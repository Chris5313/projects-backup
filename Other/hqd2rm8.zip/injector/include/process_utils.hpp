#ifndef PROCESS_UTILS_HPP
#define PROCESS_UTILS_HPP

#include <Windows.h>
#include <winternl.h>
#include <ntstatus.h>
#include <stdint.h>
#include <string>
#include <vector>
#include <memory>
#include <algorithm>
#include <optional>
#include <TlHelp32.h>

namespace process_utils {
	class process_information {
	public:
		explicit process_information(const PROCESSENTRY32W& process_entry);
		~process_information() = default;

		uint32_t get_process_id() const;

		uint32_t get_parent_process_id() const;

		std::vector<process_information> get_children_processes() const;

		std::string get_name() const;

		bool is_running() const;
	private:
		PROCESSENTRY32W m_process_entry = {};
	};

	std::vector<process_information> get_all_processes();

	std::optional<process_information> get_process_by_id(uint32_t process_id);

	std::vector<process_information> get_processes_by_name(const std::string_view name);

	std::optional<process_information> get_process_by_name(const std::string_view name);
} // namespace process_utils

#endif // !PROCESS_UTILS_HPP