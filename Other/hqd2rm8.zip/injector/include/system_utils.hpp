#ifndef SYSTEM_UTILS_HPP
#define SYSTEM_UTILS_HPP

#include <Windows.h>
#include <winternl.h>
#include <ntstatus.h>
#include <stdint.h>
#include <string>
#include <vector>
#include <memory>
#include <algorithm>
#include <optional>

#pragma comment(lib, "ntdll.lib")

constexpr auto SystemModuleInformation = static_cast<SYSTEM_INFORMATION_CLASS>(11);

struct RTL_PROCESS_MODULE_INFORMATION {
	void* Section;
	void* MappedBase;
	void* ImageBase;
	uint32_t ImageSize;
	uint32_t Flags;
	uint16_t LoadOrderIndex;
	uint16_t InitOrderIndex;
	uint16_t LoadCount;
	uint16_t OffsetToFileName;
	uint8_t FullPathName[256];
};

struct RTL_PROCESS_MODULES {
	uint32_t NumberOfModules;
	RTL_PROCESS_MODULE_INFORMATION Modules[1];
};

namespace system_utils {
	class system_module_information {
	public:
		explicit system_module_information(const RTL_PROCESS_MODULE_INFORMATION& system_module);
		~system_module_information() = default;

		uint64_t image_base() const;

		uint64_t image_size() const;

		std::string get_full_path_string() const;

		std::string get_path_string() const;

		std::string get_file_name_string() const;

		std::wstring get_full_path_wstring() const;

		std::wstring get_path_wstring() const;

		std::wstring get_file_name_wstring() const;

		uint64_t get_export(const std::string_view export_name) const;
	private:
		RTL_PROCESS_MODULE_INFORMATION m_system_module = {};
	};

	std::vector<system_module_information> get_system_modules();

	std::optional<system_module_information> get_system_module(const std::string_view module_name);
} // namespace system_utils

#endif // !SYSTEM_UTILS_HPP