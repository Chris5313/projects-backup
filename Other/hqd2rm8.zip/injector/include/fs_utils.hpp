#ifndef FS_UTILS_HPP
#define FS_UTILS_HPP

#include <stdint.h>
#include <string>
#include <vector>
#include <fstream>

namespace fs_utils {
	bool load_file_into_memory(const std::string_view& file_path, std::vector<uint8_t>& file_vector);

	bool create_file_from_memory(const std::string_view& file_path, const std::vector<uint8_t>& file_vector);
} // namespace fs_utils

#endif // !FS_UTILS_HPP