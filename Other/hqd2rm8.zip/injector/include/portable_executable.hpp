#ifndef PORTABLE_EXECUTABLE_HPP
#define PORTABLE_EXECUTABLE_HPP

#include <Windows.h>
#include <stdint.h>
#include <string>
#include <vector>
#include <optional>
#include <atomic>

class portable_executable_section {
public:
	explicit portable_executable_section(PIMAGE_SECTION_HEADER image_section_header);
	~portable_executable_section() = default;

	std::string_view get_name() const;

	uint32_t get_characteristics() const;

	uint64_t get_virtual_address() const;

	uint64_t get_virtual_size() const;

	uint64_t get_size_of_raw_data() const;

	uint64_t get_pointer_to_raw_data() const;
private:
	PIMAGE_SECTION_HEADER m_image_section_header = nullptr;
};

class portable_executable_import_thunk {
public:
	explicit portable_executable_import_thunk(std::string name, uint64_t* address_of_data);
	~portable_executable_import_thunk() = default;

	void set_address_of_data(uint64_t value);

	std::string_view get_name() const;
private:
	std::string m_name;
	uint64_t* m_address_of_data = nullptr;
};

class portable_executable_import_descriptor {
public:
	explicit portable_executable_import_descriptor(std::string name, std::vector<portable_executable_import_thunk> portable_executable_import_thunks);
	~portable_executable_import_descriptor() = default;

	std::string_view get_name() const;
	
	const std::vector<portable_executable_import_thunk>& get_import_thunks() const;
private:
	std::string m_name;
	std::vector<portable_executable_import_thunk> m_portable_executable_import_thunks;
};

class portable_exectuable_relocation {
public:
	explicit portable_exectuable_relocation(uint16_t entry);
	~portable_exectuable_relocation() = default;
	
	auto* get_relocation() const;
private:
	struct {
		uint16_t offset : 12;
		uint16_t type : 4;
	}m_relocation;
};

class portable_exectuable_relocation_block {
public:
	explicit portable_exectuable_relocation_block(uint64_t virtual_address, std::vector<portable_exectuable_relocation> portable_exectuable_relocations);
	~portable_exectuable_relocation_block() = default;

	uint64_t get_virtual_address() const;

	std::vector<portable_exectuable_relocation>& get_relocations();
private:
	uint64_t m_virtual_address = 0;
	std::vector<portable_exectuable_relocation> m_portable_exectuable_relocations;
};

class portable_executable {
public:
	explicit portable_executable(std::vector<uint8_t>& portable_executable);
	~portable_executable() = default;

	bool parse();

	PIMAGE_DOS_HEADER get_image_dos_header() const;

	PIMAGE_NT_HEADERS get_image_nt_headers() const;

	PIMAGE_FILE_HEADER get_image_file_header() const;

	PIMAGE_OPTIONAL_HEADER get_image_optional_header() const;

	const std::vector<uint8_t>& get_portable_executable() const;

	uint64_t get_image_entry_point() const;

	uint64_t get_image_base_address() const;

	uint64_t get_image_size() const;

	const std::vector<portable_executable_section>& get_portable_executable_sections() const;

	const std::vector<portable_exectuable_relocation_block>& get_portable_executable_relocations_blocks();

	const std::vector<portable_executable_import_descriptor>& get_portable_executable_import_descriptors();
private:
	void parse_sections();

	bool parse_relocations();

	bool parse_imports();

	template <typename t>
	const t* at(uint64_t rva) const {
		if (!m_sections_parsed.load())
			return nullptr;

		if (!rva)
			return nullptr;

		for (const auto& section : get_portable_executable_sections()) {
			const auto virtual_address = section.get_virtual_address();
			const auto virtual_size = section.get_virtual_size();
			const auto pointer_to_raw_data = section.get_pointer_to_raw_data();
			if (rva < virtual_address || rva >= (virtual_address + virtual_size))
				continue;

			const auto offset = (rva - virtual_address) + pointer_to_raw_data;
			if (offset >= m_portable_executable.size())
				return nullptr;

			return reinterpret_cast<const t*>(m_portable_executable.data() + offset);
		}

		return nullptr;
	}

	std::atomic<bool> m_sections_parsed{ false };
	std::atomic<bool> m_relocations_parsed{ false };
	std::atomic<bool> m_imports_parsed{ false };

	std::vector<portable_executable_section> m_portable_executable_sections;
	std::vector<portable_exectuable_relocation_block> m_portable_executable_relocations_blocks;
	std::vector<portable_executable_import_descriptor> m_portable_executable_import_descriptors;
	std::vector<uint8_t> m_portable_executable;
};

#endif // !PORTABLE_EXECUTABLE_HPP