#include <system_utils.hpp>

namespace system_utils {
	system_module_information::system_module_information(const RTL_PROCESS_MODULE_INFORMATION& system_module) : m_system_module(system_module) {}

	uint64_t system_module_information::image_base() const {
		return reinterpret_cast<uint64_t>(m_system_module.ImageBase);
	}

	uint64_t system_module_information::image_size() const {
		return static_cast<uint64_t>(m_system_module.ImageSize);
	}

	std::string system_module_information::get_full_path_string() const {
		return std::string(reinterpret_cast<const char*>(m_system_module.FullPathName));
	}

	std::string system_module_information::get_path_string() const {
		const auto full_path_string = get_full_path_string();
		return full_path_string.substr(0, m_system_module.OffsetToFileName);
	}

	std::string system_module_information::get_file_name_string() const {
		return get_full_path_string().substr(m_system_module.OffsetToFileName);
	}

	std::wstring system_module_information::get_full_path_wstring() const {
		const auto full_path_string = get_full_path_string();
		return std::wstring(full_path_string.begin(), full_path_string.end());
	}

	std::wstring system_module_information::get_path_wstring() const {
		const auto path_string = get_path_string();
		return std::wstring(path_string.begin(), path_string.end());
	}

	std::wstring system_module_information::get_file_name_wstring() const {
		const auto file_name_string = get_file_name_string();
		return std::wstring(file_name_string.begin(), file_name_string.end());
	}

	uint64_t system_module_information::get_export(const std::string_view export_name) const {
		const auto file_name_string = get_file_name_string();

		auto* dll_handle = LoadLibraryExA(std::string("C:\\Windows\\System32\\" + file_name_string).c_str(), nullptr, DONT_RESOLVE_DLL_REFERENCES);
		if (!dll_handle)
			dll_handle = LoadLibraryExA(std::string("C:\\Windows\\System32\\drivers\\" + file_name_string).c_str(), nullptr, DONT_RESOLVE_DLL_REFERENCES);
		
		if (!dll_handle) {
			dll_handle = LoadLibraryExA(file_name_string.c_str(), nullptr, DONT_RESOLVE_DLL_REFERENCES | LOAD_LIBRARY_SEARCH_APPLICATION_DIR | LOAD_LIBRARY_SEARCH_DEFAULT_DIRS
				| LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR
				| LOAD_LIBRARY_SEARCH_SYSTEM32
				| LOAD_LIBRARY_SEARCH_USER_DIRS
				| LOAD_WITH_ALTERED_SEARCH_PATH);
		}

		if (!dll_handle)
			return 0;

		auto procedure_address = reinterpret_cast<uint64_t>(GetProcAddress(dll_handle, export_name.data()));
		if (!procedure_address && file_name_string != "ntoskrnl.exe") {
			const auto ntoskrnl = get_system_module("ntoskrnl.exe");
			procedure_address = ntoskrnl->get_export(export_name);
		}


		FreeLibrary(dll_handle);
		return (procedure_address) ? (procedure_address - reinterpret_cast<uint64_t>(dll_handle)) + image_base() : 0;
	}

	std::vector<system_module_information> get_system_modules() {
		uint32_t return_length = 0;
		auto status = NtQuerySystemInformation(SystemModuleInformation, nullptr, 0,
			reinterpret_cast<PULONG>(&return_length));
		if (status != STATUS_INFO_LENGTH_MISMATCH)
			return {};

		std::unique_ptr<uint8_t[]> system_modules_buffer;
		while (status == STATUS_INFO_LENGTH_MISMATCH) {
			system_modules_buffer = std::make_unique<uint8_t[]>(return_length);
			status = NtQuerySystemInformation((SYSTEM_INFORMATION_CLASS)SystemModuleInformation, system_modules_buffer.get(), return_length,
				reinterpret_cast<PULONG>(&return_length));
		}

		const auto* system_modules = reinterpret_cast<RTL_PROCESS_MODULES*>(system_modules_buffer.get());
		std::vector<system_module_information> system_modules_vector;
		system_modules_vector.reserve(system_modules->NumberOfModules);

		for (uint32_t idx = 0; idx < system_modules->NumberOfModules; idx++)
			system_modules_vector.emplace_back(system_modules->Modules[idx]);

		return system_modules_vector;
	}

	std::optional<system_module_information> get_system_module(const std::string_view module_name) {
		const auto& system_modules = get_system_modules();
		if (system_modules.empty())
			return std::nullopt;

		for (const auto& module : system_modules) {
			const auto to_lower_case = [](const std::string& string) -> std::string {
				std::string result = string;
				std::transform(result.begin(), result.end(), result.begin(),
					[](uint8_t c) { return std::tolower(c); });
				return result;
			};

			if (to_lower_case(module.get_file_name_string()).find(to_lower_case(std::string(module_name))) == std::string::npos)
				continue;

			return module;
		}

		return std::nullopt;
	}
} // namespace system_utils