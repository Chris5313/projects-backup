#include <Windows.h>
#include <winternl.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <thread>
#include <chrono>
#include <process_utils.hpp>

int main() {
    auto target = process_utils::get_process_by_name("RustClient.exe");
    while (!target) {
        target = process_utils::get_process_by_name("RustClient.exe");
        std::this_thread::sleep_for(std::chrono::milliseconds(250));
    }

    auto process_handle = OpenProcess(PROCESS_ALL_ACCESS, false, target->get_process_id());
    if (!process_handle)
        return 1;

    std::string internal_path = "A:\\repos\\moneyhack\\build\\internal.dll";
    auto* remote_path = VirtualAllocEx(process_handle, nullptr, internal_path.size(),
        MEM_COMMIT | MEM_RESERVE, 
        PAGE_READWRITE);
    if (!remote_path) {
        CloseHandle(process_handle);
        return 1;
    }

    if (!WriteProcessMemory(process_handle, remote_path, internal_path.c_str(), 
        internal_path.size(),
        nullptr)) {
        VirtualFreeEx(process_handle, remote_path, 0,
            MEM_RELEASE);
        CloseHandle(process_handle);
        return 1;
    }

    auto kernel32 = LoadLibraryA("kernel32.dll");
    auto load_library_a = GetProcAddress(kernel32, "LoadLibraryA");

    auto remote_thread = CreateRemoteThread(process_handle, nullptr, 0,
        reinterpret_cast<LPTHREAD_START_ROUTINE>(load_library_a),
        reinterpret_cast<void*>(remote_path),
        0,
        nullptr);

    CloseHandle(remote_thread);
    CloseHandle(process_handle);
    return 0;
}