#include <fs_utils.hpp>

namespace fs_utils {
	bool load_file_into_memory(const std::string_view& file_path, std::vector<uint8_t>& file_vector) {
		std::ifstream file(std::string(file_path), std::ios::binary | std::ios::ate);
		if (!file.is_open())
			return false;

		const auto file_size = file.tellg();
		if (file_size < 0) {
			file.close();
			return false;
		}

		file_vector.clear();
		file_vector.resize(static_cast<uint64_t>(file_size));

		file.seekg(0, std::ios::beg);
		file.read(reinterpret_cast<char*>(file_vector.data()), file_size);
		file.close();
		return true;
	}

	bool create_file_from_memory(const std::string_view& file_path, const std::vector<uint8_t>& file_vector) {
		std::ofstream file(std::string(file_path), std::ios::out | std::ios::binary);
		if (!file.is_open())
			return false;

		if (file_vector.empty()) {
			file.close();
			return true;
		}

		file.write(reinterpret_cast<const char*>(file_vector.data()), file_vector.size());
		file.close();
		return true;
	}
} // namespace fs_utils