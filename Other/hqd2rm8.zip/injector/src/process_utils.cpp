#include <process_utils.hpp>

namespace process_utils {
	process_information::process_information(const PROCESSENTRY32W& process_entry) : m_process_entry(process_entry) {}

	uint32_t process_information::get_process_id() const {
		return m_process_entry.th32ProcessID;
	}

	uint32_t process_information::get_parent_process_id() const {
		return m_process_entry.th32ParentProcessID;
	}

	std::vector<process_information> process_information::get_children_processes() const {
		std::vector<process_information> children;
		const auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		if (snapshot == INVALID_HANDLE_VALUE)
			return children;

		PROCESSENTRY32W process_entry = { .dwSize = sizeof(PROCESSENTRY32W) };
		if (!Process32FirstW(snapshot, &process_entry)) {
			CloseHandle(snapshot);
			return children;
		}

		do {
			if (process_entry.th32ParentProcessID == m_process_entry.th32ProcessID)
				children.emplace_back(process_entry);
		} while (Process32NextW(snapshot, &process_entry));

		CloseHandle(snapshot);
		return children;
	}

	std::string process_information::get_name() const {
		std::wstring_view process_name(m_process_entry.szExeFile);
		return std::string(process_name.begin(), process_name.end());
	}

	bool process_information::is_running() const {
		const auto process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, m_process_entry.th32ProcessID);
		if (!process)
			return false;

		uint32_t exit_code = 0;
		if (GetExitCodeProcess(process, reinterpret_cast<LPDWORD>(&exit_code))) {
			CloseHandle(process);
			return (exit_code == STILL_ACTIVE);
		}

		CloseHandle(process);
		return false;
	}

	std::vector<process_information> get_all_processes() {
		std::vector<process_information> processes;
		const auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		if (snapshot == INVALID_HANDLE_VALUE)
			return processes;

		PROCESSENTRY32W process_entry = { .dwSize = sizeof(PROCESSENTRY32W) };
		if (!Process32FirstW(snapshot, &process_entry)) {
			CloseHandle(snapshot);
			return processes;
		}

		do {
			processes.emplace_back(process_entry);
		} while (Process32NextW(snapshot, &process_entry));

		CloseHandle(snapshot);
		return processes;
	}

	std::optional<process_information> get_process_by_id(uint32_t process_id) {
		const auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		if (snapshot == INVALID_HANDLE_VALUE)
			return std::nullopt;

		PROCESSENTRY32W process_entry = { .dwSize = sizeof(PROCESSENTRY32W) };
		if (!Process32FirstW(snapshot, &process_entry)) {
			CloseHandle(snapshot);
			return std::nullopt;
		}

		do {
			if (process_entry.th32ProcessID == process_id) {
				CloseHandle(snapshot);
				return process_information(process_entry);
			}
		} while (Process32NextW(snapshot, &process_entry));

		CloseHandle(snapshot);
		return std::nullopt;
	}

	std::vector<process_information> get_processes_by_name(const std::string_view name) {
		std::vector<process_information> matching_processes;
		const auto all_processes = get_all_processes();

		for (const auto& process : all_processes) {
			if (process.get_name().find(name) != std::string_view::npos)
				matching_processes.push_back(process);
		}

		return matching_processes;
	}

	std::optional<process_information> get_process_by_name(const std::string_view name) {
		const auto matches = get_processes_by_name(name);
		if (!matches.empty())
			return matches.front();

		return std::nullopt;
	}
} // namespace process_utils