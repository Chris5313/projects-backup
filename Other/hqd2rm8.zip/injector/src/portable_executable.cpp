#include <portable_executable.hpp>

portable_executable::portable_executable(std::vector<uint8_t>& portable_executable) : m_portable_executable(portable_executable) {}

bool portable_executable::parse() {
	if (m_portable_executable.empty())
		return false;

	if (!get_image_nt_headers())
		return false;

	parse_sections();

	return parse_relocations() && parse_imports();
}

PIMAGE_DOS_HEADER portable_executable::get_image_dos_header() const {
	if (m_portable_executable.empty() || m_portable_executable.size() < sizeof(IMAGE_DOS_HEADER))
		return nullptr;

	auto* image_dos_header = reinterpret_cast<PIMAGE_DOS_HEADER>(const_cast<uint8_t*>(m_portable_executable.data()));
	if (image_dos_header->e_magic != IMAGE_DOS_SIGNATURE)
		return nullptr;

	return image_dos_header;
}

PIMAGE_NT_HEADERS portable_executable::get_image_nt_headers() const {
	const auto image_dos_header = get_image_dos_header();
	if (!image_dos_header)
		return nullptr;

	auto* image_nt_headers = reinterpret_cast<PIMAGE_NT_HEADERS>(const_cast<uint8_t*>(m_portable_executable.data()) + image_dos_header->e_lfanew);
	if (image_nt_headers->Signature != IMAGE_NT_SIGNATURE)
		return nullptr;

	return image_nt_headers;
}

PIMAGE_FILE_HEADER portable_executable::get_image_file_header() const {
	const auto image_nt_headers = get_image_nt_headers();
	if (!image_nt_headers)
		return nullptr;

	return &image_nt_headers->FileHeader;
}

PIMAGE_OPTIONAL_HEADER portable_executable::get_image_optional_header() const {
	const auto image_nt_headers = get_image_nt_headers();
	if (!image_nt_headers)
		return nullptr;

	return &image_nt_headers->OptionalHeader;
}

const std::vector<uint8_t>& portable_executable::get_portable_executable() const {
	return m_portable_executable;
}

uint64_t portable_executable::get_image_entry_point() const {
	const auto* image_optional_header = get_image_optional_header();
	if (!image_optional_header)
		return 0;

	return image_optional_header->AddressOfEntryPoint;
}

uint64_t portable_executable::get_image_base_address() const {
	const auto* image_optional_header = get_image_optional_header();
	if (!image_optional_header)
		return 0;

	return image_optional_header->ImageBase;
}

uint64_t portable_executable::get_image_size() const {
	const auto* image_optional_header = get_image_optional_header();
	if (!image_optional_header)
		return 0;

	return image_optional_header->SizeOfImage;
}

const std::vector<portable_executable_section>& portable_executable::get_portable_executable_sections() const {
	return m_portable_executable_sections;
}

const std::vector<portable_exectuable_relocation_block>& portable_executable::get_portable_executable_relocations_blocks() {
	return m_portable_executable_relocations_blocks;
}

const std::vector<portable_executable_import_descriptor>& portable_executable::get_portable_executable_import_descriptors() {
	return m_portable_executable_import_descriptors;
}

void portable_executable::parse_sections() {
	if (m_sections_parsed.load())
		return;

	const auto* image_nt_headers = get_image_nt_headers();
	const auto* image_file_header = get_image_file_header();

	auto* image_sections = IMAGE_FIRST_SECTION(image_nt_headers);
	for (auto idx = 0; idx < image_file_header->NumberOfSections; idx++) {
		m_portable_executable_sections.emplace_back(&image_sections[idx]);
	}

	m_sections_parsed.store(true);
}

bool portable_executable::parse_relocations() {
	if (m_relocations_parsed.load())
		return true;

	const auto* image_nt_headers = get_image_nt_headers();
	const auto& directory = image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
	if (!directory.VirtualAddress || !directory.Size)
		return true;

	const auto* image_base_relocation = at<IMAGE_BASE_RELOCATION>(directory.VirtualAddress);
	if (!image_base_relocation)
		return false;

	const auto* directory_end = reinterpret_cast<const std::uint8_t*>(image_base_relocation) + directory.Size;

	while (reinterpret_cast<const std::uint8_t*>(image_base_relocation) < directory_end && image_base_relocation->SizeOfBlock > 0) {
		const auto* relocation_entries = reinterpret_cast<const uint16_t*>(image_base_relocation + 1);
		const auto entries_count = (image_base_relocation->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(uint16_t);

		std::vector<portable_exectuable_relocation> relocations;
		relocations.reserve(entries_count);

		for (auto idx = 0; idx < entries_count; idx++)
			relocations.emplace_back(relocation_entries[idx]);

		m_portable_executable_relocations_blocks.emplace_back(image_base_relocation->VirtualAddress, std::move(relocations));

		image_base_relocation = reinterpret_cast<const IMAGE_BASE_RELOCATION*>(reinterpret_cast<const std::uint8_t*>(image_base_relocation) + image_base_relocation->SizeOfBlock);
	}

	m_relocations_parsed.store(true);
	return true;
}

bool portable_executable::parse_imports() {
	if (m_imports_parsed.load()) 
		return true;

	const auto* image_nt_headers = get_image_nt_headers();
	const auto& directory = image_nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
	if (!directory.VirtualAddress || !directory.Size) 
		return true;

	const auto* image_import_descriptor =at<IMAGE_IMPORT_DESCRIPTOR>(directory.VirtualAddress);
	if (!image_import_descriptor) return false;

	while (image_import_descriptor->Name) {
		auto module_name = std::string(at<char>(image_import_descriptor->Name));

		std::vector<portable_executable_import_thunk> thunks;

		const auto* image_thunk_data =
			at<IMAGE_THUNK_DATA>(image_import_descriptor->OriginalFirstThunk
				? image_import_descriptor->OriginalFirstThunk
				: image_import_descriptor->FirstThunk);

		while (image_thunk_data && image_thunk_data->u1.AddressOfData) {
			std::string function_name = "";
			if (!(image_thunk_data->u1.Ordinal & IMAGE_ORDINAL_FLAG64)) {
				const auto* image_import_by_name =
					at<IMAGE_IMPORT_BY_NAME>(image_thunk_data->u1.AddressOfData);
				if (image_import_by_name)
					function_name =
					reinterpret_cast<const char*>(image_import_by_name->Name);
			} else {
				function_name = std::to_string(image_thunk_data->u1.Ordinal & 0xFFFF);
			}

			auto* address_field = reinterpret_cast<uint64_t*>(
				const_cast<IMAGE_THUNK_DATA*>(image_thunk_data));
			thunks.emplace_back(std::string(function_name), address_field);
			image_thunk_data++;
		}

		m_portable_executable_import_descriptors.emplace_back(
			std::move(module_name), std::move(thunks));
		image_import_descriptor++;
	}

	m_imports_parsed.store(true);
	return true;
}

portable_executable_section::portable_executable_section(PIMAGE_SECTION_HEADER image_section_header) : m_image_section_header(image_section_header) {}

std::string_view portable_executable_section::get_name() const {
	if (!m_image_section_header)
		return {};

	const auto* name = reinterpret_cast<const char*>(m_image_section_header->Name);

	uint64_t length = 0;
	while (length < sizeof(IMAGE_SECTION_HEADER::Name) && name[length] != '\0')
		length++;

	return std::string_view(name, length);
}

uint32_t portable_executable_section::get_characteristics() const {
	if (!m_image_section_header)
		return 0;

	return m_image_section_header->Characteristics;
}

uint64_t portable_executable_section::get_virtual_address() const {
	if (!m_image_section_header)
		return 0;

	return m_image_section_header->VirtualAddress;
}

uint64_t portable_executable_section::get_virtual_size() const {
	if (!m_image_section_header)
		return 0;

	return m_image_section_header->Misc.VirtualSize;
}

uint64_t portable_executable_section::get_size_of_raw_data() const {
	if (!m_image_section_header)
		return 0;

	return m_image_section_header->SizeOfRawData;
}

uint64_t portable_executable_section::get_pointer_to_raw_data() const {
	if (!m_image_section_header)
		return 0;

	return m_image_section_header->PointerToRawData;
}

portable_executable_import_thunk::portable_executable_import_thunk(std::string name, uint64_t* address_of_data) : m_name(name), m_address_of_data(address_of_data) {}

void portable_executable_import_thunk::set_address_of_data(uint64_t value) {
	if (!value)
		return;

	*m_address_of_data = value;
}

std::string_view portable_executable_import_thunk::get_name() const {
	return m_name;
}

portable_executable_import_descriptor::portable_executable_import_descriptor(std::string name, std::vector<portable_executable_import_thunk> portable_executable_import_thunks) : m_name(name), m_portable_executable_import_thunks(portable_executable_import_thunks) {}

std::string_view portable_executable_import_descriptor::get_name() const {
	return m_name;
}

const std::vector<portable_executable_import_thunk>& portable_executable_import_descriptor::get_import_thunks() const {
	return m_portable_executable_import_thunks;
}

portable_exectuable_relocation::portable_exectuable_relocation(uint16_t entry) {
	m_relocation.offset = (entry & 0xFFF);
	m_relocation.type = (entry >> 12);
}

auto* portable_exectuable_relocation::get_relocation() const {
	return &m_relocation;
}

portable_exectuable_relocation_block::portable_exectuable_relocation_block(uint64_t virtual_address, std::vector<portable_exectuable_relocation> portable_exectuable_relocations) : m_virtual_address(virtual_address), m_portable_exectuable_relocations(portable_exectuable_relocations) {}

uint64_t portable_exectuable_relocation_block::get_virtual_address() const {
	return m_virtual_address;
}

std::vector<portable_exectuable_relocation>& portable_exectuable_relocation_block::get_relocations() {
	return m_portable_exectuable_relocations;
}