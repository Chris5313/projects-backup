#ifndef SDK_HPP
#define SDK_HPP

#include <il2cpp/api_functions.hpp>
#include <glm/glm.hpp>
#include <globals.hpp>

namespace sdk {
	namespace unity_engine {
		class object : public Il2CppObject {};

		class component : public object {};

		class behaviour : public component {};

		class mono_behaviour : public behaviour {};
	} // namespace unity_engine

	class facepunch_behaviour : public unity_engine::mono_behaviour {};

	class base_mono_behaviour : public facepunch_behaviour {};

	class base_networkable : public base_mono_behaviour {
	public:
		class entity_realm {
		public:
			void* get_entity_list() {
				return nullptr;
			}
		};

		uint32_t get_prefab_id() {
			static auto offset = rust::base_networkable.load()->get_field_from_name("prefabId")->get_offset();
			return *reinterpret_cast<uint32_t*>(reinterpret_cast<uint8_t*>(this) + offset);
		}
	};

	class base_entity : public base_networkable {
	public:

	};
} // namespace sdk

#endif // !SDK_HPP