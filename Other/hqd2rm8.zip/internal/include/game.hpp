#ifndef GAME_HPP
#define GAME_HPP

#include <Windows.h>
#include <winternl.h>
#include <stdint.h>
#include <thread>
#include <string>
#include <renderer.hpp>
#include <hooks/hooks.hpp>
#include <globals.hpp>

namespace game {
	bool initialize();
} // namespace game

#endif // !GAME_HPP