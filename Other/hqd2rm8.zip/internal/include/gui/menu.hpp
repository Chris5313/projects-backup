#ifndef GUI_MENU_HPP
#define GUI_MENU_HPP

#include <string>
#include <globals.hpp>
#include <renderer.hpp>
#include <gui/tabs/aimbot.hpp>
#include <gui/tabs/visuals.hpp>
#include <gui/tabs/misc.hpp>

namespace gui::menu {
	extern std::atomic<bool> initialized;
	extern std::atomic<bool> menu_shown;
	constexpr ImVec2 window_size = { 500, 500 };

	void render();
} // namespace gui::menu

#endif // !GUI_MENU_HPP