#ifndef GUI_AIMBOT_VISUALS_HPP
#define GUI_AIMBOT_VISUALS_HPP

#include <gui/menu.hpp>

namespace gui::menu::aimbot {
	void render();
} // namespace gui::menu::aimbot

#endif // !GUI_AIMBOT_VISUALS_HPP