#ifndef GUI_MISC_VISUALS_HPP
#define GUI_MISC_VISUALS_HPP

#include <gui/menu.hpp>

namespace gui::menu::misc {
	void render();
} // namespace gui::menu::misc

#endif // !GUI_MISC_VISUALS_HPP