#ifndef GUI_TABS_VISUALS_HPP
#define GUI_TABS_VISUALS_HPP

#include <gui/menu.hpp>

namespace gui::menu::visuals {
	void render();
} // namespace gui::menu::visuals

#endif // !GUI_TABS_VISUALS_HPP