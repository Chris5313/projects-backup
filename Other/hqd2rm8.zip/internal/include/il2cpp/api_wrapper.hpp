#ifndef API_WRAPPER_HPP
#define API_WRAPPER_HPP

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <string_view>
#include <vector>
#include <il2cpp/api_functions.hpp>
#include <il2cpp/class_internals.hpp>
#include <il2cpp/object_internals.hpp>
#include <il2cpp/runtime_metadata.hpp>
#include <il2cpp/tabledefs.hpp>

namespace il2cpp::api_wrapper {
    struct type;
    struct field;
    struct method;
    struct klass;
    struct image;
    struct object;

    bool valid(void* __this);

    bool valid(const void* __this);

    struct type {
        object* get_object() const;

        int32_t get_type() const;

        klass* get_class_or_element_class(type* type) const;

        std::string_view get_name() const;

        bool is_byref() const;

        uint32_t get_attributes() const;

        bool equals(type* type);

        std::string_view get_assembly_qualified_name() const;

        std::string_view get_reflection_name() const;

        bool is_static() const;

        bool is_pointer_type() const;

        Il2CppType* il2cpp() const;
    };

    struct field {
        int32_t get_flags() const;

        std::string_view get_name() const;

        klass* get_parent() const;

        uint64_t get_offset() const;
        
        type* get_type() const;

        bool is_static() const;

        bool has_attribute(klass* klass) const;

        void get_value(object* object, void* value) const;

        template <typename t>
        t get_value(object* object) const {
            t result{};
            get_value(object, &result);
            return result;
        }

        void set_value(object* object, void* value) const;

        template <typename t>
        void set_value(object* object, const t& value) const {
            set_value(object, (void*)&value);
        }

        void static_get_value(void* value) const;

        template <typename t>
        t static_get_value() const {
            t result{};
            static_get_value(&result);
            return result;
        }

        void static_set_value(void* value) const;

        template <typename t>
        void static_set_value(const t& value) const {
            static_set_value((void*)&value);
        }

        FieldInfo* il2cpp() const;
    };

    struct method {
        type* get_return_type() const;

        std::string_view get_name() const;

        bool is_generic() const;

        bool is_inflated() const;

        bool is_instance() const;

        bool is_virtual() const;

        uint32_t get_param_count() const;

        type* get_param_type(uint32_t idx) const;

        klass* get_class() const;

        bool has_attribute(klass* klass) const;

        std::string_view get_param_name(uint32_t idx) const;

        void* get_method_address() const;

        void** get_method_pointer() const;

        object* invoke(object* object, void** params, Il2CppException** exception = nullptr) const;

        MethodInfo* il2cpp() const;
    };

    struct klass {
        void* get_vtable() const;

        uint64_t get_vtable_size() const;

        bool is_inited() const;

        bool is_generic() const;

        bool is_inflated() const;

        bool is_abstract() const;

        bool is_interface() const;

        bool is_enum() const;

        bool has_attribute(klass* klass) const;

        bool has_references() const;

        std::vector<klass*> get_nested_types() const;

        std::vector<klass*> get_interfaces() const;

        std::vector<field*> get_fields() const;

        field* get_field_from_name(std::string_view field_name) const;

        std::vector<method*> get_methods() const;

        method* get_method_from_name(std::string_view method_name, int32_t argument_count) const;

        method* get_method_from_name(std::string_view method_name) const;

        std::string_view get_name() const;

        std::string_view get_namespace() const;

        klass* get_parent() const;

        int32_t get_flags() const;

        type* get_type() const;

        image* get_image() const;

        std::string_view get_assembly_name() const;

        void* get_static_field_data() const;

        template <typename t> 
        t* get_static_field_data() const {
            return (t*)get_static_field_data();
        }

        Il2CppClass* il2cpp() const;
    };

    struct image {
        std::string_view get_name() const;

        std::string_view get_file_name() const;

        std::vector<klass*> get_classes() const;

        klass* get_class(std::string_view class_name) const;

        Il2CppImage* il2cpp() const;
    };

    struct object {
    public:
        Il2CppObject* il2cpp() const;
    };

    klass* find_class(std::string_view namespace_name, std::string_view class_name);

    klass* find_class(std::string_view class_name);

    klass* find_nested_class(std::string_view namespace_name, std::string_view class_name, std::string_view nested_name);

    klass* find_nested_class(std::string_view class_name, std::string_view nested_name);

    method* find_method(std::string_view namespace_name, std::string_view class_name, std::string_view method_name,
        int32_t argument_count);

    method* find_method(std::string_view namespace_name, std::string_view class_name, std::string_view method_name);

    method* find_method(std::string_view class_name, std::string_view method_name, int32_t argument_count);

    method* find_method(std::string_view class_name, std::string_view method_name);
} // namespace il2cpp::api_wrapper

#endif // !API_WRAPPER_HPP