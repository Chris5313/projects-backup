#ifndef API_FUNCTIONS_HPP
#define API_FUNCTIONS_HPP

#include <Windows.h>
#include <stdint.h>
#include <stddef.h>
#include <il2cpp/api_types.hpp>

namespace il2cpp {
    extern HMODULE game_assembly;

    namespace init {
        int32_t init(const char* domain_name);

        int32_t init_utf16(const Il2CppChar* domain_name);

        void shutdown();
    } // namespace init

    namespace config {
        void set_config_dir(const char* config_path);

        void set_data_dir(const char* data_path);

        void set_temp_dir(const char* temp_path);

        void set_commandline_arguments(int32_t argc, const char* const argv[], const char* basedir);

        void set_commandline_arguments_utf16(int32_t argc, const Il2CppChar* const argv[], const char* basedir);

        void set_config_utf16(const Il2CppChar* executablePath);

        void set_config(const char* executablePath);

        void set_memory_callbacks(Il2CppMemoryCallbacks* callbacks);
    } // namespace config

    namespace memory {
        void* alloc(size_t size);

        void free(void* ptr);

        void* gc_alloc_fixed(size_t size);

        void gc_free_fixed(void* address);
    } // namespace memory

    namespace icall {
        void add_internal_call(const char* name, Il2CppMethodPointer method);

        Il2CppMethodPointer resolve_icall(const char* name);
    } // namespace icall

    namespace core {
        const Il2CppImage* get_corlib();
    } // namespace core

    namespace array {
        Il2CppClass* class_get(Il2CppClass* element_class, uint32_t rank);

        uint32_t length(Il2CppArray* array);

        uint32_t get_byte_length(Il2CppArray* array);

        Il2CppArray* new_array(Il2CppClass* elementTypeInfo, il2cpp_array_size_t length);

        Il2CppArray* new_specific(Il2CppClass* arrayTypeInfo, il2cpp_array_size_t length);

        Il2CppArray* new_full(Il2CppClass* array_class, il2cpp_array_size_t* lengths, il2cpp_array_size_t* lower_bounds);

        Il2CppClass* bounded_class_get(Il2CppClass* element_class, uint32_t rank, bool bounded);

        int32_t element_size(const Il2CppClass* array_class);
    } // namespace array

    namespace assembly {
        const Il2CppImage* get_image(const Il2CppAssembly* assembly);
    } // namespace assembly

    namespace klass {
        void for_each(void(*klassReportFunc)(Il2CppClass* klass, void* userData), void* userData);

        const Il2CppType* enum_basetype(Il2CppClass* klass);

        bool is_inited(const Il2CppClass* klass);

        bool is_generic(const Il2CppClass* klass);

        bool is_inflated(const Il2CppClass* klass);

        bool is_assignable_from(Il2CppClass* klass, Il2CppClass* oklass);

        bool is_subclass_of(Il2CppClass* klass, Il2CppClass* klassc, bool check_interfaces);

        bool has_parent(Il2CppClass* klass, Il2CppClass* klassc);

        Il2CppClass* from_il2cpp_type(const Il2CppType* type);

        Il2CppClass* from_name(const Il2CppImage* image, const char* namespaze, const char* name);

        Il2CppClass* from_system_type(Il2CppReflectionType* type);

        Il2CppClass* get_element_class(Il2CppClass* klass);

        const EventInfo* get_events(Il2CppClass* klass, void** iter);

        FieldInfo* get_fields(Il2CppClass* klass, void** iter);

        Il2CppClass* get_nested_types(Il2CppClass* klass, void** iter);

        Il2CppClass* get_interfaces(Il2CppClass* klass, void** iter);

        const PropertyInfo* get_properties(Il2CppClass* klass, void** iter);

        const PropertyInfo* get_property_from_name(Il2CppClass* klass, const char* name);

        FieldInfo* get_field_from_name(Il2CppClass* klass, const char* name);

        const MethodInfo* get_methods(Il2CppClass* klass, void** iter);

        const MethodInfo* get_method_from_name(Il2CppClass* klass, const char* name, int32_t argsCount);

        const char* get_name(Il2CppClass* klass);

        const char* get_namespace(Il2CppClass* klass);

        Il2CppClass* get_parent(Il2CppClass* klass);

        Il2CppClass* get_declaring_type(Il2CppClass* klass);

        int32_t instance_size(Il2CppClass* klass);

        size_t num_fields(const Il2CppClass* enumKlass);

        bool is_valuetype(const Il2CppClass* klass);

        int32_t value_size(Il2CppClass* klass, uint32_t* align);

        bool is_blittable(const Il2CppClass* klass);

        int32_t get_flags(const Il2CppClass* klass);

        bool is_abstract(const Il2CppClass* klass);

        bool is_interface(const Il2CppClass* klass);

        int32_t array_element_size(const Il2CppClass* klass);

        Il2CppClass* from_type(const Il2CppType* type);

        const Il2CppType* get_type(Il2CppClass* klass);

        uint32_t get_type_token(Il2CppClass* klass);

        bool has_attribute(Il2CppClass* klass, Il2CppClass* attr_class);

        bool has_references(Il2CppClass* klass);

        bool is_enum(const Il2CppClass* klass);

        const Il2CppImage* get_image(Il2CppClass* klass);

        const char* get_assemblyname(const Il2CppClass* klass);

        int32_t get_rank(const Il2CppClass* klass);

        uint32_t get_data_size(const Il2CppClass* klass);

        void* get_static_field_data(const Il2CppClass* klass);

        size_t get_bitmap_size(const Il2CppClass* klass);

        void get_bitmap(Il2CppClass* klass, size_t* bitmap);
    } // namespace klass

    namespace domain {
        Il2CppDomain* get();

        const Il2CppAssembly* assembly_open(Il2CppDomain* domain, const char* name);

        const Il2CppAssembly** get_assemblies(const Il2CppDomain* domain, size_t* size);
    } // namespace domain

    namespace exception {
        [[noreturn]] void raise(Il2CppException*);

        Il2CppException* from_name_msg(const Il2CppImage* image, const char* name_space, const char* name, const char* msg);

        Il2CppException* get_argument_null(const char* arg);

        void format(const Il2CppException* ex, char* message, int32_t message_size);

        void format_stack_trace(const Il2CppException* ex, char* output, int32_t output_size);

        void unhandled(Il2CppException*);

        void native_stack_trace(const Il2CppException* ex, uintptr_t** addresses, int32_t* numFrames, char** imageUUID, char** imageName);
    } // namespace exception

    namespace field {
        int32_t get_flags(FieldInfo* field);

        const FieldInfo* get_from_reflection(const Il2CppReflectionField* field);

        const char* get_name(FieldInfo* field);

        Il2CppClass* get_parent(FieldInfo* field);

        Il2CppReflectionField* get_object(FieldInfo* field, Il2CppClass* refclass);

        size_t get_offset(FieldInfo* field);

        const Il2CppType* get_type(FieldInfo* field);

        void get_value(Il2CppObject* obj, FieldInfo* field, void* value);

        Il2CppObject* get_value_object(FieldInfo* field, Il2CppObject* obj);

        bool has_attribute(FieldInfo* field, Il2CppClass* attr_class);

        void set_value(Il2CppObject* obj, FieldInfo* field, void* value);

        void static_get_value(FieldInfo* field, void* value);

        void static_set_value(FieldInfo* field, void* value);

        void set_value_object(Il2CppObject* instance, FieldInfo* field, Il2CppObject* value);

        bool is_literal(FieldInfo* field);
    } // namespace field

    namespace gc {
        void collect(int32_t maxGenerations);

        int32_t collect_a_little();

        void start_incremental_collection();

        void disable();

        void enable();

        bool is_disabled();

        void set_mode(Il2CppGCMode mode);

        int64_t get_max_time_slice_ns();

        void set_max_time_slice_ns(int64_t maxTimeSlice);

        bool is_incremental();

        int64_t get_used_size();

        int64_t get_heap_size();

        void wbarrier_set_field(Il2CppObject* obj, void** targetAddress, void* object);

        bool has_strict_wbarriers();

        void set_external_allocation_tracker(void(*func)(void*, size_t, int32_t));

        void set_external_wbarrier_tracker(void(*func)(void**));

        void foreach_heap(void(*func)(void* data, void* userData), void* userData);

        void stop_gc_world();

        void start_gc_world();
    } // namespace gc

    namespace gchandle {
        Il2CppGCHandle new_handle(Il2CppObject* obj, bool pinned);

        Il2CppGCHandle new_weakref(Il2CppObject* obj, bool track_resurrection);

        Il2CppObject* get_target(Il2CppGCHandle gchandle);

        void free(Il2CppGCHandle gchandle);

        void foreach_get_target(void(*func)(void* data, void* userData), void* userData);
    } // namespace gchandle

    namespace object {
        uint32_t header_size();

        uint32_t array_header_size();

        uint32_t offset_of_array_length_in_header();

        uint32_t offset_of_array_bounds_in_header();

        uint32_t allocation_granularity();

        Il2CppClass* get_class(Il2CppObject* obj);

        uint32_t get_size(Il2CppObject* obj);

        const MethodInfo* get_virtual_method(Il2CppObject* obj, const MethodInfo* method);

        Il2CppObject* new_object(const Il2CppClass* klass);

        void* unbox(Il2CppObject* obj);

        Il2CppObject* value_box(Il2CppClass* klass, void* data);
    } // namespace object

    namespace method {
        const Il2CppType* get_return_type(const MethodInfo* method);

        Il2CppClass* get_declaring_type(const MethodInfo* method);

        const char* get_name(const MethodInfo* method);

        const MethodInfo* get_from_reflection(const Il2CppReflectionMethod* method);

        Il2CppReflectionMethod* get_object(const MethodInfo* method, Il2CppClass* refclass);

        bool is_generic(const MethodInfo* method);

        bool is_inflated(const MethodInfo* method);

        bool is_instance(const MethodInfo* method);

        uint32_t get_param_count(const MethodInfo* method);

        const Il2CppType* get_param(const MethodInfo* method, uint32_t index);

        Il2CppClass* get_class(const MethodInfo* method);

        bool has_attribute(const MethodInfo* method, Il2CppClass* attr_class);

        uint32_t get_flags(const MethodInfo* method, uint32_t* iflags);

        uint32_t get_token(const MethodInfo* method);

        const char* get_param_name(const MethodInfo* method, uint32_t index);
    } // namespace method

    namespace property {
        uint32_t get_flags(PropertyInfo* prop);

        const MethodInfo* get_get_method(PropertyInfo* prop);

        const MethodInfo* get_set_method(PropertyInfo* prop);

        const char* get_name(PropertyInfo* prop);

        Il2CppClass* get_parent(PropertyInfo* prop);
    } // namespace property

    namespace runtime {
        Il2CppObject* invoke(const MethodInfo* method, void* obj, void** params, Il2CppException** exc);

        Il2CppObject* invoke_convert_args(const MethodInfo* method, void* obj, Il2CppObject** params, int32_t paramCount, Il2CppException** exc);

        void class_init(Il2CppClass* klass);

        void object_init(Il2CppObject* obj);

        void object_init_exception(Il2CppObject* obj, Il2CppException** exc);

        void unhandled_exception_policy_set(Il2CppRuntimeUnhandledExceptionPolicy value);
    } // namespace runtime

    namespace string {
        int32_t length(Il2CppString* str);

        Il2CppChar* chars(Il2CppString* str);

        Il2CppString* new_string(const char* str);

        Il2CppString* new_len(const char* str, uint32_t length);

        Il2CppString* new_utf16(const Il2CppChar* text, int32_t len);

        Il2CppString* new_wrapper(const char* str);

        Il2CppString* intern(Il2CppString* str);

        Il2CppString* is_interned(Il2CppString* str);
    } // namespace string

    namespace thread {
        Il2CppThread* current();

        Il2CppThread* attach(Il2CppDomain* domain);

        void detach(Il2CppThread* thread);

        bool is_vm_thread(Il2CppThread* thread);
    } // namespace thread

    namespace type {
        Il2CppObject* get_object(const Il2CppType* type);

        int32_t get_type(const Il2CppType* type);

        Il2CppClass* get_class_or_element_class(const Il2CppType* type);

        char* get_name(const Il2CppType* type);

        bool is_byref(const Il2CppType* type);

        uint32_t get_attrs(const Il2CppType* type);

        bool equals(const Il2CppType* type, const Il2CppType* otherType);

        char* get_assembly_qualified_name(const Il2CppType* type);

        char* get_reflection_name(const Il2CppType* type);

        bool is_static(const Il2CppType* type);

        bool is_pointer_type(const Il2CppType* type);

        void get_name_chunked(const Il2CppType* type, void(*chunkReportFunc)(void* data, void* userData), void* userData);
    } // namespace type

    namespace image {
        const Il2CppAssembly* get_assembly(const Il2CppImage* image);

        const char* get_name(const Il2CppImage* image);

        const char* get_filename(const Il2CppImage* image);

        const MethodInfo* get_entry_point(const Il2CppImage* image);

        size_t get_class_count(const Il2CppImage* image);

        const Il2CppClass* get_class(const Il2CppImage* image, size_t index);
    } // namespace image

    namespace custom_attrs {
        Il2CppCustomAttrInfo* from_class(Il2CppClass* klass);

        Il2CppCustomAttrInfo* from_method(const MethodInfo* method);

        Il2CppCustomAttrInfo* from_field(const FieldInfo* field);

        Il2CppObject* get_attr(Il2CppCustomAttrInfo* ainfo, Il2CppClass* attr_klass);

        bool has_attr(Il2CppCustomAttrInfo* ainfo, Il2CppClass* attr_klass);

        Il2CppArray* construct(Il2CppCustomAttrInfo* cinfo);

        void free(Il2CppCustomAttrInfo* ainfo);
    } // namespace custom_attrs

    namespace stats {
        bool dump_to_file(const char* path);

        uint64_t get_value(Il2CppStat stat);
    } // namespace stats

} // namespace il2cpp

#endif // !API_FUNCTIONS_HPP