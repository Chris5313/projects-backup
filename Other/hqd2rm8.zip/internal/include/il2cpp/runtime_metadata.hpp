#ifndef RUNTIME_METADATA_HPP
#define RUNTIME_METADATA_HPP

#include <il2cpp/blob.hpp>
#include <il2cpp/metadata.hpp>

struct Il2CppClass;
struct MethodInfo;
struct Il2CppType;

typedef struct Il2CppArrayType {
    const Il2CppType* etype;
    uint8_t rank;
    uint8_t numsizes;
    uint8_t numlobounds;
    int* sizes;
    int* lobounds;
} Il2CppArrayType;

typedef struct Il2CppGenericInst {
    uint32_t type_argc;
    const Il2CppType** type_argv;
} Il2CppGenericInst;

typedef struct Il2CppGenericContext {
    const Il2CppGenericInst* class_inst;
    const Il2CppGenericInst* method_inst;
} Il2CppGenericContext;

typedef struct Il2CppGenericClass {
    const Il2CppType* type;        
    Il2CppGenericContext context;  
    Il2CppClass* cached_class;     
} Il2CppGenericClass;

typedef struct Il2CppGenericMethod {
    const MethodInfo* methodDefinition;
    Il2CppGenericContext context;
} Il2CppGenericMethod;

typedef struct Il2CppType {
    union {
        void* dummy;
        TypeDefinitionIndex __klassIndex; 
        Il2CppMetadataTypeHandle typeHandle; 
        const Il2CppType* type;   
        Il2CppArrayType* array; 
        GenericParameterIndex __genericParameterIndex; 
        Il2CppMetadataGenericParameterHandle genericParameterHandle; 
        Il2CppGenericClass* generic_class; 
    } data;
    unsigned int attrs : 16; 
    Il2CppTypeEnum type : 8;
    unsigned int num_mods : 5;  
    unsigned int byref : 1;
    unsigned int pinned : 1;  
    unsigned int valuetype : 1;
    
} Il2CppType;

typedef struct Il2CppMetadataFieldInfo {
    const Il2CppType* type;
    const char* name;
    uint32_t token;
} Il2CppMetadataFieldInfo;

typedef struct Il2CppMetadataMethodInfo {
    Il2CppMetadataMethodDefinitionHandle handle;
    const char* name;
    const Il2CppType* return_type;
    uint32_t token;
    uint16_t flags;
    uint16_t iflags;
    uint16_t slot;
    uint16_t parameterCount;
    bool isUnmangedCallersOnly;
} Il2CppMetadataMethodInfo;

typedef struct Il2CppMetadataParameterInfo {
    const char* name;
    uint32_t token;
    const Il2CppType* type;
} Il2CppMetadataParameterInfo;

typedef struct Il2CppMetadataPropertyInfo {
    const char* name;
    const MethodInfo* get;
    const MethodInfo* set;
    uint32_t attrs;
    uint32_t token;
} Il2CppMetadataPropertyInfo;

typedef struct Il2CppMetadataEventInfo {
    const char* name;
    const Il2CppType* type;
    const MethodInfo* add;
    const MethodInfo* remove;
    const MethodInfo* raise;
    uint32_t token;
} Il2CppMetadataEventInfo;

typedef struct Il2CppInterfaceOffsetInfo {
    const Il2CppType* interfaceType;
    int32_t offset;
} Il2CppInterfaceOffsetInfo;

typedef struct Il2CppGenericParameterInfo {
    Il2CppMetadataGenericContainerHandle containerHandle;
    const char* name;
    uint16_t num;
    uint16_t flags;
} Il2CppGenericParameterInfo;

#endif // !RUNTIME_METADATA_HPP