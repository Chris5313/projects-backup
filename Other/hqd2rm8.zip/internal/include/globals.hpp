#ifndef GLOBALS_HPP
#define GLOBALS_HPP

#include <Windows.h>
#include <stdint.h>
#include <atomic>
#include <il2cpp/api_wrapper.hpp>
#include <glm/glm.hpp>

namespace globals {
	extern HMODULE process;
	extern HMODULE internal;
	extern HMODULE game_assembly;
	extern HMODULE unity_player;

	extern glm::vec2 window_size;

	extern float scale;
} // namespace globals

namespace rust {
	extern std::atomic<il2cpp::api_wrapper::klass*> base_networkable;
	extern std::atomic<il2cpp::api_wrapper::klass*> base_entity;
	extern std::atomic<il2cpp::api_wrapper::klass*> base_combat_entity;
	extern std::atomic<il2cpp::api_wrapper::klass*> base_player;
	extern std::atomic<il2cpp::api_wrapper::klass*> base_npc;
	extern std::atomic<il2cpp::api_wrapper::klass*> base_vehicle;
	extern std::atomic<il2cpp::api_wrapper::klass*> base_projectile;
	extern std::atomic<il2cpp::api_wrapper::klass*> base_movement;
	extern std::atomic<il2cpp::api_wrapper::klass*> base_view_model;
	extern std::atomic<il2cpp::api_wrapper::klass*> base_melee;
	extern std::atomic<il2cpp::api_wrapper::klass*> bow_weapon;
	extern std::atomic<il2cpp::api_wrapper::klass*> flint_strike_weapon;
	extern std::atomic<il2cpp::api_wrapper::klass*> jack_hammer;
	extern std::atomic<il2cpp::api_wrapper::klass*> player_eyes;
	extern std::atomic<il2cpp::api_wrapper::klass*> player_model;
	extern std::atomic<il2cpp::api_wrapper::klass*> player_inventory;
	extern std::atomic<il2cpp::api_wrapper::klass*> player_input;
	extern std::atomic<il2cpp::api_wrapper::klass*> main_camera;
	extern std::atomic<il2cpp::api_wrapper::klass*> camera;
	extern std::atomic<il2cpp::api_wrapper::klass*> capsule_collider;
	extern std::atomic<il2cpp::api_wrapper::klass*> recoil_properties;
	extern std::atomic<il2cpp::api_wrapper::klass*> update_handler;
	extern std::atomic<il2cpp::api_wrapper::klass*> tod_sky;
} // namespace rust

#endif // !GLOBALS_HPP