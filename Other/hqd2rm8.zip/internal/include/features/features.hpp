#ifndef FEATURES_FEATURES_HPP
#define FEATURES_FEATURES_HPP

#include <globals.hpp>

namespace features {
	void aimbot();
	
	void visuals();

	void misc();
} // namespace features

#endif // !FEATURES_FEATURES_HPP