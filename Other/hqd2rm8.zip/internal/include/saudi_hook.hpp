#ifndef SAUDI_HOOK_HPP
#define SAUDI_HOOK_HPP

#include <Windows.h>
#include <stdint.h>

template <typename t>
class saudi_hook {
public:
	saudi_hook(void* hook) : m_hook(hook) {}
	~saudi_hook() = default;

	bool initialize(void** function) {
		if (!function)
			return false;

		m_function = function;
		m_original = *reinterpret_cast<t**>(function);
		return valid();
	}


	bool enable() {
		if (!valid() || m_enabled)
			return m_enabled;

		MEMORY_BASIC_INFORMATION memory_basic_information = {};
		if (!VirtualQuery(m_function, &memory_basic_information, sizeof(memory_basic_information)))
			return false;

		uint32_t original_protection = 0;
		if (!VirtualProtect(m_function, sizeof(void*), PAGE_READWRITE,
			reinterpret_cast<PDWORD>(&original_protection)))
			return false;

		_InterlockedExchangePointer(reinterpret_cast<void* volatile*>(m_function), m_hook);

		VirtualProtect(m_function, sizeof(void*), original_protection,
			reinterpret_cast<PDWORD>(&original_protection));

		return (m_enabled = true);
	}

	bool disable() {
		if (!m_enabled || !valid())
			return !m_enabled;

		MEMORY_BASIC_INFORMATION memory_basic_information = {};
		if (!VirtualQuery(m_function, &memory_basic_information, sizeof(memory_basic_information)))
			return false;

		uint32_t original_protection = 0;
		if (!VirtualProtect(m_function, sizeof(void*), PAGE_READWRITE,
			reinterpret_cast<PDWORD>(&original_protection)))
			return false;

		_InterlockedExchangePointer(reinterpret_cast<void* volatile*>(m_function), m_original);

		VirtualProtect(m_function, sizeof(void*), original_protection,
			reinterpret_cast<PDWORD>(&original_protection));

		return (m_enabled = false);
	}

	bool valid() const {
		return m_hook && m_original && m_function;
	}

	t* original() const {
		return m_original;
	}
private:
	bool m_enabled = false;
	void* m_hook = nullptr;
	t* m_original = nullptr;
	void** m_function = nullptr;
};

#endif // !SAUDI_HOOK_HPP