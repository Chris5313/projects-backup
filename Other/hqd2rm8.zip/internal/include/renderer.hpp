#ifndef RENDERER_HPP
#define RENDERER_HPP

#include <Windows.h>
#include <atomic>
#include <d3d11.h>
#include <imgui/imgui.hpp>
#include <imgui/imgui_impl_dx11.hpp>
#include <imgui/imgui_impl_win32.hpp>

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, 
	LPARAM lParam);

namespace renderer {
	extern std::atomic<bool> initialized;
	extern HWND output_window;
	extern ID3D11Device* device;
	extern ID3D11DeviceContext* device_context;
	extern ID3D11RenderTargetView* render_target;
	extern WNDPROC o_window_proc;

	void create_render_target(IDXGISwapChain* swap_chain);

	void release_render_target();

	void on_present_hk(IDXGISwapChain* swap_chain, uint32_t sync_interval, uint32_t flags);

	void on_resize_buffers_hk();

	LRESULT on_window_proc(HWND hwnd, uint32_t message, uint64_t w_param, uint64_t l_param);

	void begin_frame();

	void end_frame();

	void cleanup();

	bool key_pressed(const uint32_t virtual_key, const bool check_held);

	bool key_pressed(const uint32_t virtual_key);
} // namespace renderer

#endif // !RENDERER_HPP