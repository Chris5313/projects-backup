#ifndef HOOKS_HOOKS_HPP
#define HOOKS_HOOKS_HPP

#include <Windows.h>
#include <stdint.h>
#include <globals.hpp>
#include <il2cpp/api_wrapper.hpp>
#include <game.hpp>
#include <saudi_hook.hpp>
#include <d3d11.h>

namespace hooks {
	namespace swap_chain {
		HRESULT present_hk(IDXGISwapChain* swap_chain, uint32_t sync_interval, uint32_t flags);

		extern saudi_hook<decltype(present_hk)> present;

		HRESULT resize_buffers_hk(IDXGISwapChain* swap_chain, uint32_t buffer_count, uint32_t width,
			uint32_t height,
			DXGI_FORMAT new_format,
			uint32_t swap_chain_flags);

		extern saudi_hook<decltype(resize_buffers_hk)> resize_buffers;
	} // namespace swap_chain

	namespace update_handler {
		void update_hk(void* __this, const MethodInfo* method);

		extern saudi_hook<decltype(update_hk)> update;
	} // namespace update_handler

	namespace base_melee {
		void do_attack_hk(void* __this, const MethodInfo* method);

		extern saudi_hook<decltype(do_attack_hk)> do_attack;
	} // namespace base_melee

	namespace base_projectile {
		void do_attack_hk(void* __this, const MethodInfo* method);

		extern saudi_hook<decltype(do_attack_hk)> do_attack;
	} // namespace base_projectile

	namespace bow_weapon {
		void do_attack_hk(void* __this, const MethodInfo* method);

		extern saudi_hook<decltype(do_attack_hk)> do_attack;
	} // namespace bow_weapon

	namespace flint_strike_weapon {
		void do_attack_hk(void* __this, const MethodInfo* method);

		extern saudi_hook<decltype(do_attack_hk)> do_attack;
	} // namespace flint_strike_weapon

	namespace jack_hammer {
		void do_attack_hk(void* __this, const MethodInfo* method);

		extern saudi_hook<decltype(do_attack_hk)> do_attack;
	} // namespace jack_hammer

	namespace tod_sky {
		void late_update_hk(void* __this, const MethodInfo* method);

		extern saudi_hook<decltype(late_update_hk)> late_update;
	} // namespace tod_sky

	bool initialize();

	void cleanup();
} // namespace hooks

#endif // !HOOKS_HOOKS_HPP