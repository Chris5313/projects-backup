#include <il2cpp/api_wrapper.hpp>

namespace il2cpp::api_wrapper {
    bool valid(void* __this) {
        return (__this);
    }

    bool valid(const void* __this) {
        return (__this);
    }

    /* TYPE */

    object* type::get_object() const {
        if (!valid(this))
            return {};

        return (object*)il2cpp::type::get_object(il2cpp());
    }

    int32_t il2cpp::api_wrapper::type::get_type() const {
        if (!valid(this))
            return {};

        return il2cpp::type::get_type(il2cpp());
    }

    klass* type::get_class_or_element_class(type* type) const {
        if (!valid(this))
            return {};

        return (klass*)il2cpp::type::get_class_or_element_class(il2cpp());
    }

    std::string_view type::get_name() const {
        if (!valid(this))
            return {};

        return il2cpp::type::get_name(il2cpp());
    }

    bool type::is_byref() const {
        if (!valid(this))
            return {};

        return il2cpp::type::is_byref(il2cpp());
    }

    uint32_t type::get_attributes() const {
        if (!valid(this))
            return {};

        return il2cpp::type::get_attrs(il2cpp());
    }

    bool type::equals(type* type) {
        if (!valid(this))
            return {};

        return il2cpp::type::equals(il2cpp(), (const Il2CppType*)type);
    }

    std::string_view type::get_assembly_qualified_name() const {
        if (!valid(this))
            return {};

        return il2cpp::type::get_assembly_qualified_name(il2cpp());
    }

    std::string_view type::get_reflection_name() const {
        if (!valid(this))
            return {};

        return il2cpp::type::get_reflection_name(il2cpp());
    }

    bool type::is_static() const {
        if (!valid(this))
            return {};

        return il2cpp::type::is_static(il2cpp());
    }

    bool type::is_pointer_type() const {
        if (!valid(this))
            return {};

        return il2cpp::type::is_pointer_type(il2cpp());
    }

    Il2CppType* type::il2cpp() const {
        return (Il2CppType*)this;
    }

    /* FIELD */

    int32_t field::get_flags() const {
        if (!valid(this))
            return {};

        return il2cpp::field::get_flags(il2cpp());
    }

    std::string_view field::get_name() const {
        if (!valid(this))
            return {};

        return il2cpp::field::get_name(il2cpp());
    }

    klass* field::get_parent() const {
        if (!valid(this))
            return {};

        return (klass*)il2cpp::field::get_parent(il2cpp());
    }

    uint64_t field::get_offset() const {
        if (!valid(this))
            return {};

        return il2cpp::field::get_offset(il2cpp());
    }

    type* field::get_type() const {
        if (!valid(this))
            return {};

        return (type*)il2cpp::field::get_type(il2cpp());
    }

    bool field::is_static() const {
        if (!valid(this))
            return {};

        return (get_flags() & FIELD_ATTRIBUTE_STATIC);
    }

    bool field::has_attribute(klass* klass) const {
        if (!valid(this))
            return {};

        return il2cpp::field::has_attribute(il2cpp(), (Il2CppClass*)klass);
    }

    void field::get_value(object* object, void* value) const {
        if (!valid(this) || !object || !value)
            return;

        if (is_static())
            return;

        il2cpp::field::get_value(object->il2cpp(), il2cpp(), value);
    }

    void field::set_value(object* object, void* value) const {
        if (!valid(this) || !object || !value)
            return;

        if (is_static())
            return;

        il2cpp::field::set_value(object->il2cpp(), il2cpp(), value);
    }

    void field::static_get_value(void* value) const {
        if (!valid(this) || !value)
            return;

        il2cpp::field::static_get_value(il2cpp(), value);
    }

    void field::static_set_value(void* value) const {
        if (!valid(this) || !value)
            return;

        il2cpp::field::static_set_value(il2cpp(), value);
    }

    FieldInfo* field::il2cpp() const {
        return (FieldInfo*)this;
    }

    /* METHOD */

    type* method::get_return_type() const {
        if (!valid(this))
            return {};

        return (type*)il2cpp::method::get_return_type(il2cpp());
    }

    std::string_view method::get_name() const {
        if (!valid(this))
            return {};

        return il2cpp::method::get_name(il2cpp());
    }

    bool method::is_generic() const {
        if (!valid(this))
            return {};

        return il2cpp::method::is_generic(il2cpp());
    }

    bool method::is_inflated() const {
        if (!valid(this))
            return {};

        return il2cpp::method::is_inflated(il2cpp());
    }

    bool method::is_instance() const {
        if (!valid(this))
            return {};

        return il2cpp::method::is_instance(il2cpp());
    }

    bool method::is_virtual() const {
        if (!valid(this))
            return {};

        return (il2cpp()->flags & METHOD_ATTRIBUTE_VIRTUAL);
    }

    uint32_t method::get_param_count() const {
        if (!valid(this))
            return {};

        return il2cpp::method::get_param_count(il2cpp());
    }

    type* method::get_param_type(uint32_t idx) const {
        if (!valid(this))
            return {};

        return (type*)il2cpp::method::get_param(il2cpp(), idx);
    }

    klass* method::get_class() const {
        if (!valid(this))
            return {};

        return (klass*)il2cpp::method::get_class(il2cpp());
    }

    bool method::has_attribute(klass* klass) const {
        if (!valid(this))
            return {};

        return il2cpp::method::has_attribute(il2cpp(), (Il2CppClass*)klass);
    }

    std::string_view method::get_param_name(uint32_t idx) const {
        if (!valid(this))
            return {};

        return il2cpp::method::get_param_name(il2cpp(), idx);
    }

    void* method::get_method_address() const {
        if (!valid(this))
            return {};

        if (!is_virtual())
            return il2cpp()->methodPointer;

        const auto slot = il2cpp()->slot;
        if (il2cpp()->klass && il2cpp()->klass->vtable)
            return il2cpp()->klass->vtable[slot].methodPtr;

        return nullptr;
    }

    void** method::get_method_pointer() const {
        if (!valid(this)) {
            printf("badclass\n");

            return {};
        }
        if (!is_virtual()) {
            printf("non virtual\n");
            return reinterpret_cast<void**>(&il2cpp()->methodPointer);
        }

        const auto slot = il2cpp()->slot;
        if (il2cpp()->klass->vtable) {
            printf("virtual\n");
            return reinterpret_cast<void**>(&il2cpp()->klass->vtable[slot].methodPtr);
        }

        printf("bad\n");
        return nullptr;
    }

    object* method::invoke(object* object, void** params, Il2CppException** exception) const {
        if (!valid(this))
            return {};

        return (struct object*)il2cpp::runtime::invoke(il2cpp(), object, params,
            exception);
    }

    MethodInfo* method::il2cpp() const {
        return (MethodInfo*)this;
    }

    /* KLASS */

    void* klass::get_vtable() const {
        if (!valid(this))
            return {};

        return (il2cpp())->vtable;
    }

    uint64_t klass::get_vtable_size() const {
        if (!valid(this))
            return {};

        return (il2cpp())->vtable_count;
    }

    bool klass::is_inited() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::is_inited(il2cpp());
    }

    bool klass::is_generic() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::is_generic(il2cpp());
    }

    bool klass::is_inflated() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::is_inflated(il2cpp());
    }

    bool klass::is_abstract() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::is_abstract(il2cpp());
    }

    bool klass::is_interface() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::is_interface(il2cpp());
    }

    bool klass::is_enum() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::is_enum(il2cpp());
    }

    bool klass::has_attribute(klass* klass) const {
        if (!valid(this))
            return {};

        return il2cpp::klass::has_attribute(il2cpp(), (Il2CppClass*)klass);
    }

    bool klass::has_references() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::has_references(il2cpp());
    }

    std::vector<klass*> klass::get_nested_types() const {
        if (!valid(this))
            return {};

        std::vector<klass*> result;

        void* iter = nullptr;
        while (auto* klass = il2cpp::klass::get_nested_types(il2cpp(), &iter))
            result.push_back((struct klass*)klass);

        return result;
    }

    std::vector<klass*> klass::get_interfaces() const {
        if (!valid(this))
            return {};

        std::vector<klass*> result;

        void* iter = nullptr;
        while (auto* klass = il2cpp::klass::get_interfaces(il2cpp(), &iter))
            result.push_back((struct klass*)klass);

        return result;
    }

    std::vector<field*> klass::get_fields() const {
        if (!valid(this))
            return {};

        std::vector<field*> result;

        void* iter = nullptr;
        while (auto* field = il2cpp::klass::get_fields(il2cpp(), &iter))
            result.push_back((struct field*)field);

        return result;
    }

    field* klass::get_field_from_name(std::string_view field_name) const {
        if (!valid(this))
            return {};

        return (field*)il2cpp::klass::get_field_from_name(il2cpp(), field_name.data());
    }

    std::vector<method*> klass::get_methods() const {
        if (!valid(this))
            return {};

        std::vector<method*> result;

        void* iter = nullptr;
        while (auto* method = il2cpp::klass::get_methods(il2cpp(), &iter))
            result.push_back((struct method*)method);

        return result;
    }

    method* klass::get_method_from_name(std::string_view method_name, int32_t argument_count) const {
        if (!valid(this))
            return {};

        return (method*)il2cpp::klass::get_method_from_name(il2cpp(), method_name.data(), argument_count);
    }

    method* klass::get_method_from_name(std::string_view method_name) const {
        if (!valid(this))
            return {};

        return (method*)il2cpp::klass::get_method_from_name(il2cpp(), method_name.data(), 0);
    }

    std::string_view klass::get_name() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::get_name(il2cpp());
    }

    std::string_view klass::get_namespace() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::get_namespace(il2cpp());
    }

    klass* klass::get_parent() const {
        if (!valid(this))
            return {};

        return (klass*)il2cpp::klass::get_parent(il2cpp());
    }

    int32_t klass::get_flags() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::get_flags(il2cpp());
    }

    type* klass::get_type() const {
        if (!valid(this))
            return {};

        return (type*)il2cpp::klass::get_type(il2cpp());
    }

    image* klass::get_image() const {
        if (!valid(this))
            return {};

        return (image*)il2cpp::klass::get_image(il2cpp());
    }

    std::string_view klass::get_assembly_name() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::get_assemblyname(il2cpp());
    }

    void* klass::get_static_field_data() const {
        if (!valid(this))
            return {};

        return il2cpp::klass::get_static_field_data(il2cpp());
    }

    Il2CppClass* klass::il2cpp() const {
        return (Il2CppClass*)this;
    }

    /* IMAGE */

    std::string_view image::get_name() const {
        if (!valid(this))
            return {};

        return il2cpp::image::get_name(il2cpp());
    }

    std::string_view image::get_file_name() const {
        if (!valid(this))
            return {};

        return il2cpp::image::get_filename(il2cpp());
    }

    std::vector<klass*> image::get_classes() const {
        if (!valid(this))
            return {};

        std::vector<klass*> result;

        const auto class_count = il2cpp::image::get_class_count(il2cpp());
        for (auto idx = 0; idx < class_count; idx++)
            if (auto* klass = il2cpp::image::get_class(il2cpp(), idx))
                result.push_back((struct klass*)klass);

        return result;
    }

    klass* image::get_class(std::string_view class_name) const {
        if (!valid(this))
            return {};

        const auto classes = get_classes();
        for (auto* klass : classes)
            if (klass->get_name() == class_name)
                return klass;

        return nullptr;
    }

    Il2CppImage* image::il2cpp() const {
        return (Il2CppImage*)this;
    }

    /* OBJECT */

    Il2CppObject* object::il2cpp() const {
        return (Il2CppObject*)this;
    }

    /* UTILS */

    klass* find_class(std::string_view namespace_name, std::string_view class_name) {
        uint64_t count = 0;
        const auto** assemblies = il2cpp::domain::get_assemblies(il2cpp::domain::get(), &count);
        for (auto idx = 0; idx < count; idx++) {
            auto* image = (struct image*)il2cpp::assembly::get_image(assemblies[idx]);
            if (!image)
                continue;

            const auto& classes = image->get_classes();
            for (const auto& klass : classes) {
                if (!klass->is_inited())
                    il2cpp::runtime::class_init(klass->il2cpp());

                if (klass->get_name() == class_name && klass->get_namespace() == namespace_name)
                    return klass;
            }
        }

        return nullptr;
    }

    klass* find_class(std::string_view class_name) {
        uint64_t count = 0;
        const auto** assemblies = il2cpp::domain::get_assemblies(il2cpp::domain::get(), &count);
        for (auto idx = 0; idx < count; idx++) {
            auto* image = (struct image*)il2cpp::assembly::get_image(assemblies[idx]);
            if (!image)
                continue;

            const auto& classes = image->get_classes();
            for (const auto& klass : classes) {
                if (!klass->is_inited())
                    il2cpp::runtime::class_init(klass->il2cpp());

                if (klass->get_name() == class_name)
                    return klass;
            }
        }

        return nullptr;
    }

    klass* find_nested_class(std::string_view namespace_name, std::string_view class_name, std::string_view nested_name) {
        auto* klass = find_class(namespace_name, class_name);
        if (!klass)
            return nullptr;

        const auto nested_types = klass->get_nested_types();
        if (nested_types.empty())
            return nullptr;

        for (const auto& nested_type : nested_types)
            if (nested_type->get_name() == nested_name)
                return nested_type;

        return nullptr;
    }

    klass* find_nested_class(std::string_view class_name, std::string_view nested_name) {
        auto* klass = find_class(class_name);
        if (!klass)
            return nullptr;

        const auto nested_types = klass->get_nested_types();
        if (nested_types.empty())
            return nullptr;

        for (const auto& nested_type : nested_types)
            if (nested_type->get_name() == nested_name)
                return nested_type;

        return nullptr;
    }


    method* find_method(std::string_view namespace_name, std::string_view class_name, std::string_view method_name,
        int32_t argument_count) {
        auto* klass = find_class(namespace_name, class_name);
        if (!klass)
            return nullptr;

        return klass->get_method_from_name(method_name, argument_count);
    }

    method* find_method(std::string_view namespace_name, std::string_view class_name, std::string_view method_name) {
        return find_method(namespace_name, class_name, method_name, 
            0);
    }

    method* find_method(std::string_view class_name, std::string_view method_name, int32_t argument_count) {
        auto* klass = find_class(class_name);
        if (!klass)
            return nullptr;

        return klass->get_method_from_name(method_name, argument_count);
    }

    method* find_method(std::string_view class_name, std::string_view method_name) {
        return find_method(class_name, method_name, 0);
    }
} // namespace il2cpp::api_wrapper