#include <il2cpp/api_functions.hpp>

namespace il2cpp {
    HMODULE game_assembly = nullptr;

    namespace init {
        int32_t init(const char* domain_name) {
            static decltype(&init) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_init"));

            return function(domain_name);
        }

        int32_t init_utf16(const Il2CppChar* domain_name) {
            static decltype(&init_utf16) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_init_utf16"));

            return function(domain_name);
        }

        void shutdown() {
            static decltype(&shutdown) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_shutdown"));

            function();
        }
    } // namespace init

    namespace config {
        void set_config_dir(const char* config_path) {
            static decltype(&set_config_dir) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_set_config_dir"));

            function(config_path);
        }

        void set_data_dir(const char* data_path) {
            static decltype(&set_data_dir) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_set_data_dir"));

            function(data_path);
        }

        void set_temp_dir(const char* temp_path) {
            static decltype(&set_temp_dir) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_set_temp_dir"));

            function(temp_path);
        }

        void set_commandline_arguments(int32_t argc, const char* const argv[], const char* basedir) {
            static decltype(&set_commandline_arguments) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_set_commandline_arguments"));

            function(argc, argv, basedir);
        }

        void set_commandline_arguments_utf16(int32_t argc, const Il2CppChar* const argv[], const char* basedir) {
            static decltype(&set_commandline_arguments_utf16) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_set_commandline_arguments_utf16"));

            function(argc, argv, basedir);
        }

        void set_config_utf16(const Il2CppChar* executablePath) {
            static decltype(&set_config_utf16) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_set_config_utf16"));

            function(executablePath);
        }

        void set_config(const char* executablePath) {
            static decltype(&set_config) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_set_config"));

            function(executablePath);
        }

        void set_memory_callbacks(Il2CppMemoryCallbacks* callbacks) {
            static decltype(&set_memory_callbacks) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_set_memory_callbacks"));

            function(callbacks);
        }
    } // namespace config

    namespace memory {
        void* alloc(size_t size) {
            static decltype(&alloc) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_alloc"));

            return function(size);
        }

        void free(void* ptr) {
            static decltype(&free) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_free"));

            function(ptr);
        }

        void* gc_alloc_fixed(size_t size) {
            static decltype(&gc_alloc_fixed) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_alloc_fixed"));

            return function(size);
        }

        void gc_free_fixed(void* address) {
            static decltype(&gc_free_fixed) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_free_fixed"));

            function(address);
        }
    } // namespace memory

    namespace icall {
        void add_internal_call(const char* name, Il2CppMethodPointer method) {
            static decltype(&add_internal_call) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_add_internal_call"));

            function(name, method);
        }

        Il2CppMethodPointer resolve_icall(const char* name) {
            static decltype(&resolve_icall) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_resolve_icall"));

            return function(name);
        }
    } // namespace icall

    namespace core {
        const Il2CppImage* get_corlib() {
            static decltype(&get_corlib) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_get_corlib"));

            return function();
        }
    } // namespace core

    namespace array {
        Il2CppClass* class_get(Il2CppClass* element_class, uint32_t rank) {
            static decltype(&class_get) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_array_class_get"));

            return function(element_class, rank);
        }

        uint32_t length(Il2CppArray* array) {
            static decltype(&length) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_array_length"));

            return function(array);
        }

        uint32_t get_byte_length(Il2CppArray* array) {
            static decltype(&get_byte_length) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_array_get_byte_length"));

            return function(array);
        }

        Il2CppArray* new_array(Il2CppClass* elementTypeInfo, il2cpp_array_size_t length) {
            static decltype(&new_array) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_array_new"));

            return function(elementTypeInfo, length);
        }

        Il2CppArray* new_specific(Il2CppClass* arrayTypeInfo, il2cpp_array_size_t length) {
            static decltype(&new_specific) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_array_new_specific"));

            return function(arrayTypeInfo, length);
        }

        Il2CppArray* new_full(Il2CppClass* array_class, il2cpp_array_size_t* lengths, il2cpp_array_size_t* lower_bounds) {
            static decltype(&new_full) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_array_new_full"));

            return function(array_class, lengths, lower_bounds);
        }

        Il2CppClass* bounded_class_get(Il2CppClass* element_class, uint32_t rank, bool bounded) {
            static decltype(&bounded_class_get) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_bounded_array_class_get"));

            return function(element_class, rank, bounded);
        }

        int32_t element_size(const Il2CppClass* array_class) {
            static decltype(&element_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_array_element_size"));

            return function(array_class);
        }
    } // namespace array

    namespace assembly {
        const Il2CppImage* get_image(const Il2CppAssembly* assembly) {
            static decltype(&get_image) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_assembly_get_image"));

            return function(assembly);
        }
    } // namespace assembly

    namespace klass {
        void for_each(void(*klassReportFunc)(Il2CppClass* klass, void* userData), void* userData) {
            static decltype(&for_each) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_for_each"));

            function(klassReportFunc, userData);
        }

        const Il2CppType* enum_basetype(Il2CppClass* klass) {
            static decltype(&enum_basetype) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_enum_basetype"));

            return function(klass);
        }

        bool is_inited(const Il2CppClass* klass) {
            static decltype(&is_inited) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_inited"));

            return function(klass);
        }

        bool is_generic(const Il2CppClass* klass) {
            static decltype(&is_generic) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_generic"));

            return function(klass);
        }

        bool is_inflated(const Il2CppClass* klass) {
            static decltype(&is_inflated) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_inflated"));

            return function(klass);
        }

        bool is_assignable_from(Il2CppClass* klass, Il2CppClass* oklass) {
            static decltype(&is_assignable_from) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_assignable_from"));

            return function(klass, oklass);
        }

        bool is_subclass_of(Il2CppClass* klass, Il2CppClass* klassc, bool check_interfaces) {
            static decltype(&is_subclass_of) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_subclass_of"));

            return function(klass, klassc, check_interfaces);
        }

        bool has_parent(Il2CppClass* klass, Il2CppClass* klassc) {
            static decltype(&has_parent) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_has_parent"));

            return function(klass, klassc);
        }

        Il2CppClass* from_il2cpp_type(const Il2CppType* type) {
            static decltype(&from_il2cpp_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_from_il2cpp_type"));

            return function(type);
        }

        Il2CppClass* from_name(const Il2CppImage* image, const char* namespaze, const char* name) {
            static decltype(&from_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_from_name"));

            return function(image, namespaze, name);
        }

        Il2CppClass* from_system_type(Il2CppReflectionType* type) {
            static decltype(&from_system_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_from_system_type"));

            return function(type);
        }

        Il2CppClass* get_element_class(Il2CppClass* klass) {
            static decltype(&get_element_class) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_element_class"));

            return function(klass);
        }

        const EventInfo* get_events(Il2CppClass* klass, void** iter) {
            static decltype(&get_events) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_events"));

            return function(klass, iter);
        }

        FieldInfo* get_fields(Il2CppClass* klass, void** iter) {
            static decltype(&get_fields) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_fields"));

            return function(klass, iter);
        }

        Il2CppClass* get_nested_types(Il2CppClass* klass, void** iter) {
            static decltype(&get_nested_types) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_nested_types"));

            return function(klass, iter);
        }

        Il2CppClass* get_interfaces(Il2CppClass* klass, void** iter) {
            static decltype(&get_interfaces) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_interfaces"));

            return function(klass, iter);
        }

        const PropertyInfo* get_properties(Il2CppClass* klass, void** iter) {
            static decltype(&get_properties) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_properties"));

            return function(klass, iter);
        }

        const PropertyInfo* get_property_from_name(Il2CppClass* klass, const char* name) {
            static decltype(&get_property_from_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_property_from_name"));

            return function(klass, name);
        }

        FieldInfo* get_field_from_name(Il2CppClass* klass, const char* name) {
            static decltype(&get_field_from_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_field_from_name"));

            return function(klass, name);
        }

        const MethodInfo* get_methods(Il2CppClass* klass, void** iter) {
            static decltype(&get_methods) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_methods"));

            return function(klass, iter);
        }

        const MethodInfo* get_method_from_name(Il2CppClass* klass, const char* name, int32_t argsCount) {
            static decltype(&get_method_from_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_method_from_name"));

            return function(klass, name, argsCount);
        }

        const char* get_name(Il2CppClass* klass) {
            static decltype(&get_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_name"));

            return function(klass);
        }

        const char* get_namespace(Il2CppClass* klass) {
            static decltype(&get_namespace) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_namespace"));

            return function(klass);
        }

        Il2CppClass* get_parent(Il2CppClass* klass) {
            static decltype(&get_parent) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_parent"));

            return function(klass);
        }

        Il2CppClass* get_declaring_type(Il2CppClass* klass) {
            static decltype(&get_declaring_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_declaring_type"));

            return function(klass);
        }

        int32_t instance_size(Il2CppClass* klass) {
            static decltype(&instance_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_instance_size"));

            return function(klass);
        }

        size_t num_fields(const Il2CppClass* enumKlass) {
            static decltype(&num_fields) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_num_fields"));

            return function(enumKlass);
        }

        bool is_valuetype(const Il2CppClass* klass) {
            static decltype(&is_valuetype) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_valuetype"));

            return function(klass);
        }

        int32_t value_size(Il2CppClass* klass, uint32_t* align) {
            static decltype(&value_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_value_size"));

            return function(klass, align);
        }

        bool is_blittable(const Il2CppClass* klass) {
            static decltype(&is_blittable) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_blittable"));

            return function(klass);
        }

        int32_t get_flags(const Il2CppClass* klass) {
            static decltype(&get_flags) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_flags"));

            return function(klass);
        }

        bool is_abstract(const Il2CppClass* klass) {
            static decltype(&is_abstract) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_abstract"));

            return function(klass);
        }

        bool is_interface(const Il2CppClass* klass) {
            static decltype(&is_interface) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_interface"));
            
            return function(klass);
        }

        int32_t array_element_size(const Il2CppClass* klass) {
            static decltype(&array_element_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_array_element_size"));

            return function(klass);
        }

        Il2CppClass* from_type(const Il2CppType* type) {
            static decltype(&from_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_from_type"));

            return function(type);
        }

        const Il2CppType* get_type(Il2CppClass* klass) {
            static decltype(&get_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_type"));

            return function(klass);
        }

        uint32_t get_type_token(Il2CppClass* klass) {
            static decltype(&get_type_token) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_type_token"));

            return function(klass);
        }

        bool has_attribute(Il2CppClass* klass, Il2CppClass* attr_class) {
            static decltype(&has_attribute) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_has_attribute"));

            return function(klass, attr_class);
        }

        bool has_references(Il2CppClass* klass) {
            static decltype(&has_references) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_has_references"));

            return function(klass);
        }

        bool is_enum(const Il2CppClass* klass) {
            static decltype(&is_enum) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_is_enum"));

            return function(klass);
        }

        const Il2CppImage* get_image(Il2CppClass* klass) {
            static decltype(&get_image) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_image"));

            return function(klass);
        }

        const char* get_assemblyname(const Il2CppClass* klass) {
            static decltype(&get_assemblyname) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_assemblyname"));

            return function(klass);
        }

        int32_t get_rank(const Il2CppClass* klass) {
            static decltype(&get_rank) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_rank"));

            return function(klass);
        }

        uint32_t get_data_size(const Il2CppClass* klass) {
            static decltype(&get_data_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_data_size"));

            return function(klass);
        }

        void* get_static_field_data(const Il2CppClass* klass) {
            static decltype(&get_static_field_data) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_static_field_data"));

            return function(klass);
        }

        size_t get_bitmap_size(const Il2CppClass* klass) {
            static decltype(&get_bitmap_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_bitmap_size"));

            return function(klass);
        }

        void get_bitmap(Il2CppClass* klass, size_t* bitmap) {
            static decltype(&get_bitmap) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_class_get_bitmap"));

            function(klass, bitmap);
        }
    } // namespace klass

    namespace domain {
        Il2CppDomain* get() {
            static decltype(&get) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_domain_get"));

            return function();
        }

        const Il2CppAssembly* assembly_open(Il2CppDomain* domain, const char* name) {
            static decltype(&assembly_open) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_domain_assembly_open"));

            return function(domain, name);
        }

        const Il2CppAssembly** get_assemblies(const Il2CppDomain* domain, size_t* size) {
            static decltype(&get_assemblies) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_domain_get_assemblies"));

            return function(domain, size);
        }
    } // namespace domain

    namespace exception {
        void raise(Il2CppException* exc) {
            static decltype(&raise) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_raise_exception"));

            function(exc);
        }

        Il2CppException* from_name_msg(const Il2CppImage* image, const char* name_space, const char* name, const char* msg) {
            static decltype(&from_name_msg) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_exception_from_name_msg"));

            return function(image, name_space, name, msg);
        }

        Il2CppException* get_argument_null(const char* arg) {
            static decltype(&get_argument_null) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_get_exception_argument_null"));

            return function(arg);
        }

        void format(const Il2CppException* ex, char* message, int32_t message_size) {
            static decltype(&format) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_format_exception"));

            function(ex, message, message_size);
        }

        void format_stack_trace(const Il2CppException* ex, char* output, int32_t output_size) {
            static decltype(&format_stack_trace) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_format_stack_trace"));

            function(ex, output, output_size);
        }

        void unhandled(Il2CppException* exc) {
            static decltype(&unhandled) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_unhandled_exception"));

            function(exc);
        }

        void native_stack_trace(const Il2CppException* ex, uintptr_t** addresses, int32_t* numFrames, char** imageUUID, char** imageName) {
            static decltype(&native_stack_trace) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_native_stack_trace"));

            function(ex, addresses, numFrames, imageUUID, imageName);
        }
    } // namespace exception

    namespace field {
        int32_t get_flags(FieldInfo* field) {
            static decltype(&get_flags) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_get_flags"));

            return function(field);
        }

        const FieldInfo* get_from_reflection(const Il2CppReflectionField* field) {
            static decltype(&get_from_reflection) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_get_from_reflection"));

            return function(field);
        }

        const char* get_name(FieldInfo* field) {
            static decltype(&get_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_get_name"));

            return function(field);
        }

        Il2CppClass* get_parent(FieldInfo* field) {
            static decltype(&get_parent) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_get_parent"));

            return function(field);
        }

        Il2CppReflectionField* get_object(FieldInfo* field, Il2CppClass* refclass) {
            static decltype(&get_object) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_get_object"));

            return function(field, refclass);
        }

        size_t get_offset(FieldInfo* field) {
            static decltype(&get_offset) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_get_offset"));

            return function(field);
        }

        const Il2CppType* get_type(FieldInfo* field) {
            static decltype(&get_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_get_type"));

            return function(field);
        }

        void get_value(Il2CppObject* obj, FieldInfo* field, void* value) {
            static decltype(&get_value) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_get_value"));

            function(obj, field, value);
        }

        Il2CppObject* get_value_object(FieldInfo* field, Il2CppObject* obj) {
            static decltype(&get_value_object) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_get_value_object"));

            return function(field, obj);
        }

        bool has_attribute(FieldInfo* field, Il2CppClass* attr_class) {
            static decltype(&has_attribute) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_has_attribute"));

            return function(field, attr_class);
        }

        void set_value(Il2CppObject* obj, FieldInfo* field, void* value) {
            static decltype(&set_value) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_set_value"));

            function(obj, field, value);
        }

        void static_get_value(FieldInfo* field, void* value) {
            static decltype(&static_get_value) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_static_get_value"));

            function(field, value);
        }

        void static_set_value(FieldInfo* field, void* value) {
            static decltype(&static_set_value) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_static_set_value"));

            function(field, value);
        }

        void set_value_object(Il2CppObject* instance, FieldInfo* field, Il2CppObject* value) {
            static decltype(&set_value_object) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_set_value_object"));

            function(instance, field, value);
        }

        bool is_literal(FieldInfo* field) {
            static decltype(&is_literal) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_field_is_literal"));

            return function(field);
        }
    } // namespace field

    namespace gc {
        void collect(int32_t maxGenerations) {
            static decltype(&collect) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_collect"));

            function(maxGenerations);
        }

        int32_t collect_a_little() {
            static decltype(&collect_a_little) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_collect_a_little"));

            return function();
        }

        void start_incremental_collection() {
            static decltype(&start_incremental_collection) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_start_incremental_collection"));

            function();
        }

        void disable() {
            static decltype(&disable) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_disable"));

            function();
        }

        void enable() {
            static decltype(&enable) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_enable"));

            function();
        }

        bool is_disabled() {
            static decltype(&is_disabled) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_is_disabled"));

            return function();
        }

        void set_mode(Il2CppGCMode mode) {
            static decltype(&set_mode) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_set_mode"));

            function(mode);
        }

        int64_t get_max_time_slice_ns() {
            static decltype(&get_max_time_slice_ns) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_get_max_time_slice_ns"));

            return function();
        }

        void set_max_time_slice_ns(int64_t maxTimeSlice) {
            static decltype(&set_max_time_slice_ns) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_set_max_time_slice_ns"));

            function(maxTimeSlice);
        }

        bool is_incremental() {
            static decltype(&is_incremental) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_is_incremental"));

            return function();
        }

        int64_t get_used_size() {
            static decltype(&get_used_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_get_used_size"));

            return function();
        }

        int64_t get_heap_size() {
            static decltype(&get_heap_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_get_heap_size"));

            return function();
        }

        void wbarrier_set_field(Il2CppObject* obj, void** targetAddress, void* object) {
            static decltype(&wbarrier_set_field) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_wbarrier_set_field"));

            function(obj, targetAddress, object);
        }

        bool has_strict_wbarriers() {
            static decltype(&has_strict_wbarriers) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_has_strict_wbarriers"));

            return function();
        }

        void set_external_allocation_tracker(void(*func)(void*, size_t, int32_t)) {
            static decltype(&set_external_allocation_tracker) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_set_external_allocation_tracker"));

            function(func);
        }

        void set_external_wbarrier_tracker(void(*func)(void**)) {
            static decltype(&set_external_wbarrier_tracker) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_set_external_wbarrier_tracker"));

            function(func);
        }

        void foreach_heap(void(*func)(void* data, void* userData), void* userData) {
            static decltype(&foreach_heap) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gc_foreach_heap"));

            function(func, userData);
        }

        void stop_gc_world() {
            static decltype(&stop_gc_world) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_stop_gc_world"));

            function();
        }

        void start_gc_world() {
            static decltype(&start_gc_world) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_start_gc_world"));

            function();
        }
    } // namespace gc

    namespace gchandle {
        Il2CppGCHandle new_handle(Il2CppObject* obj, bool pinned) {
            static decltype(&new_handle) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gchandle_new"));

            return function(obj, pinned);
        }

        Il2CppGCHandle new_weakref(Il2CppObject* obj, bool track_resurrection) {
            static decltype(&new_weakref) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gchandle_new_weakref"));

            return function(obj, track_resurrection);
        }

        Il2CppObject* get_target(Il2CppGCHandle gchandle) {
            static decltype(&get_target) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gchandle_get_target"));

            return function(gchandle);
        }

        void free(Il2CppGCHandle gchandle) {
            static decltype(&free) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gchandle_free"));

            function(gchandle);
        }

        void foreach_get_target(void(*func)(void* data, void* userData), void* userData) {
            static decltype(&foreach_get_target) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_gchandle_foreach_get_target"));

            function(func, userData);
        }
    } // namespace gchandle

    namespace object {
        uint32_t header_size() {
            static decltype(&header_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_object_header_size"));

            return function();
        }

        uint32_t array_header_size() {
            static decltype(&array_header_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_array_object_header_size"));

            return function();
        }

        uint32_t offset_of_array_length_in_header() {
            static decltype(&offset_of_array_length_in_header) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_offset_of_array_length_in_array_object_header"));

            return function();
        }

        uint32_t offset_of_array_bounds_in_header() {
            static decltype(&offset_of_array_bounds_in_header) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_offset_of_array_bounds_in_array_object_header"));

            return function();
        }

        uint32_t allocation_granularity() {
            static decltype(&allocation_granularity) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_allocation_granularity"));

            return function();
        }

        Il2CppClass* get_class(Il2CppObject* obj) {
            static decltype(&get_class) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_object_get_class"));

            return function(obj);
        }

        uint32_t get_size(Il2CppObject* obj) {
            static decltype(&get_size) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_object_get_size"));

            return function(obj);
        }

        const MethodInfo* get_virtual_method(Il2CppObject* obj, const MethodInfo* method) {
            static decltype(&get_virtual_method) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_object_get_virtual_method"));

            return function(obj, method);
        }

        Il2CppObject* new_object(const Il2CppClass* klass) {
            static decltype(&new_object) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_object_new"));

            return function(klass);
        }

        void* unbox(Il2CppObject* obj) {
            static decltype(&unbox) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_object_unbox"));

            return function(obj);
        }

        Il2CppObject* value_box(Il2CppClass* klass, void* data) {
            static decltype(&value_box) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_value_box"));

            return function(klass, data);
        }
    } // namespace object

    namespace method {
        const Il2CppType* get_return_type(const MethodInfo* method) {
            static decltype(&get_return_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_return_type"));

            return function(method);
        }

        Il2CppClass* get_declaring_type(const MethodInfo* method) {
            static decltype(&get_declaring_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_declaring_type"));

            return function(method);
        }

        const char* get_name(const MethodInfo* method) {
            static decltype(&get_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_name"));

            return function(method);
        }

        const MethodInfo* get_from_reflection(const Il2CppReflectionMethod* method) {
            static decltype(&get_from_reflection) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_from_reflection"));

            return function(method);
        }

        Il2CppReflectionMethod* get_object(const MethodInfo* method, Il2CppClass* refclass) {
            static decltype(&get_object) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_object"));

            return function(method, refclass);
        }

        bool is_generic(const MethodInfo* method) {
            static decltype(&is_generic) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_is_generic"));

            return function(method);
        }

        bool is_inflated(const MethodInfo* method) {
            static decltype(&is_inflated) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_is_inflated"));

            return function(method);
        }

        bool is_instance(const MethodInfo* method) {
            static decltype(&is_instance) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_is_instance"));

            return function(method);
        }

        uint32_t get_param_count(const MethodInfo* method) {
            static decltype(&get_param_count) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_param_count"));

            return function(method);
        }

        const Il2CppType* get_param(const MethodInfo* method, uint32_t index) {
            static decltype(&get_param) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_param"));

            return function(method, index);
        }

        Il2CppClass* get_class(const MethodInfo* method) {
            static decltype(&get_class) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_class"));

            return function(method);
        }

        bool has_attribute(const MethodInfo* method, Il2CppClass* attr_class) {
            static decltype(&has_attribute) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_has_attribute"));

            return function(method, attr_class);
        }

        uint32_t get_flags(const MethodInfo* method, uint32_t* iflags) {
            static decltype(&get_flags) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_flags"));

            return function(method, iflags);
        }

        uint32_t get_token(const MethodInfo* method) {
            static decltype(&get_token) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_token"));

            return function(method);
        }

        const char* get_param_name(const MethodInfo* method, uint32_t index) {
            static decltype(&get_param_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_method_get_param_name"));

            return function(method, index);
        }
    } // namespace method

    namespace property {
        uint32_t get_flags(PropertyInfo* prop) {
            static decltype(&get_flags) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_property_get_flags"));

            return function(prop);
        }

        const MethodInfo* get_get_method(PropertyInfo* prop) {
            static decltype(&get_get_method) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_property_get_get_method"));

            return function(prop);
        }

        const MethodInfo* get_set_method(PropertyInfo* prop) {
            static decltype(&get_set_method) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_property_get_set_method"));

            return function(prop);
        }

        const char* get_name(PropertyInfo* prop) {
            static decltype(&get_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_property_get_name"));

            return function(prop);
        }

        Il2CppClass* get_parent(PropertyInfo* prop) {
            static decltype(&get_parent) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_property_get_parent"));

            return function(prop);
        }
    } // namespace property

    namespace runtime {
        Il2CppObject* invoke(const MethodInfo* method, void* obj, void** params, Il2CppException** exc) {
            static decltype(&invoke) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_runtime_invoke"));

            return function(method, obj, params, exc);
        }

        Il2CppObject* invoke_convert_args(const MethodInfo* method, void* obj, Il2CppObject** params, int32_t paramCount, Il2CppException** exc) {
            static decltype(&invoke_convert_args) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_runtime_invoke_convert_args"));

            return function(method, obj, params, paramCount, exc);
        }

        void class_init(Il2CppClass* klass) {
            static decltype(&class_init) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_runtime_class_init"));

            function(klass);
        }

        void object_init(Il2CppObject* obj) {
            static decltype(&object_init) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_runtime_object_init"));

            function(obj);
        }

        void object_init_exception(Il2CppObject* obj, Il2CppException** exc) {
            static decltype(&object_init_exception) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_runtime_object_init_exception"));

            function(obj, exc);
        }

        void unhandled_exception_policy_set(Il2CppRuntimeUnhandledExceptionPolicy value) {
            static decltype(&unhandled_exception_policy_set) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_runtime_unhandled_exception_policy_set"));

            function(value);
        }
    } // namespace runtime

    namespace string {
        int32_t length(Il2CppString* str) {
            static decltype(&length) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_string_length"));

            return function(str);
        }

        Il2CppChar* chars(Il2CppString* str) {
            static decltype(&chars) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_string_chars"));

            return function(str);
        }

        Il2CppString* new_string(const char* str) {
            static decltype(&new_string) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_string_new"));

            return function(str);
        }

        Il2CppString* new_len(const char* str, uint32_t length) {
            static decltype(&new_len) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_string_new_len"));

            return function(str, length);
        }

        Il2CppString* new_utf16(const Il2CppChar* text, int32_t len) {
            static decltype(&new_utf16) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_string_new_utf16"));

            return function(text, len);
        }

        Il2CppString* new_wrapper(const char* str) {
            static decltype(&new_wrapper) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_string_new_wrapper"));

            return function(str);
        }

        Il2CppString* intern(Il2CppString* str) {
            static decltype(&intern) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_string_intern"));

            return function(str);
        }

        Il2CppString* is_interned(Il2CppString* str) {
            static decltype(&is_interned) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_string_is_interned"));

            return function(str);
        }
    } // namespace string

    namespace thread {
        Il2CppThread* current() {
            static decltype(&current) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_thread_current"));

            return function();
        }

        Il2CppThread* attach(Il2CppDomain* domain) {
            static decltype(&attach) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_thread_attach"));

            return function(domain);
        }

        void detach(Il2CppThread* thread) {
            static decltype(&detach) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_thread_detach"));

            function(thread);
        }

        bool is_vm_thread(Il2CppThread* thread) {
            static decltype(&is_vm_thread) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_is_vm_thread"));

            return function(thread);
        }
    } // namespace thread

    namespace type {
        Il2CppObject* get_object(const Il2CppType* type) {
            static decltype(&get_object) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_get_object"));

            return function(type);
        }

        int32_t get_type(const Il2CppType* type) {
            static decltype(&get_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_get_type"));

            return function(type);
        }

        Il2CppClass* get_class_or_element_class(const Il2CppType* type) {
            static decltype(&get_class_or_element_class) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_get_class_or_element_class"));

            return function(type);
        }

        char* get_name(const Il2CppType* type) {
            static decltype(&get_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_get_name"));

            return function(type);
        }

        bool is_byref(const Il2CppType* type) {
            static decltype(&is_byref) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_is_byref"));

            return function(type);
        }

        uint32_t get_attrs(const Il2CppType* type) {
            static decltype(&get_attrs) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_get_attrs"));

            return function(type);
        }

        bool equals(const Il2CppType* type, const Il2CppType* otherType) {
            static decltype(&equals) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_equals"));

            return function(type, otherType);
        }

        char* get_assembly_qualified_name(const Il2CppType* type) {
            static decltype(&get_assembly_qualified_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_get_assembly_qualified_name"));

            return function(type);
        }

        char* get_reflection_name(const Il2CppType* type) {
            static decltype(&get_reflection_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_get_reflection_name"));

            return function(type);
        }

        bool is_static(const Il2CppType* type) {
            static decltype(&is_static) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_is_static"));

            return function(type);
        }

        bool is_pointer_type(const Il2CppType* type) {
            static decltype(&is_pointer_type) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_is_pointer_type"));

            return function(type);
        }

        void get_name_chunked(const Il2CppType* type, void(*chunkReportFunc)(void* data, void* userData), void* userData) {
            static decltype(&get_name_chunked) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_type_get_name_chunked"));

            function(type, chunkReportFunc, userData);
        }
    } // namespace type

    namespace image {
        const Il2CppAssembly* get_assembly(const Il2CppImage* image) {
            static decltype(&get_assembly) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_image_get_assembly"));

            return function(image);
        }

        const char* get_name(const Il2CppImage* image) {
            static decltype(&get_name) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_image_get_name"));

            return function(image);
        }

        const char* get_filename(const Il2CppImage* image) {
            static decltype(&get_filename) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_image_get_filename"));

            return function(image);
        }

        const MethodInfo* get_entry_point(const Il2CppImage* image) {
            static decltype(&get_entry_point) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_image_get_entry_point"));

            return function(image);
        }

        size_t get_class_count(const Il2CppImage* image) {
            static decltype(&get_class_count) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_image_get_class_count"));

            return function(image);
        }

        const Il2CppClass* get_class(const Il2CppImage* image, size_t index) {
            static decltype(&get_class) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_image_get_class"));

            return function(image, index);
        }
    } // namespace image

    namespace custom_attrs {
        Il2CppCustomAttrInfo* from_class(Il2CppClass* klass) {
            static decltype(&from_class) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_custom_attrs_from_class"));

            return function(klass);
        }

        Il2CppCustomAttrInfo* from_method(const MethodInfo* method) {
            static decltype(&from_method) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_custom_attrs_from_method"));

            return function(method);
        }

        Il2CppCustomAttrInfo* from_field(const FieldInfo* field) {
            static decltype(&from_field) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_custom_attrs_from_field"));

            return function(field);
        }

        Il2CppObject* get_attr(Il2CppCustomAttrInfo* ainfo, Il2CppClass* attr_klass) {
            static decltype(&get_attr) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_custom_attrs_get_attr"));

            return function(ainfo, attr_klass);
        }

        bool has_attr(Il2CppCustomAttrInfo* ainfo, Il2CppClass* attr_klass) {
            static decltype(&has_attr) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_custom_attrs_has_attr"));

            return function(ainfo, attr_klass);
        }

        Il2CppArray* construct(Il2CppCustomAttrInfo* cinfo) {
            static decltype(&construct) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_custom_attrs_construct"));

            return function(cinfo);
        }

        void free(Il2CppCustomAttrInfo* ainfo) {
            static decltype(&free) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_custom_attrs_free"));

            function(ainfo);
        }
    } // namespace custom_attrs

    namespace stats {
        bool dump_to_file(const char* path) {
            static decltype(&dump_to_file) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_stats_dump_to_file"));

            return function(path);
        }

        uint64_t get_value(Il2CppStat stat) {
            static decltype(&get_value) function = nullptr;
            if (!game_assembly)
                game_assembly = GetModuleHandleA("GameAssembly.dll");

            if (!function)
                function = reinterpret_cast<decltype(function)>(GetProcAddress(game_assembly, "il2cpp_stats_get_value"));

            return function(stat);
        }
    } // namespace stats
} // namespace il2cpp