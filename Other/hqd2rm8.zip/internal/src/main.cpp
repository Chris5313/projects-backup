#include <globals.hpp>
#include <game.hpp>

bool DllMain(HMODULE module, uint32_t reason, void* reserved) {
	DisableThreadLibraryCalls(module);

	if (reason == DLL_PROCESS_ATTACH) {
		globals::process = GetModuleHandleA(nullptr);
		globals::internal = module;

#ifdef _DEBUG
		if (GetConsoleWindow() == nullptr) {
			if (!AllocConsole())
				return false;

			ShowWindow(GetConsoleWindow(), SW_SHOW);

			FILE* dummy = nullptr;
			freopen_s(&dummy, "CONIN$", "r", 
				stdin);
			freopen_s(&dummy, "CONOUT$", "w", 
				stderr);
			freopen_s(&dummy, "CONOUT$", "w", 
				stdout);
		}
#endif // !_DEBUG

		std::printf("process : %p\n", globals::process);
		std::printf("internal : %p\n", globals::internal);

		return game::initialize();
	}

	return true;
}