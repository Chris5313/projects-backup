#include <game.hpp>

namespace game {
	void cleanup_thread() {
		while (!GetAsyncKeyState(VK_END))
			std::this_thread::sleep_for(std::chrono::milliseconds(10));

		renderer::cleanup();
		hooks::cleanup();
		ShowWindow(GetConsoleWindow(), SW_HIDE);
		DestroyWindow(GetConsoleWindow());
		FreeConsole();
		FreeLibraryAndExitThread(globals::internal, 0);
	}

    void initialize_classes() {
        rust::base_networkable.store(il2cpp::api_wrapper::find_class("BaseNetworkable"));
        rust::base_entity.store(il2cpp::api_wrapper::find_class("BaseEntity"));
        rust::base_combat_entity.store(il2cpp::api_wrapper::find_class("BaseCombatEntity"));
        rust::base_player.store(il2cpp::api_wrapper::find_class("BasePlayer"));
        rust::base_npc.store(il2cpp::api_wrapper::find_class("BaseNpc"));
        rust::base_vehicle.store(il2cpp::api_wrapper::find_class("BaseVehicle"));
        rust::base_projectile.store(il2cpp::api_wrapper::find_class("BaseProjectile"));
        rust::base_melee.store(il2cpp::api_wrapper::find_class("BaseMelee"));
        rust::base_movement.store(il2cpp::api_wrapper::find_class("BaseMovement"));
        rust::base_view_model.store(il2cpp::api_wrapper::find_class("BaseViewModel"));
        rust::bow_weapon.store(il2cpp::api_wrapper::find_class("BowWeapon"));
        rust::flint_strike_weapon.store(il2cpp::api_wrapper::find_class("FlintStrikeWeapon"));
        rust::jack_hammer.store(il2cpp::api_wrapper::find_class("Jackhammer"));
        rust::player_eyes.store(il2cpp::api_wrapper::find_class("PlayerEyes"));
        rust::player_model.store(il2cpp::api_wrapper::find_class("PlayerModel"));
        rust::player_inventory.store(il2cpp::api_wrapper::find_class("PlayerInventory"));
        rust::player_input.store(il2cpp::api_wrapper::find_class("PlayerInput"));
        rust::main_camera.store(il2cpp::api_wrapper::find_class("MainCamera"));
        rust::camera.store(il2cpp::api_wrapper::find_class("UnityEngine", "Camera"));
        rust::capsule_collider.store(il2cpp::api_wrapper::find_class("UnityEngine", "CapsuleCollider"));
        rust::recoil_properties.store(il2cpp::api_wrapper::find_class("RecoilProperties"));
        rust::update_handler.store(il2cpp::api_wrapper::find_class("UpdateHandler"));
        rust::tod_sky.store(il2cpp::api_wrapper::find_class("TOD_Sky"));
    }

	bool initialize() {
		while (!globals::game_assembly || !globals::unity_player) {
			globals::game_assembly = GetModuleHandleA("GameAssembly.dll");
			globals::unity_player = GetModuleHandleA("UnityPlayer.dll");
			std::this_thread::sleep_for(std::chrono::milliseconds(250));
		}

		std::printf("game assembly : %p\n", globals::game_assembly);
		std::printf("unity player : %p\n", globals::unity_player);

#ifdef _DEBUG
		if (const auto thread = CreateThread(nullptr, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(cleanup_thread),
			nullptr,
			0,
			nullptr))
			CloseHandle(thread);
#endif // !_DEBUG

        initialize_classes();
		return hooks::initialize();
	}
} // namespace game