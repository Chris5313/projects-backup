#include <globals.hpp>

namespace globals {
	HMODULE process = nullptr;
	HMODULE internal = nullptr;
	HMODULE game_assembly = nullptr;
	HMODULE unity_player = nullptr;

	glm::vec2 window_size = {};
	float scale{ 0 };
} // namespace globals

namespace rust {
	std::atomic<il2cpp::api_wrapper::klass*> base_networkable{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> base_entity{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> base_combat_entity{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> base_player{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> base_npc{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> base_vehicle{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> base_projectile{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> base_movement{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> base_view_model{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> base_melee{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> bow_weapon{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> flint_strike_weapon{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> jack_hammer{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> player_eyes{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> player_model{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> player_inventory{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> player_input{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> main_camera{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> camera{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> capsule_collider{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> recoil_properties{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> update_handler{ nullptr };
	std::atomic<il2cpp::api_wrapper::klass*> tod_sky{ nullptr };
} // namespace rust