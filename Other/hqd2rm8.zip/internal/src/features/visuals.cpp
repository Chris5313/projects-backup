#include <features/features.hpp>

namespace features {
	void visuals() {

	}
} // namespace features