#include <features/features.hpp>

namespace features {
	void aimbot() {

	}
} // namespace features