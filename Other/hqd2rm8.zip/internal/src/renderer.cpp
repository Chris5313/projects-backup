#include <renderer.hpp>

namespace renderer {
	std::atomic<bool> initialized{ false };
	HWND output_window = nullptr;
	ID3D11Device* device = nullptr;
	ID3D11DeviceContext* device_context = nullptr;
	ID3D11RenderTargetView* render_target = nullptr;
	WNDPROC o_window_proc = nullptr;

	void create_render_target(IDXGISwapChain* swap_chain) {
		ID3D11Texture2D* back_buffer = nullptr;
		if (FAILED(swap_chain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&back_buffer))))
			return;

		device->CreateRenderTargetView(back_buffer, nullptr, &render_target);
		back_buffer->Release();
	}

	void release_render_target() {
		if (!render_target)
			return;

		render_target->Release();
		render_target = nullptr;
	}

	void on_present_hk(IDXGISwapChain* swap_chain, uint32_t sync_interval, uint32_t flags) {
		if (!initialized.load()) {
			if (FAILED(swap_chain->GetDevice(__uuidof(ID3D11Device), reinterpret_cast<void**>(&device))))
				return;

			device->GetImmediateContext(&device_context);

			DXGI_SWAP_CHAIN_DESC swap_chain_desc = {};
			if (FAILED(swap_chain->GetDesc(&swap_chain_desc)))
				return;

			output_window = swap_chain_desc.OutputWindow;

			ImGui::CreateContext();
			ImGui::GetIO().IniFilename = nullptr;

			ImGui_ImplWin32_Init(output_window);
			ImGui_ImplDX11_Init(device, device_context);

			o_window_proc = reinterpret_cast<WNDPROC>(SetWindowLongPtrW(output_window, GWLP_WNDPROC, reinterpret_cast<uint64_t>(on_window_proc)));

			initialized.store(true);
		}

		if (!render_target)
			create_render_target(swap_chain);
	}

	void on_resize_buffers_hk() {
		if (!initialized.load())
			return;

		release_render_target();
	}

	LRESULT on_window_proc(HWND hwnd, uint32_t message, uint64_t w_param,
		uint64_t l_param) {
		if (initialized.load() && ImGui_ImplWin32_WndProcHandler(hwnd, message, w_param,
			l_param))
			return true;

		return CallWindowProcW(o_window_proc, hwnd, message,
			w_param,
			l_param);
	}

	void begin_frame() {
		if (!initialized.load())
			return;

		ImGui_ImplDX11_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();
	}

	void end_frame() {
		if (!initialized.load())
			return;

		ImGui::Render();

		if (!render_target)
			return;

		ID3D11RenderTargetView* o_rtv = nullptr;
		ID3D11DepthStencilView* o_dsv = nullptr;
		device_context->OMGetRenderTargets(1, &o_rtv, &o_dsv);

		device_context->OMSetRenderTargets(1, &render_target, nullptr);
		ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

		device_context->OMSetRenderTargets(1, &o_rtv, o_dsv);

		if (o_rtv) 
			o_rtv->Release();

		if (o_dsv) 
			o_dsv->Release();
	}

	void cleanup() {
		if (!initialized.load())
			return;

		release_render_target();

		if (o_window_proc && output_window) {
			SetWindowLongPtrW(output_window, GWLP_WNDPROC, reinterpret_cast<uint64_t>(o_window_proc));
			o_window_proc = nullptr;
		}

		ImGui_ImplDX11_Shutdown();
		ImGui_ImplWin32_Shutdown();
		ImGui::DestroyContext();

		if (device_context) {
			device_context->Release();
			device_context = nullptr;
		}

		if (device) {
			device->Release();
			device = nullptr;
		}

		output_window = nullptr;
		initialized.store(false);
	}

	bool key_pressed(const uint32_t virtual_key, const bool check_held) {
		const auto foreground = GetForegroundWindow();
		if (!foreground)
			return false;

		uint32_t foreground_process_id = 0;
		if (!GetWindowThreadProcessId(foreground, reinterpret_cast<LPDWORD>(&foreground_process_id)))
			return false;

		if (foreground_process_id != GetCurrentProcessId())
			return false;

		const auto mask = check_held ? 0x8000U : 0x0001U;
		return GetAsyncKeyState(virtual_key) & mask;
	}

	bool key_pressed(const uint32_t virtual_key) {
		return key_pressed(virtual_key, false);
	}
} // namespace renderer