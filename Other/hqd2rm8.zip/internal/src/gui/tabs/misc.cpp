#include <gui/tabs/misc.hpp>

namespace gui::menu::misc {
	void render() {
	
	}
} // namespace gui::menu::misc