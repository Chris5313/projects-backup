#include <gui/tabs/visuals.hpp>

namespace gui::menu::visuals {
	void render() {

	}
} // namespace gui::menu::visuals