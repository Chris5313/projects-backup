#include <gui/tabs/aimbot.hpp>

namespace gui::menu::aimbot {
	void render() {

	}
} // namespace gui::menu::aimbot