#include <hooks/hooks.hpp>
#include <renderer.hpp>
#include <gui/menu.hpp>
#include <features/features.hpp>

namespace hooks::swap_chain {
	saudi_hook<decltype(present_hk)> present(present_hk);
	saudi_hook<decltype(resize_buffers_hk)> resize_buffers(resize_buffers_hk);

	HRESULT present_hk(IDXGISwapChain* swap_chain, uint32_t sync_interval, uint32_t flags) {
		if (!swap_chain)
			return present.original()(swap_chain, sync_interval, flags);

		renderer::on_present_hk(swap_chain, sync_interval, flags);

		renderer::begin_frame();

		gui::menu::render();

		renderer::end_frame();

		return present.original()(swap_chain, sync_interval, flags);
	}

	HRESULT resize_buffers_hk(IDXGISwapChain* swap_chain, uint32_t buffer_count, uint32_t width,
		uint32_t height,
		DXGI_FORMAT new_format,
		uint32_t swap_chain_flags) {
		renderer::on_resize_buffers_hk();
		globals::window_size = { width, height };
		return resize_buffers.original()(swap_chain, buffer_count, width,
			height,
			new_format,
			swap_chain_flags);
	}
} // namespace hooks::swap_chain