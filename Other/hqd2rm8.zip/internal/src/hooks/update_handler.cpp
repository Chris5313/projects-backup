#include <hooks/hooks.hpp>
#include <features/features.hpp>

namespace hooks::update_handler {
    saudi_hook<decltype(update_hk)> update(update_hk);

    void update_hk(void* __this, const MethodInfo* method) {
        features::misc();
        update.original()(__this, method);
    }
} // namespace hooks::update_handler