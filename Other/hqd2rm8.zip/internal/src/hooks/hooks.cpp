#include <hooks/hooks.hpp>

namespace hooks {
	bool initialize() {
		const auto get_swap_chain_vtable = []() -> void** {
			WNDCLASSEXA wnd_class = { sizeof(wnd_class) };
			wnd_class.style = CS_CLASSDC;
			wnd_class.lpfnWndProc = DefWindowProcA;
			wnd_class.hInstance = GetModuleHandleA(nullptr);
			wnd_class.lpszClassName = "window";

			RegisterClassExA(&wnd_class);

			const auto window = CreateWindowExA(WS_EX_TRANSPARENT, "window", nullptr,
				WS_OVERLAPPEDWINDOW,
				0,
				0,
				0,
				0,
				nullptr,
				nullptr,
				wnd_class.hInstance,
				nullptr);

			DXGI_SWAP_CHAIN_DESC swap_chain_desc = {};
			swap_chain_desc.BufferCount = 1;
			swap_chain_desc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
			swap_chain_desc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
			swap_chain_desc.OutputWindow = window;
			swap_chain_desc.SampleDesc.Count = 1;
			swap_chain_desc.Windowed = true;
			swap_chain_desc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

			ID3D11Device* device = nullptr;
			IDXGISwapChain* swap_chain = nullptr;
			ID3D11DeviceContext* context = nullptr;

			const D3D_FEATURE_LEVEL feature_levels[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_11_1 };
			if (FAILED(D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr,
				0,
				feature_levels,
				sizeof(feature_levels) / sizeof(feature_levels[0]),
				D3D11_SDK_VERSION,
				&swap_chain_desc,
				&swap_chain,
				&device,
				nullptr,
				&context))) {
				DestroyWindow(window);
				UnregisterClassA(wnd_class.lpszClassName, wnd_class.hInstance);
				return nullptr;
			}

			auto** vtable = *reinterpret_cast<void***>(swap_chain);

			if (context)
				context->Release();

			if (device)
				device->Release();

			if (swap_chain)
				swap_chain->Release();

			DestroyWindow(window);
			UnregisterClassA(wnd_class.lpszClassName, wnd_class.hInstance);

			return vtable;
		};

		auto** swap_chain_vtable = get_swap_chain_vtable();
		if (!swap_chain_vtable)
			return false;

		if (!swap_chain::present.initialize(&swap_chain_vtable[8]) || !swap_chain::resize_buffers.initialize(&swap_chain_vtable[13]))
			return false;

		const auto do_attack_method_name = "%840b64577865854f20f4e095d8277c5f004d4cd8";
		auto* do_attack = rust::base_melee.load()->get_method_from_name(do_attack_method_name);
		if (!base_melee::do_attack.initialize(do_attack->get_method_pointer()))
			return false;

		do_attack = rust::base_projectile.load()->get_method_from_name(do_attack_method_name);
		if (!base_projectile::do_attack.initialize(do_attack->get_method_pointer()))
			return false;

		do_attack = rust::bow_weapon.load()->get_method_from_name(do_attack_method_name);
		if (!bow_weapon::do_attack.initialize(do_attack->get_method_pointer()))
			return false;

		do_attack = rust::flint_strike_weapon.load()->get_method_from_name(do_attack_method_name);
		if (!flint_strike_weapon::do_attack.initialize(do_attack->get_method_pointer()))
			return false;

		do_attack = rust::jack_hammer.load()->get_method_from_name(do_attack_method_name);
		if (!jack_hammer::do_attack.initialize(do_attack->get_method_pointer()))
			return false;

		const auto* late_update = rust::tod_sky.load()->get_method_from_name("LateUpdate");
		if (!tod_sky::late_update.initialize(late_update->get_method_pointer()))
			return false;

		const auto* update = rust::update_handler.load()->get_method_from_name("Update");
		if (!update_handler::update.initialize(update->get_method_pointer()))
			return false;

		swap_chain::present.enable();
		swap_chain::resize_buffers.enable();
		base_melee::do_attack.enable();
		base_projectile::do_attack.enable();
		bow_weapon::do_attack.enable();
		flint_strike_weapon::do_attack.enable();
		jack_hammer::do_attack.enable();
		tod_sky::late_update.enable();
		update_handler::update.enable();

		return true;
	}

	void cleanup() {
		swap_chain::present.disable();
		swap_chain::resize_buffers.disable();
		base_melee::do_attack.disable();
		base_projectile::do_attack.disable();
		bow_weapon::do_attack.disable();
		flint_strike_weapon::do_attack.disable();
		jack_hammer::do_attack.disable();
		tod_sky::late_update.disable();
		update_handler::update.disable();
	}
} // namespace hooks