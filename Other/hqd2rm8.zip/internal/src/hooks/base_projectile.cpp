#include <hooks/hooks.hpp>

namespace hooks::base_projectile {
	saudi_hook<decltype(do_attack_hk)> do_attack(do_attack_hk);

	void do_attack_hk(void* __this, const MethodInfo* method) {
		auto* current_burst = reinterpret_cast<int32_t*>(reinterpret_cast<uint8_t*>(__this) + 0x4B0);
		if (*current_burst > 1)
			*current_burst = 0;

		do_attack.original()(__this, method);
	}
} // namespace hooks::base_projectile