#include <hooks/hooks.hpp>

namespace hooks::tod_sky {
	saudi_hook<decltype(late_update_hk)> late_update(late_update_hk);

	void late_update_hk(void* __this, const MethodInfo* method) {
		late_update.original()(__this, method);
	}
} // namespace hooks::tod_sky