#include <hooks/hooks.hpp>

namespace hooks::base_melee {
	saudi_hook<decltype(do_attack_hk)> do_attack(do_attack_hk);

	void do_attack_hk(void* __this, const MethodInfo* method) {
		do_attack.original()(__this, method);
	}
} // namespace hooks::base_melee