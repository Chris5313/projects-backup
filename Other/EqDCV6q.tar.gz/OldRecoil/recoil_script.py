#!/usr/bin/env python3
import os
import sys
import time
import threading
import subprocess
import logging
try:
    from flask import Flask, render_template, jsonify, request
except ImportError:
    print("Missing dependency: run pip install flask")
    sys.exit(1)
from dataclasses import dataclass, field
from typing import List

try:
    import evdev
    from evdev import UInput, ecodes as e
except ImportError:
    print("Missing dependency: run  pip install evdev")
    sys.exit(1)
Recoil_Ak47 = [
    (-69.0, 100.0), (10.0, 92.0),  (-110.0, 83.0), (-85.0, 75.0),
    (0.0,   67.0),  (33.0, 57.0),  (58.0,   48.0), (76.0,  39.0),
    (84.0,  29.0),  (85.0, 19.0),  (76.0,   20.0), (60.0,  37.0),
    (34.0,  50.0),  (2.0,  59.0),  (-30.0,  65.0), (-55.0, 67.0),
    (-74.0, 64.0),  (-86.0, 59.0), (-92.0,  49.0), (-91.0, 34.0),
    (-84.0, 17.0),  (-70.0, 10.0), (-49.0,  28.0), (-22.0, 42.0),
    (24.0,  51.0),  (72.0,  56.0), (97.0,   57.0), (98.0,  51.0),
    (77.0,  43.0),
]

ControlTime_Ak47 = [
    121.96149709966872, 92.6333814724611,  138.60598637206294, 113.37874368443146,
    66.25151186427745,  66.29530438019354,  75.9327831420658,   85.05526144256157,
    89.20256669256554,  86.68010184667988,  78.82145888317788,  70.0451048111144,
    60.85979604582978,  59.51642457624619,  71.66762996283607,  86.74060009403034,
    98.3363599080854,  104.34161954944257, 104.09299204005345,  97.58780746901739,
    85.48062700875559,  70.4889202349561,   56.56417811530545,  47.386907899993936,
    56.63787408680247,  91.5937793023631,  112.38667610336424, 111.39338971888095,
    87.5067801164596,
]

Recoil_Lr300 = [
    (0, 50), (-11, 60), (-22, 67), (-28, 59), (-31, 50), (-29, 42), (-9, 38),
    (-9, 30), (23, 25), (36, 24), (35, 13), (40, 19), (18, 6), (0, 17),
    (-13, 6), (-16, 5), (-19, 6), (-34, 12), (-31, 2), (-29, 5), (-28, 0),
    (-21, 5), (-12, 13), (-7, 0), (19, 5), (3, 11), (61, 0), (73, 0),
    (54, 6), (0, 8), (50, 0),
]

Recoil_Mp5a4 = [
    (0, 43), (0, 58), (0, 65), (25, 66), (59, 58), (63, 42), (46, 27),
    (3, 23), (-37, 19), (-47, 18), (-40, 18), (-8, 7), (16, 12), (28, 11),
    (35, 9), (34, 8), (25, 6), (12, 0), (-4, 2), (-6, 2), (-18, 0),
    (-27, 5), (-26, 0), (-27, 0), (-20, 0), (-32, 0), (-12, 0), (-25, 0),
    (-4, 0), (0, 0), (43, 0),
]

Recoil_Custom_g = [
    (-28, 52), (-10, 53), (0, 53), (11, 44), (20, 45), (22, 42), (17, 35),
    (7, 30), (-9, 27), (-13, 28), (-23, 22), (-21, 21), (-15, 24),
    (0, 13), (20, 14), (16, 12), (29, 19), (7, 6), (11, 10), (-4, 8),
    (-8, 13), (-7, 2), (-13, 14),
]

Recoil_Thompson_g = [
    (-29, 63), (-12, 61), (9, 61), (21, 55), (25, 52), (21, 43), (5, 32),
    (-16, 33), (-24, 25), (-24, 26), (-14, 21), (7, 17), (16, 18),
    (23, 16), (25, 17), (8, 16), (-5, 5), (-13, 15), (-14, 8),
]

Recoil_Semi_r = [(0, 75), (0, 75)]
Recoil_M249   = [(0, 58), (0, 58)]

Recoil_NewAK = [
    (0.000000, -1.128896), (0.161621, -1.150379), (0.324796, -1.149879), (0.424393, -1.129517),
    (0.537704, -1.161973), (0.634245, -1.107978), (0.665481, -1.118278), (0.668416, -1.109101),
    (0.752758, -1.071727), (0.752211, -1.116545), (0.721058, -1.135097), (0.739271, -1.102159),
    (0.696437, -1.082908), (0.740412, -1.088943), (0.798534, -1.135457), (0.724998, -1.072946),
    (0.684589, -1.135225), (0.791181, -1.149167), (0.758436, -1.117533), (0.749124, -1.119200),
    (0.732884, -1.165821), (0.782406, -1.121310), (0.758759, -1.151526), (0.711216, -1.105973),
    (0.776597, -1.124021), (0.755231, -1.142663), (0.776939, -1.120023), (0.760190, -1.110919),
    (0.776939, -1.120023), (0.776597, -1.124021),
]

class WeaponData:
    AK47_Delay      = 133.3333
    LR300_Delay     = 118
    MP5_Delay       = 98
    CUSTOM_SMG_Delay= 99
    THOMPSON_Delay  = 127
    SEMI_Delay      = 150
    M249_Delay      = 103

class Multiplier:
    Scope_x8     = 3.84
    Scope_x16    = 7.68
    Scope_Holo   = 1.2
    Scope_Simple = 0.8
    Scope_None   = 1.0
    Barrel_Suppressor = 0.8
    Barrel_None       = 1.0

bReload    = False
bAK47      = False
bLR300     = False
bMP5       = False
bCSMG      = False
bTHOMPSON  = False
bSemi      = False
bM249      = False
bNewAK     = False

bSound     = True

b8x        = False
bHolo      = False
bSimple    = False
bSuppressor  = False
bMuzzleBoost = False

UserSens: float = 1.0

Weapon = "NONE"
Scope  = "NONE"
Barrel = "NONE"
Sounds = "ON"

BUILD   = "v0.1py"
MADE_BY = "blouzy."

state_lock = threading.Lock()

_ui: UInput = None

def init_uinput():
    global _ui
    cap = {e.EV_REL: [e.REL_X, e.REL_Y], e.EV_KEY: [e.BTN_LEFT, e.BTN_RIGHT]}
    _ui = UInput(cap, name="gorilla-script-mouse")

def rel_move(dx: int, dy: int):
    if _ui is None:
        return
    if dx:
        _ui.write(e.EV_REL, e.REL_X, dx)
    if dy:
        _ui.write(e.EV_REL, e.REL_Y, dy)
    _ui.syn()

def mouse_up():
    if _ui is None:
        return
    _ui.write(e.EV_KEY, e.BTN_LEFT, 0)
    _ui.syn()

_key_state: dict[int, bool] = {}
_key_state_lock = threading.Lock()

def is_pressed(code: int) -> bool:
    with _key_state_lock:
        return _key_state.get(code, False)

def find_devices():
    """Return (keyboard_devs, mouse_devs)."""
    keyboards, mice = [], []
    for path in evdev.list_devices():
        try:
            dev = evdev.InputDevice(path)
            caps = dev.capabilities()
            if e.EV_KEY in caps:
                keys = caps[e.EV_KEY]
                if e.KEY_LEFTSHIFT in keys:
                    keyboards.append(dev)
                elif e.BTN_LEFT in keys:
                    mice.append(dev)
        except Exception:
            pass
    return keyboards, mice

def input_reader_thread(devices: list):
    """Background thread: keep _key_state up to date."""
    import selectors
    sel = selectors.DefaultSelector()
    for dev in devices:
        sel.register(dev, selectors.EVENT_READ)
    while True:
        for key, _ in sel.select(timeout=0.05):
            dev = key.fileobj
            try:
                for event in dev.read():
                    if event.type == e.EV_KEY:
                        with _key_state_lock:
                            _key_state[event.code] = bool(event.value)
            except Exception:
                pass

# Attachment multipliers

def scope_attachment() -> float:
    if b8x:
        if bCSMG or bTHOMPSON:
            return Multiplier.Scope_x8 + 0.75
        return Multiplier.Scope_x8
    elif bSimple:
        if bCSMG or bTHOMPSON:
            return Multiplier.Scope_Simple + 0.1
        return Multiplier.Scope_Simple
    elif bHolo:
        if bCSMG or bTHOMPSON:
            return Multiplier.Scope_Holo + 0.3
        return Multiplier.Scope_Holo
    return Multiplier.Scope_None

def barrel_attachment() -> float:
    if bSuppressor:
        supp = Multiplier.Barrel_Suppressor
        if bM249:
            supp = 0.75
        if bCSMG:
            supp = 0.85
        if bSimple or bHolo:
            return 0.75
        if b8x:
            return 1.46
        return supp
    return Multiplier.Barrel_None

def is_muzzle_boost(delay: float) -> int:
    if bMuzzleBoost:
        diff = delay * 0.1
        return int(delay - diff) + 2
    return int(delay)

# CurrentWeapon helpers
def current_x(bullet: int) -> float:
    sc, ba = scope_attachment(), barrel_attachment()
    if bAK47:    return (((Recoil_Ak47[bullet][0]    * sc) * ba) / 4) / UserSens
    if bLR300:   return (((Recoil_Lr300[bullet][0]   * sc) * ba) / 4) / UserSens
    if bMP5:     return (((Recoil_Mp5a4[bullet][0]   * sc) * ba) / 4) / UserSens
    if bTHOMPSON:return (((Recoil_Thompson_g[bullet][0] * sc) * ba) / 4) / UserSens
    if bCSMG:    return (((Recoil_Custom_g[bullet][0] * sc) * ba) / 4) / UserSens
    if bM249:    return (((Recoil_M249[bullet][0]    * sc) * ba) / 4) / UserSens
    if bSemi:    return (((Recoil_Semi_r[bullet][0]  * sc) * ba) / 4) / UserSens
    if bNewAK:   return (((Recoil_NewAK[bullet][0]   * sc) * ba) / 4) / UserSens
    return 0.0

def current_y(bullet: int) -> float:
    sc, ba = scope_attachment(), barrel_attachment()
    if bAK47:    return (((Recoil_Ak47[bullet][1]    * sc) * ba) / 4) / UserSens
    if bLR300:   return (((Recoil_Lr300[bullet][1]   * sc) * ba) / 4) / UserSens
    if bMP5:     return (((Recoil_Mp5a4[bullet][1]   * sc) * ba) / 4) / UserSens
    if bTHOMPSON:return (((Recoil_Thompson_g[bullet][1] * sc) * ba) / 4) / UserSens
    if bCSMG:    return (((Recoil_Custom_g[bullet][1] * sc) * ba) / 4) / UserSens
    if bM249:    return (((Recoil_M249[bullet][1]    * sc) * ba) / 4) / UserSens
    if bSemi:    return (((Recoil_Semi_r[bullet][1]  * sc) * ba) / 4) / UserSens
    if bNewAK:   return (((Recoil_NewAK[bullet][1]   * sc) * ba) / 4) / UserSens
    return 0.0

def current_delay() -> float:
    if bAK47:    return WeaponData.AK47_Delay
    if bLR300:   return WeaponData.LR300_Delay
    if bMP5:     return WeaponData.MP5_Delay
    if bTHOMPSON:return WeaponData.THOMPSON_Delay
    if bCSMG:    return WeaponData.CUSTOM_SMG_Delay
    if bM249:    return WeaponData.M249_Delay
    if bSemi:    return WeaponData.SEMI_Delay
    if bNewAK:   return WeaponData.AK47_Delay
    return 0.0

def current_control(bullet: int) -> float:
    if bAK47:    return ControlTime_Ak47[bullet]
    if bLR300:   return WeaponData.LR300_Delay
    if bMP5:     return WeaponData.MP5_Delay
    if bTHOMPSON:return WeaponData.THOMPSON_Delay
    if bCSMG:    return WeaponData.CUSTOM_SMG_Delay
    if bM249:    return WeaponData.M249_Delay
    if bSemi:    return WeaponData.SEMI_Delay
    if bNewAK:   return WeaponData.AK47_Delay
    return 0.0

def current_bullet_count() -> int:
    if bAK47:    return len(Recoil_Ak47) - 1
    if bLR300:   return len(Recoil_Lr300) - 1
    if bMP5:     return len(Recoil_Mp5a4) - 1
    if bTHOMPSON:return len(Recoil_Thompson_g) - 1
    if bCSMG:    return len(Recoil_Custom_g) - 1
    if bM249:    return len(Recoil_M249) - 1
    if bSemi:    return len(Recoil_Semi_r) - 1
    if bNewAK:   return len(Recoil_NewAK) - 1
    return 0

def weapon_active() -> bool:
    return any([bAK47, bLR300, bMP5, bTHOMPSON, bCSMG, bSemi, bM249, bNewAK])

def recoil_break(count: int):
    if bSemi:
        mouse_up()
    elif not bM249:
        if count == current_bullet_count():
            if bSound:
                beep(1200, 90)
                beep(1500, 90)
            mouse_up()

# ────────────────────────────────────────────────────────────────────────────
# Timing / smoothing
# ────────────────────────────────────────────────────────────────────────────

def p_query_sleep(ms: float):
    """High-resolution sleep using time.perf_counter (Linux equivalent of QueryPerformanceCounter)."""
    end = time.perf_counter() + ms / 1000.0
    while time.perf_counter() < end:
        pass

def smoothing(delay: float, control_time: float, x: int, y: int):
    x_, y_, t_ = 0, 0, 0
    ct = int(control_time)
    if ct == 0:
        return
    for i in range(1, ct + 1):
        xI = i * x // ct
        yI = i * y // ct
        tI = i * ct // ct          # always equals i; kept for 1:1 parity
        rel_move(xI - x_, yI - y_)
        p_query_sleep(tI - t_)
        x_, y_, t_ = xI, yI, tI
    p_query_sleep(delay - control_time)

# ────────────────────────────────────────────────────────────────────────────
# Sound (Linux: uses `beep` CLI or /dev/console bell)
# ────────────────────────────────────────────────────────────────────────────

def beep(freq: int, duration_ms: int):
    """Best-effort PC-speaker beep on Linux. Requires `beep` package or console access."""
    try:
        subprocess.Popen(
            ["beep", "-f", str(freq), "-l", str(duration_ms)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except FileNotFoundError:
        pass  # `beep` not installed – silent fallback

def sound(toggle: bool):
    if toggle:
        if bSound:
            beep(1200, 100)
    else:
        if bSound:
            beep(800, 100)
    time.sleep(0.12)

# ────────────────────────────────────────────────────────────────────────────
# Arrow-key menu
# ────────────────────────────────────────────────────────────────────────────

# Each section is a list of (label, getter, toggler) tuples.
# getter()  -> bool  : is this item currently active?
# toggler() -> None  : activate / deactivate this item

def _make_weapon(name, flag_attr, others):
    """Build a toggler for a mutually-exclusive weapon."""
    def toggle():
        global Weapon, Scope, Barrel, b8x, bHolo, bSimple, bSuppressor
        global bAK47, bLR300, bMP5, bCSMG, bTHOMPSON, bSemi, bM249
        cur = globals()[flag_attr]
        # turn everything off first
        bAK47 = bLR300 = bMP5 = bCSMG = bTHOMPSON = bSemi = bM249 = False
        if not cur:                       # was OFF -> turn ON
            globals()[flag_attr] = True   # type: ignore[index]
            Weapon = name
        else:                             # was ON -> turn OFF
            Weapon = Scope = Barrel = "NONE"
            b8x = bHolo = bSimple = bSuppressor = False
        sound(globals()[flag_attr])
    def getter():
        return globals()[flag_attr]
    return getter, toggle

_ak47_get,     _ak47_tog     = _make_weapon("AK47",          "bAK47",     [])
_lr300_get,    _lr300_tog    = _make_weapon("LR300",         "bLR300",    [])
_mp5_get,      _mp5_tog      = _make_weapon("MP5A4",         "bMP5",      [])
_csmg_get,     _csmg_tog     = _make_weapon("CUSTOM_SMG",    "bCSMG",     [])
_thompson_get, _thompson_tog = _make_weapon("THOMPSON",      "bTHOMPSON", [])
_m249_get,     _m249_tog     = _make_weapon("M249",          "bM249",     [])
_semi_get,     _semi_tog     = _make_weapon("SEMI-AUTO-RIFLE","bSemi",   [])
_newak_get,    _newak_tog    = _make_weapon("NEW AK",          "bNewAK",  [])

def _toggle_8x():
    global b8x, bHolo, bSimple, Scope
    b8x = not b8x
    Scope = "8x" if b8x else "NONE"
    if b8x: bHolo = bSimple = False
    sound(b8x)

def _toggle_holo():
    global b8x, bHolo, bSimple, Scope
    bHolo = not bHolo
    Scope = "HOLO" if bHolo else "NONE"
    if bHolo: b8x = bSimple = False
    sound(bHolo)

def _toggle_simple():
    global b8x, bHolo, bSimple, Scope
    bSimple = not bSimple
    Scope = "SIMPLE" if bSimple else "NONE"
    if bSimple: b8x = bHolo = False
    sound(bSimple)

def _toggle_boost():
    global bMuzzleBoost, bSuppressor, Barrel
    bMuzzleBoost = not bMuzzleBoost
    Barrel = "BOOST" if bMuzzleBoost else "NONE"
    if bMuzzleBoost: bSuppressor = False
    sound(bMuzzleBoost)

def _toggle_silencer():
    global bSuppressor, bMuzzleBoost, Barrel
    bSuppressor = not bSuppressor
    Barrel = "SILENCER" if bSuppressor else "NONE"
    if bSuppressor: bMuzzleBoost = False
    sound(bSuppressor)

def _toggle_sound():
    global bSound, Sounds
    bSound = not bSound
    Sounds = "ON" if bSound else "OFF"
    sound(bSound)

# ── Menu item table: [ (label, getter, toggler), ... ] per column ────────────
COL_WEAPONS = [
    ("AK47",        _ak47_get,     _ak47_tog),
    ("LR300",       _lr300_get,    _lr300_tog),
    ("MP5A4",       _mp5_get,      _mp5_tog),
    ("CUSTOM SMG",  _csmg_get,     _csmg_tog),
    ("THOMPSON",    _thompson_get, _thompson_tog),
    ("M249",        _m249_get,     _m249_tog),
    ("SAR",         _semi_get,     _semi_tog),
    ("NEW AK",       _newak_get,    _newak_tog),
]
COL_SCOPES = [
    ("8x",          lambda: b8x,          _toggle_8x),
    ("HOLO",        lambda: bHolo,         _toggle_holo),
    ("SIMPLE",      lambda: bSimple,       _toggle_simple),
]
COL_BARREL = [
    ("BOOST",       lambda: bMuzzleBoost,  _toggle_boost),
    ("SILENCER",    lambda: bSuppressor,   _toggle_silencer),
    ("SOUND",       lambda: bSound,        _toggle_sound),
]
COLUMNS = [COL_WEAPONS, COL_SCOPES, COL_BARREL]
COL_NAMES = ["  WEAPON  ", "  SCOPE  ", " BARREL/SFX "]

# cursor position
_cur_col = 0
_cur_row = 0

# ANSI helpers
RESET  = "\033[0m"
BOLD   = "\033[1m"
GREEN  = "\033[32m"
CYAN   = "\033[36m"
YELLOW = "\033[33m"
DIM    = "\033[2m"
HIGHLIGHT = "\033[7m"    # reverse video = cursor highlight

def menu():
    """Render the full arrow-key menu to the terminal."""
    os.system("clear")
    # ── Header ────────────────────────────────────────────────────────────────
    print(f"{BOLD}{CYAN}  Gorilla Script Universal  {RESET}  {DIM}Build {BUILD}{RESET}")
    print(f"  Sensitivity: {YELLOW}{UserSens}{RESET}   Sounds: {GREEN if bSound else DIM}{Sounds}{RESET}")
    print(f"  {DIM}↑↓ navigate   ←→ column   Enter/Space = toggle{RESET}")
    print()

    # ── Determine max rows across all columns ─────────────────────────────────
    max_rows = max(len(c) for c in COLUMNS)
    col_w = 18   # fixed cell width

    # ── Column headers ────────────────────────────────────────────────────────
    header = ""
    for ci, name in enumerate(COL_NAMES):
        active_item = COLUMNS[ci][_cur_row if _cur_row < len(COLUMNS[ci]) else 0]
        is_col = ci == _cur_col
        hdr = f"{BOLD}{CYAN if is_col else ''}{name.center(col_w)}{RESET}"
        header += hdr
    print(header)
    print("  " + ("─" * col_w + "  ") * len(COLUMNS))

    # ── Rows ─────────────────────────────────────────────────────────────────
    for row in range(max_rows):
        line = ""
        for col, items in enumerate(COLUMNS):
            if row >= len(items):
                line += " " * (col_w + 2)
                continue
            label, getter, _ = items[row]
            active  = getter()
            is_cur  = (col == _cur_col and row == _cur_row)
            # build cell text
            marker = f"{GREEN}●{RESET}" if active else f"{DIM}○{RESET}"
            text   = label[:col_w - 4].ljust(col_w - 4)
            cell   = f" {marker} {text}"
            if is_cur:
                cell = f"{HIGHLIGHT}{cell}{RESET}"
            line += cell.ljust(col_w + 12)    # ljust accounts for ANSI escape width illusion
        print(line)

    # ── Status bar ────────────────────────────────────────────────────────────
    print()
    print(f"  {BOLD}[WEAPON]{RESET} {YELLOW}{Weapon}{RESET}   "
          f"{BOLD}[SCOPE]{RESET} {YELLOW}{Scope}{RESET}   "
          f"{BOLD}[BARREL]{RESET} {YELLOW}{Barrel}{RESET}")

# ────────────────────────────────────────────────────────────────────────────
# Recoil execution thread
# ────────────────────────────────────────────────────────────────────────────

def recoil_execution():
    while True:
        if weapon_active():
            lmb = is_pressed(e.BTN_LEFT)
            rmb = is_pressed(e.BTN_RIGHT)
            if lmb and rmb:
                bc = current_bullet_count()
                for i in range(bc + 1):
                    if not (is_pressed(e.BTN_LEFT) and is_pressed(e.BTN_RIGHT)):
                        break
                    delay   = is_muzzle_boost(current_delay())
                    control = is_muzzle_boost(current_control(i))
                    x = int(current_x(i))
                    y = int(current_y(i))
                    smoothing(delay, control, x, y)
                    recoil_break(i)
        time.sleep(0.001)

# ────────────────────────────────────────────────────────────────────────────
# Key edge-detect helper
# ────────────────────────────────────────────────────────────────────────────

_prev_keys: dict[int, bool] = {}

def just_pressed(code: int) -> bool:
    """Edge-detect: true only on the first frame the key is down."""
    cur  = is_pressed(code)
    prev = _prev_keys.get(code, False)
    _prev_keys[code] = cur
    return cur and not prev

# ────────────────────────────────────────────────────────────────────────────
# Flask Web Menu
# ────────────────────────────────────────────────────────────────────────────

app = Flask(__name__)
# Suppress Werkzeug logging to keep terminal UI clean
logging.getLogger('werkzeug').setLevel(logging.ERROR)

@app.route('/')
def index_route():
    return render_template('index.html')

@app.route('/api/state')
def api_state():
    return jsonify({
        "Weapon": Weapon,
        "Scope": Scope,
        "Barrel": Barrel,
        "Sounds": Sounds,
        "UserSens": UserSens,
        "bAK47": bAK47,
        "bLR300": bLR300,
        "bMP5": bMP5,
        "bCSMG": bCSMG,
        "bTHOMPSON": bTHOMPSON,
        "bSemi": bSemi,
        "bM249": bM249,
        "bNewAK": bNewAK,
        "b8x": b8x,
        "bHolo": bHolo,
        "bSimple": bSimple,
        "bMuzzleBoost": bMuzzleBoost,
        "bSuppressor": bSuppressor,
        "bSound": bSound
    })

@app.route('/api/toggle/<category>/<item>', methods=['POST'])
def api_toggle(category, item):
    _menu_map = {
        'weapon': {
            'AK47': _ak47_tog,
            'LR300': _lr300_tog,
            'MP5A4': _mp5_tog,
            'CUSTOM_SMG': _csmg_tog,
            'THOMPSON': _thompson_tog,
            'M249': _m249_tog,
            'SEMI-AUTO-RIFLE': _semi_tog,
            'NEW AK': _newak_tog,
        },
        'scope': {
            '8x': _toggle_8x,
            'HOLO': _toggle_holo,
            'SIMPLE': _toggle_simple,
        },
        'barrel': {
            'BOOST': _toggle_boost,
            'SILENCER': _toggle_silencer,
            'SOUND': _toggle_sound,
        }
    }
    
    if category in _menu_map and item in _menu_map[category]:
        func = _menu_map[category][item]
        func()
        # Redraw menu immediately
        menu()
        
    return api_state()

@app.route('/api/set_sens', methods=['POST'])
def api_set_sens():
    global UserSens
    data = request.get_json()
    if data and 'sens' in data:
        try:
            val = float(data['sens'])
            UserSens = val
            menu()
        except ValueError:
            pass
    return api_state()

def run_flask():
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

# ────────────────────────────────────────────────────────────────────────────
# Main
# ────────────────────────────────────────────────────────────────────────────

def main():
    global bAK47, bLR300, bMP5, bCSMG, bTHOMPSON, bSemi, bM249
    global b8x, bHolo, bSimple, bSuppressor, bMuzzleBoost, bSound
    global Weapon, Scope, Barrel, Sounds, UserSens

    # Raise process priority
    try:
        os.nice(-10)
    except PermissionError:
        pass   # needs root; non-fatal

    # Init uinput
    try:
        init_uinput()
    except PermissionError:
        print("ERROR: Cannot open uinput. Run as root or add yourself to the 'input' group.")
        print("  sudo usermod -aG input $USER  (then log out/in)")
        sys.exit(1)

    # Find and grab input devices
    keyboards, mice = find_devices()
    all_devs = keyboards + mice
    if not all_devs:
        print("ERROR: No suitable input devices found. Check permissions for /dev/input/event*")
        sys.exit(1)

    # Start input reader thread
    t_input = threading.Thread(target=input_reader_thread, args=(all_devs,), daemon=True)
    t_input.start()

    # Start recoil thread
    t_recoil = threading.Thread(target=recoil_execution, daemon=True)
    t_recoil.start()

    # Start Flask Web Menu thread
    t_flask = threading.Thread(target=run_flask, daemon=True)
    t_flask.start()

    # Collect sensitivity
    try:
        UserSens = float(input("Enter Sens: "))
    except ValueError:
        UserSens = 1.0

    menu()

    # ── arrow-key nav loop ──────────────────────────────────────
    global _cur_col, _cur_row
    while True:
        redraw = False

        if just_pressed(e.KEY_UP):
            _cur_row = (_cur_row - 1) % len(COLUMNS[_cur_col])
            redraw = True
        if just_pressed(e.KEY_DOWN):
            _cur_row = (_cur_row + 1) % len(COLUMNS[_cur_col])
            redraw = True

        if just_pressed(e.KEY_LEFT):
            _cur_col = (_cur_col - 1) % len(COLUMNS)
            _cur_row = min(_cur_row, len(COLUMNS[_cur_col]) - 1)
            redraw = True
        if just_pressed(e.KEY_RIGHT):
            _cur_col = (_cur_col + 1) % len(COLUMNS)
            _cur_row = min(_cur_row, len(COLUMNS[_cur_col]) - 1)
            redraw = True

        if just_pressed(e.KEY_ENTER) or just_pressed(e.KEY_SPACE):
            _, _, toggler = COLUMNS[_cur_col][_cur_row]
            toggler()
            redraw = True

        if redraw:
            menu()

        time.sleep(0.001)

if __name__ == "__main__":
    main()
