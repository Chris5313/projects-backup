Since I don't play this game anymore, enjoy it, I guess.
Last updated: November 7, 2024.
To download that build, use DepotDownloader with this command (correct me if I’m wrong):

```DepotDownloader.exe -app 359550 -depot 359551 -manifest 825321500774263546 -username user -password pass```
