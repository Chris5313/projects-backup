#pragma once
#include "Scimitar.hpp"

#include "config.hpp"

#include "Render.hpp"

namespace BlindEye {

	inline std::vector<scimitar::Entity*> cached_drone;

	auto Renderables(bool enable) -> void;

	void StopRunning(bool state);

	auto rage_bot(bool enable) -> void;

	auto run_and_shoot(bool enable) -> void;

	auto fov_changer(float fov) -> void;

	auto third_person(bool enable) -> void;

	auto force_movement(float movementSpeed) -> void;
	
	auto gadget_renderables(bool enable) -> void;

	auto no_clip(bool enable) -> void;

	auto display_options_effects() -> void;

	auto self_revive(bool enable) -> void;

	auto long_melee(bool enable) -> void;

	auto flores_drone(bool enable) -> void;

	auto update_target() -> void;

	auto Health_Message(bool enable) -> void;

	auto chat_spammer() -> void;

	auto update_spread() -> void;

	auto no_spread(bool enable) -> void;
}