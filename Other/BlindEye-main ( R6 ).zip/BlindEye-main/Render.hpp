#pragma once
#include "ImGui/imgui.h"
#include "havok_math.hpp"
#include "scimitar.hpp"
#include "config.hpp"
#include <D3DX11tex.h>
#pragma comment(lib, "D3DX11.lib")
#define M_PI 3.14159265358979323846


struct Tracer {
    ubiVector4 world_start;
    ImU32 color;
    float thickness = 2.0f;
    std::chrono::time_point<std::chrono::steady_clock> start_time;
   
    ubiVector4 world_end;
};

inline std::vector<Tracer> active_tracers;

inline float hue1 = 0.0f;
inline const float hueStep = 0.01f;

namespace Render {

    ImVec4 getRainbowColor(float hue);
    ImU32 GetRainbowColor();
    void add_tracer(ubiVector4 start_pos, ubiVector4 end_pos, float thickness, bool enable);
    void render_tracers();
    void DrawPlayerTags(const ubiVector2& Position, float Health, float MaxHealth, float Distance, const char* UserName, const char* Operator, ImColor color, ImColor distanceColor);
    void outlined_text(ImDrawList* bg, const ImVec2& pos, ImU32 black, ImU32 color, const char* text);
    void LoadImages();
    void LoadGadgetImages();
    ID3D11ShaderResourceView* GetIconByName(const char* Operator);
    ID3D11ShaderResourceView* GetGadgetIconByName(const char* Gadget);
    void DrawGadgetIcon(const char* Gadget, ubiVector4 position);
    void draw_skeleton(const ImVec2& p1, const ImVec2& p2, const ImVec4& color, float thickness);
    

}



namespace OperatorIcons
{
    inline ID3D11ShaderResourceView* ace_image{ 0x0 };
    inline ID3D11ShaderResourceView* alibi_image{ 0x0 };
    inline ID3D11ShaderResourceView* amaru_image{ 0x0 };
    inline ID3D11ShaderResourceView* aruni_image{ 0x0 };
    inline ID3D11ShaderResourceView* ash_image{ 0x0 };
    inline ID3D11ShaderResourceView* azami_image{ 0x0 };
    inline ID3D11ShaderResourceView* bandit_image{ 0x0 };
    inline ID3D11ShaderResourceView* blackbeard_image{ 0x0 };
    inline ID3D11ShaderResourceView* blitz_image{ 0x0 };
    inline ID3D11ShaderResourceView* brava_image{ 0x0 };
    inline ID3D11ShaderResourceView* buck_image{ 0x0 };
    inline ID3D11ShaderResourceView* capitao_image{ 0x0 };
    inline ID3D11ShaderResourceView* castle_image{ 0x0 };
    inline ID3D11ShaderResourceView* caveira_image{ 0x0 };
    inline ID3D11ShaderResourceView* clash_image{ 0x0 };
    inline ID3D11ShaderResourceView* deimos_image{ 0x0 };
    inline ID3D11ShaderResourceView* doc_image{ 0x0 };
    inline ID3D11ShaderResourceView* dokkaebi_image{ 0x0 };
    inline ID3D11ShaderResourceView* echo_image{ 0x0 };
    inline ID3D11ShaderResourceView* ela_image{ 0x0 };
    inline ID3D11ShaderResourceView* fenrir_image{ 0x0 };
    inline ID3D11ShaderResourceView* finka_image{ 0x0 };
    inline ID3D11ShaderResourceView* flores_image{ 0x0 };
    inline ID3D11ShaderResourceView* frost_image{ 0x0 };
    inline ID3D11ShaderResourceView* fuze_image{ 0x0 };
    inline ID3D11ShaderResourceView* glaz_image{ 0x0 };
    inline ID3D11ShaderResourceView* goyo_image{ 0x0 };
    inline ID3D11ShaderResourceView* gridlock_image{ 0x0 };
    inline ID3D11ShaderResourceView* grim_image{ 0x0 };
    inline ID3D11ShaderResourceView* hibana_image{ 0x0 };
    inline ID3D11ShaderResourceView* iana_image{ 0x0 };
    inline ID3D11ShaderResourceView* iq_image{ 0x0 };
    inline ID3D11ShaderResourceView* jackal_image{ 0x0 };
    inline ID3D11ShaderResourceView* jager_image{ 0x0 };
    inline ID3D11ShaderResourceView* kaid_image{ 0x0 };
    inline ID3D11ShaderResourceView* kali_image{ 0x0 };
    inline ID3D11ShaderResourceView* kapkan_image{ 0x0 };
    inline ID3D11ShaderResourceView* lesion_image{ 0x0 };
    inline ID3D11ShaderResourceView* lion_image{ 0x0 };
    inline ID3D11ShaderResourceView* maestro_image{ 0x0 };
    inline ID3D11ShaderResourceView* maverick_image{ 0x0 };
    inline ID3D11ShaderResourceView* melusi_image{ 0x0 };
    inline ID3D11ShaderResourceView* mira_image{ 0x0 };
    inline ID3D11ShaderResourceView* montagne_image{ 0x0 };
    inline ID3D11ShaderResourceView* mozzie_image{ 0x0 };
    inline ID3D11ShaderResourceView* mute_image{ 0x0 };
    inline ID3D11ShaderResourceView* nokk_image{ 0x0 };
    inline ID3D11ShaderResourceView* nomad_image{ 0x0 };
    inline ID3D11ShaderResourceView* oryx_image{ 0x0 };
    inline ID3D11ShaderResourceView* osa_image{ 0x0 };
    inline ID3D11ShaderResourceView* pulse_image{ 0x0 };
    inline ID3D11ShaderResourceView* ram_image{ 0x0 };
    inline ID3D11ShaderResourceView* recruit_image{ 0x0 };
    inline ID3D11ShaderResourceView* recruit_blue_image{ 0x0 };
    inline ID3D11ShaderResourceView* recruit_green_image{ 0x0 };
    inline ID3D11ShaderResourceView* recruit_orange_image{ 0x0 };
    inline ID3D11ShaderResourceView* recruit_red_image{ 0x0 };
    inline ID3D11ShaderResourceView* recruit_yellow_image{ 0x0 };
    inline ID3D11ShaderResourceView* rook_image{ 0x0 };
    inline ID3D11ShaderResourceView* sens_image{ 0x0 };
    inline ID3D11ShaderResourceView* sentry_image{ 0x0 };
    inline ID3D11ShaderResourceView* sledge_image{ 0x0 };
    inline ID3D11ShaderResourceView* smoke_image{ 0x0 };
    inline ID3D11ShaderResourceView* solis_image{ 0x0 };
    inline ID3D11ShaderResourceView* striker_image{ 0x0 };
    inline ID3D11ShaderResourceView* tachanka_image{ 0x0 };
    inline ID3D11ShaderResourceView* thatcher_image{ 0x0 };
    inline ID3D11ShaderResourceView* thermite_image{ 0x0 };
    inline ID3D11ShaderResourceView* thorn_image{ 0x0 };
    inline ID3D11ShaderResourceView* thunderbird_image{ 0x0 };
    inline ID3D11ShaderResourceView* tubarao_image{ 0x0 };
    inline ID3D11ShaderResourceView* twitch_image{ 0x0 };
    inline ID3D11ShaderResourceView* valkyrie_image{ 0x0 };
    inline ID3D11ShaderResourceView* vigil_image{ 0x0 };
    inline ID3D11ShaderResourceView* wamai_image{ 0x0 };
    inline ID3D11ShaderResourceView* warden_image{ 0x0 };
    inline ID3D11ShaderResourceView* ying_image{ 0x0 };
    inline ID3D11ShaderResourceView* zero_image{ 0x0 };
    inline ID3D11ShaderResourceView* zofia_image{ 0x0 };
    inline ID3D11ShaderResourceView* skopos_image{ 0x0 };

}
inline std::vector < std::pair<std::string, ID3D11ShaderResourceView*> > operatorImages;


namespace GadgetIcons
{
    inline ID3D11ShaderResourceView* Adrenal_Surge_image{ 0x0 };
    inline ID3D11ShaderResourceView* ADS_image{ 0x0 };
    inline ID3D11ShaderResourceView* Airjab_image{ 0x0 };
    inline ID3D11ShaderResourceView* Argus_Camera_image{ 0x0 };
    inline ID3D11ShaderResourceView* Assurya_Laser_Gate_image{ 0x0 };
    inline ID3D11ShaderResourceView* Banshee_image{ 0x0 };
    inline ID3D11ShaderResourceView* Barbed_Wire_image{ 0x0 };
    inline ID3D11ShaderResourceView* Black_Eye_image{ 0x0 };
    inline ID3D11ShaderResourceView* Blitz_Shield_image{ 0x0 };
    inline ID3D11ShaderResourceView* Breach_Charge_image{ 0x0 };
    inline ID3D11ShaderResourceView* BU_GI_image{ 0x0 };
    inline ID3D11ShaderResourceView* Bulletproof_Cam_image{ 0x0 };
    inline ID3D11ShaderResourceView* Camera_image{ 0x0 };
    inline ID3D11ShaderResourceView* CCE_Shield_image{ 0x0 };
    inline ID3D11ShaderResourceView* Claymore_image{ 0x0 };
    inline ID3D11ShaderResourceView* Cluster_Charge_image{ 0x0 };
    inline ID3D11ShaderResourceView* Defuser_image{ 0x0 };
    inline ID3D11ShaderResourceView* Drone_image{ 0x0 };
    inline ID3D11ShaderResourceView* EE_ONE_D_image{ 0x0 };
    inline ID3D11ShaderResourceView* Ela_Mine_image{ 0x0 };
    inline ID3D11ShaderResourceView* Electroclaw_image{ 0x0 };
    inline ID3D11ShaderResourceView* ERC_7_image{ 0x0 };
    inline ID3D11ShaderResourceView* Evil_Eye_image{ 0x0 };
    inline ID3D11ShaderResourceView* EYENOX_MODELL_III_image{ 0x0 };
    inline ID3D11ShaderResourceView* F_NATT_image{ 0x0 };
    inline ID3D11ShaderResourceView* Flores_Drone_image{ 0x0 };
    inline ID3D11ShaderResourceView* Frag_Grenade_image{ 0x0 };
    inline ID3D11ShaderResourceView* Frost_Trap_image{ 0x0 };
    inline ID3D11ShaderResourceView* Gemini_Replicator_image{ 0x0 };
    inline ID3D11ShaderResourceView* Goyo_image{ 0x0 };
    inline ID3D11ShaderResourceView* Grim_Bees_image{ 0x0 };
    inline ID3D11ShaderResourceView* Gu_image{ 0x0 };
    inline ID3D11ShaderResourceView* Hard_Breach_Device_image{ 0x0 };
    inline ID3D11ShaderResourceView* Heartbeat_Sensor_image{ 0x0 };
    inline ID3D11ShaderResourceView* HEL_image{ 0x0 };
    inline ID3D11ShaderResourceView* Impact_image{ 0x0 };
    inline ID3D11ShaderResourceView* IQ_Scanner_image{ 0x0 };
    inline ID3D11ShaderResourceView* Kapkan_image{ 0x0 };
    inline ID3D11ShaderResourceView* Kiba_Barrier_image{ 0x0 };
    inline ID3D11ShaderResourceView* Kludge_Drone_image{ 0x0 };
    inline ID3D11ShaderResourceView* Kona_image{ 0x0 };
    inline ID3D11ShaderResourceView* Logic_Bomb_image{ 0x0 };
    inline ID3D11ShaderResourceView* LV_Explosive_Lance_image{ 0x0 };
    inline ID3D11ShaderResourceView* Mag_NET_image{ 0x0 };
    inline ID3D11ShaderResourceView* Mozzie_Pest_image{ 0x0 };
    inline ID3D11ShaderResourceView* Mute_Jammer_image{ 0x0 };
    inline ID3D11ShaderResourceView* Nitro_Cell_image{ 0x0 };
    inline ID3D11ShaderResourceView* Observation_Blocker_image{ 0x0 };
    inline ID3D11ShaderResourceView* Osa_Shield_image{ 0x0 };
    inline ID3D11ShaderResourceView* Pantheon_Avatare_V10_image{ 0x0 };
    inline ID3D11ShaderResourceView* Placeholder_image{ 0x0 };
    inline ID3D11ShaderResourceView* Prisma_image{ 0x0 };
    inline ID3D11ShaderResourceView* Proximity_Alarm_image{ 0x0 };
    inline ID3D11ShaderResourceView* Razorbloom_image{ 0x0 };
    inline ID3D11ShaderResourceView* Rook_Armor_image{ 0x0 };
    inline ID3D11ShaderResourceView* SELMA_image{ 0x0 };
    inline ID3D11ShaderResourceView* Shield_image{ 0x0 };
    inline ID3D11ShaderResourceView* Shock_Drone_image{ 0x0 };
    inline ID3D11ShaderResourceView* Shock_Wire_image{ 0x0 };
    inline ID3D11ShaderResourceView* Smart_Glasses_image{ 0x0 };
    inline ID3D11ShaderResourceView* Smoke_Grenade_image{ 0x0 };
    inline ID3D11ShaderResourceView* Spec_IO_Electro_Sensor_image{ 0x0 };
    inline ID3D11ShaderResourceView* Thermite_Breach_image{ 0x0 };
    inline ID3D11ShaderResourceView* Trax_image{ 0x0 };
    inline ID3D11ShaderResourceView* X_Kairos_image{ 0x0 };
    inline ID3D11ShaderResourceView* Yokai_Drone_image{ 0x0 };
    inline ID3D11ShaderResourceView* Zoto_Canister_image{ 0x0 };

    inline ID3D11ShaderResourceView* Black_Mirror_image{ 0x0 };
    inline ID3D11ShaderResourceView* Castle_image{ 0x0 };
    inline ID3D11ShaderResourceView* Sense_image{ 0x0 };
    inline ID3D11ShaderResourceView* Ying_image{ 0x0 };
}

inline std::vector < std::pair<std::string, ID3D11ShaderResourceView*> > GadgetImages;

