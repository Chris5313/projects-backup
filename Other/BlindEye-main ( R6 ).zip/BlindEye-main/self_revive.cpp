#include "BlindEye.hpp"

auto BlindEye::self_revive(bool enable) -> void {

	if (!enable) return;

	auto local_controller = scimitar::game_manager::get_instance()->get_local_controller();

	auto local_pawn = local_controller->get_pawn();


	if (GetAsyncKeyState(Globals->Hotkey.selfrevivekey) & 1) {

		local_pawn->self_revive(4);
		local_pawn->self_revive(1);
	}

}