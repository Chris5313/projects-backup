#include "d3d11hook.hpp"

#pragma section(".text")
__declspec(allocate(".text")) const unsigned char jmp_rdx[] = { 0xFF, 0x27 };


typedef long(__stdcall* present)(IDXGISwapChain*, UINT, UINT);
present p_present;
present p_present_target;
auto d3d11::get_present_pointer() -> bool
{
	DXGI_SWAP_CHAIN_DESC sd;
	ZeroMemory(&sd, sizeof(sd));
	sd.BufferCount = 2;
	sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	sd.OutputWindow = GetForegroundWindow();
	sd.SampleDesc.Count = 1;
	sd.Windowed = TRUE;
	sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

	IDXGISwapChain* swap_chain;
	ID3D11Device* device;

	const D3D_FEATURE_LEVEL feature_levels[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
	if (D3D11CreateDeviceAndSwapChain(
		NULL,
		D3D_DRIVER_TYPE_HARDWARE,
		NULL,
		0,

		feature_levels,
		2,
		D3D11_SDK_VERSION,
		&sd,
		&swap_chain,
		&device,
		nullptr,
		nullptr) == S_OK)
	{
		void** p_vtable = *reinterpret_cast<void***>(swap_chain);
		swap_chain->Release();
		device->Release();
		//context->Release();
		p_present_target = (present)p_vtable[8];
		return true;
	}
	return false;
}

WNDPROC oWndProc;
extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
auto __stdcall d3d11::WndProc(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) -> LRESULT {
	if (true && ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam))
		return true;

	return CallWindowProc(oWndProc, hWnd, uMsg, wParam, lParam);
}

inline bool LoadImageByMemory(ID3D11Device* device, unsigned char* image, size_t image_size, ID3D11ShaderResourceView** result)
{
	D3DX11_IMAGE_LOAD_INFO information;
	ID3DX11ThreadPump* thread = nullptr;

	auto res = D3DX11CreateShaderResourceViewFromMemory(device, image, image_size, &information, thread, result, 0);
	return (res == S_OK);
}

bool init = false;
HWND window = NULL;
ID3D11Device* p_device = NULL;
ID3D11DeviceContext* p_context = NULL;
ID3D11RenderTargetView* mainRenderTargetView = NULL;
static long __stdcall d3d11::detour_present(IDXGISwapChain* p_swap_chain, UINT sync_interval, UINT flags) {
	if (!init) {
		if (SUCCEEDED(p_swap_chain->GetDevice(__uuidof(ID3D11Device), (void**)&p_device)))
		{
			p_device->GetImmediateContext(&p_context);
			DXGI_SWAP_CHAIN_DESC sd;
			p_swap_chain->GetDesc(&sd);
			window = sd.OutputWindow;
			ID3D11Texture2D* pBackBuffer;
			p_swap_chain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer);
			p_device->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView);
			pBackBuffer->Release();
			oWndProc = (WNDPROC)SetWindowLongPtr(window, GWLP_WNDPROC, (LONG_PTR)WndProc);
			ImGui::CreateContext();
			ImGuiIO& io = ImGui::GetIO();
			io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;
			ImGui_ImplWin32_Init(window);
			ImGui_ImplDX11_Init(p_device, p_context);
			init = true;


			ImFont* Default = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\Arial.ttf", 13);

			LoadImageByMemory(p_device, aceImage, sizeof(aceImage), &OperatorIcons::ace_image);
			LoadImageByMemory(p_device, alibiImage, sizeof(alibiImage), &OperatorIcons::alibi_image);
			LoadImageByMemory(p_device, amaruImage, sizeof(amaruImage), &OperatorIcons::amaru_image);
			LoadImageByMemory(p_device, aruniImage, sizeof(aruniImage), &OperatorIcons::aruni_image);
			LoadImageByMemory(p_device, ashImage, sizeof(ashImage), &OperatorIcons::ash_image);
			LoadImageByMemory(p_device, azamiImage, sizeof(azamiImage), &OperatorIcons::azami_image);
			LoadImageByMemory(p_device, banditImage, sizeof(banditImage), &OperatorIcons::bandit_image);
			LoadImageByMemory(p_device, blackbeardImage, sizeof(blackbeardImage), &OperatorIcons::blackbeard_image);
			LoadImageByMemory(p_device, blitzImage, sizeof(blitzImage), &OperatorIcons::blitz_image);
			LoadImageByMemory(p_device, bravaImage, sizeof(bravaImage), &OperatorIcons::brava_image);
			LoadImageByMemory(p_device, buckImage, sizeof(buckImage), &OperatorIcons::buck_image);
			LoadImageByMemory(p_device, capitaoImage, sizeof(capitaoImage), &OperatorIcons::capitao_image);
			LoadImageByMemory(p_device, castleImage, sizeof(castleImage), &OperatorIcons::castle_image);
			LoadImageByMemory(p_device, caveiraImage, sizeof(caveiraImage), &OperatorIcons::caveira_image);
			LoadImageByMemory(p_device, clashImage, sizeof(clashImage), &OperatorIcons::clash_image);
			LoadImageByMemory(p_device, deimosImage, sizeof(deimosImage), &OperatorIcons::deimos_image);
			LoadImageByMemory(p_device, docImage, sizeof(docImage), &OperatorIcons::doc_image);
			LoadImageByMemory(p_device, dokkaebiImage, sizeof(dokkaebiImage), &OperatorIcons::dokkaebi_image);
			LoadImageByMemory(p_device, echoImage, sizeof(echoImage), &OperatorIcons::echo_image);
			LoadImageByMemory(p_device, elaImage, sizeof(elaImage), &OperatorIcons::ela_image);
			LoadImageByMemory(p_device, fenrirImage, sizeof(fenrirImage), &OperatorIcons::fenrir_image);
			LoadImageByMemory(p_device, finkaImage, sizeof(finkaImage), &OperatorIcons::finka_image);
			LoadImageByMemory(p_device, floresImage, sizeof(floresImage), &OperatorIcons::flores_image);
			LoadImageByMemory(p_device, frostImage, sizeof(frostImage), &OperatorIcons::frost_image);
			LoadImageByMemory(p_device, fuzeImage, sizeof(fuzeImage), &OperatorIcons::fuze_image);
			LoadImageByMemory(p_device, glazImage, sizeof(glazImage), &OperatorIcons::glaz_image);
			LoadImageByMemory(p_device, goyoImage, sizeof(goyoImage), &OperatorIcons::goyo_image);
			LoadImageByMemory(p_device, gridlockImage, sizeof(gridlockImage), &OperatorIcons::gridlock_image);
			LoadImageByMemory(p_device, grimImage, sizeof(grimImage), &OperatorIcons::grim_image);
			LoadImageByMemory(p_device, hibanaImage, sizeof(hibanaImage), &OperatorIcons::hibana_image);
			LoadImageByMemory(p_device, ianaImage, sizeof(ianaImage), &OperatorIcons::iana_image);
			LoadImageByMemory(p_device, iqImage, sizeof(iqImage), &OperatorIcons::iq_image);
			LoadImageByMemory(p_device, jackalImage, sizeof(jackalImage), &OperatorIcons::jackal_image);
			LoadImageByMemory(p_device, jagerImage, sizeof(jagerImage), &OperatorIcons::jager_image);
			LoadImageByMemory(p_device, kaidImage, sizeof(kaidImage), &OperatorIcons::kaid_image);
			LoadImageByMemory(p_device, kaliImage, sizeof(kaliImage), &OperatorIcons::kali_image);
			LoadImageByMemory(p_device, kapkanImage, sizeof(kapkanImage), &OperatorIcons::kapkan_image);
			LoadImageByMemory(p_device, lesionImage, sizeof(lesionImage), &OperatorIcons::lesion_image);
			LoadImageByMemory(p_device, lionImage, sizeof(lionImage), &OperatorIcons::lion_image);
			LoadImageByMemory(p_device, maestroImage, sizeof(maestroImage), &OperatorIcons::maestro_image);
			LoadImageByMemory(p_device, maverickImage, sizeof(maverickImage), &OperatorIcons::maverick_image);
			LoadImageByMemory(p_device, melusiImage, sizeof(melusiImage), &OperatorIcons::melusi_image);
			LoadImageByMemory(p_device, miraImage, sizeof(miraImage), &OperatorIcons::mira_image);
			LoadImageByMemory(p_device, montagneImage, sizeof(montagneImage), &OperatorIcons::montagne_image);
			LoadImageByMemory(p_device, mozzieImage, sizeof(mozzieImage), &OperatorIcons::mozzie_image);
			LoadImageByMemory(p_device, muteImage, sizeof(muteImage), &OperatorIcons::mute_image);
			LoadImageByMemory(p_device, nokkImage, sizeof(nokkImage), &OperatorIcons::nokk_image);
			LoadImageByMemory(p_device, nomadImage, sizeof(nomadImage), &OperatorIcons::nomad_image);
			LoadImageByMemory(p_device, oryxImage, sizeof(oryxImage), &OperatorIcons::oryx_image);
			LoadImageByMemory(p_device, osaImage, sizeof(osaImage), &OperatorIcons::osa_image);
			LoadImageByMemory(p_device, pulseImage, sizeof(pulseImage), &OperatorIcons::pulse_image);
			LoadImageByMemory(p_device, ramImage, sizeof(ramImage), &OperatorIcons::ram_image);
			LoadImageByMemory(p_device, recruitImage, sizeof(recruitImage), &OperatorIcons::recruit_image);
			LoadImageByMemory(p_device, recruit_blueImage, sizeof(recruit_blueImage), &OperatorIcons::recruit_blue_image);
			LoadImageByMemory(p_device, recruit_greenImage, sizeof(recruit_greenImage), &OperatorIcons::recruit_green_image);
			LoadImageByMemory(p_device, recruit_orangeImage, sizeof(recruit_orangeImage), &OperatorIcons::recruit_orange_image);
			LoadImageByMemory(p_device, recruit_redImage, sizeof(recruit_redImage), &OperatorIcons::recruit_red_image);
			LoadImageByMemory(p_device, recruit_yellowImage, sizeof(recruit_yellowImage), &OperatorIcons::recruit_yellow_image);
			LoadImageByMemory(p_device, rookImage, sizeof(rookImage), &OperatorIcons::rook_image);
			LoadImageByMemory(p_device, sensImage, sizeof(sensImage), &OperatorIcons::sens_image);
			LoadImageByMemory(p_device, sentryImage, sizeof(sentryImage), &OperatorIcons::sentry_image);
			LoadImageByMemory(p_device, sledgeImage, sizeof(sledgeImage), &OperatorIcons::sledge_image);
			LoadImageByMemory(p_device, smokeImage, sizeof(smokeImage), &OperatorIcons::smoke_image);
			LoadImageByMemory(p_device, solisImage, sizeof(solisImage), &OperatorIcons::solis_image);
			LoadImageByMemory(p_device, strikerImage, sizeof(strikerImage), &OperatorIcons::striker_image);
			LoadImageByMemory(p_device, tachankaImage, sizeof(tachankaImage), &OperatorIcons::tachanka_image);
			LoadImageByMemory(p_device, thatcherImage, sizeof(thatcherImage), &OperatorIcons::thatcher_image);
			LoadImageByMemory(p_device, thermiteImage, sizeof(thermiteImage), &OperatorIcons::thermite_image);
			LoadImageByMemory(p_device, thornImage, sizeof(thornImage), &OperatorIcons::thorn_image);
			LoadImageByMemory(p_device, thunderbirdImage, sizeof(thunderbirdImage), &OperatorIcons::thunderbird_image);
			LoadImageByMemory(p_device, tubaraoImage, sizeof(tubaraoImage), &OperatorIcons::tubarao_image);
			LoadImageByMemory(p_device, twitchImage, sizeof(twitchImage), &OperatorIcons::twitch_image);
			LoadImageByMemory(p_device, valkyrieImage, sizeof(valkyrieImage), &OperatorIcons::valkyrie_image);
			LoadImageByMemory(p_device, vigilImage, sizeof(vigilImage), &OperatorIcons::vigil_image);
			LoadImageByMemory(p_device, wamaiImage, sizeof(wamaiImage), &OperatorIcons::wamai_image);
			LoadImageByMemory(p_device, wardenImage, sizeof(wardenImage), &OperatorIcons::warden_image);
			LoadImageByMemory(p_device, yingImage, sizeof(yingImage), &OperatorIcons::ying_image);
			LoadImageByMemory(p_device, zeroImage, sizeof(zeroImage), &OperatorIcons::zero_image);
			LoadImageByMemory(p_device, zofiaImage, sizeof(zofiaImage), &OperatorIcons::zofia_image);
			LoadImageByMemory(p_device, skoposImage, sizeof(skoposImage), &OperatorIcons::skopos_image);

			LoadImageByMemory(p_device, Adrenal_SurgeImage, sizeof(Adrenal_SurgeImage), &GadgetIcons::Adrenal_Surge_image);
			LoadImageByMemory(p_device, ADSImage, sizeof(ADSImage), &GadgetIcons::ADS_image);
			LoadImageByMemory(p_device, AirjabImage, sizeof(AirjabImage), &GadgetIcons::Airjab_image);
			LoadImageByMemory(p_device, Argus_CameraImage, sizeof(Argus_CameraImage), &GadgetIcons::Argus_Camera_image);
			LoadImageByMemory(p_device, Assurya_Laser_GateImage, sizeof(Assurya_Laser_GateImage), &GadgetIcons::Assurya_Laser_Gate_image);
			LoadImageByMemory(p_device, BansheeImage, sizeof(BansheeImage), &GadgetIcons::Banshee_image);
			LoadImageByMemory(p_device, Barbed_WireImage, sizeof(Barbed_WireImage), &GadgetIcons::Barbed_Wire_image);
			LoadImageByMemory(p_device, Black_EyeImage, sizeof(Black_EyeImage), &GadgetIcons::Black_Eye_image);
			LoadImageByMemory(p_device, Blitz_ShieldImage, sizeof(Blitz_ShieldImage), &GadgetIcons::Blitz_Shield_image);
			LoadImageByMemory(p_device, Breach_ChargeImage, sizeof(Breach_ChargeImage), &GadgetIcons::Breach_Charge_image);
			LoadImageByMemory(p_device, BU_GIImage, sizeof(BU_GIImage), &GadgetIcons::BU_GI_image);
			LoadImageByMemory(p_device, Bulletproof_CamImage, sizeof(Bulletproof_CamImage), &GadgetIcons::Bulletproof_Cam_image);
			LoadImageByMemory(p_device, CameraImage, sizeof(CameraImage), &GadgetIcons::Camera_image);
			LoadImageByMemory(p_device, CCE_ShieldImage, sizeof(CCE_ShieldImage), &GadgetIcons::CCE_Shield_image);
			LoadImageByMemory(p_device, ClaymoreImage, sizeof(ClaymoreImage), &GadgetIcons::Claymore_image);
			LoadImageByMemory(p_device, Cluster_ChargeImage, sizeof(Cluster_ChargeImage), &GadgetIcons::Cluster_Charge_image);
			LoadImageByMemory(p_device, DefuserImage, sizeof(DefuserImage), &GadgetIcons::Defuser_image);
			LoadImageByMemory(p_device, DroneImage, sizeof(DroneImage), &GadgetIcons::Drone_image);
			LoadImageByMemory(p_device, EE_ONE_DImage, sizeof(EE_ONE_DImage), &GadgetIcons::EE_ONE_D_image);
			LoadImageByMemory(p_device, Ela_MineImage, sizeof(Ela_MineImage), &GadgetIcons::Ela_Mine_image);
			LoadImageByMemory(p_device, ElectroclawImage, sizeof(ElectroclawImage), &GadgetIcons::Electroclaw_image);
			LoadImageByMemory(p_device, ERC_7Image, sizeof(ERC_7Image), &GadgetIcons::ERC_7_image);
			LoadImageByMemory(p_device, Evil_EyeImage, sizeof(Evil_EyeImage), &GadgetIcons::Evil_Eye_image);
			LoadImageByMemory(p_device, EYENOX_MODELL_IIIImage, sizeof(EYENOX_MODELL_IIIImage), &GadgetIcons::EYENOX_MODELL_III_image);
			LoadImageByMemory(p_device, F_NATTImage, sizeof(F_NATTImage), &GadgetIcons::F_NATT_image);
			LoadImageByMemory(p_device, Flores_DroneImage, sizeof(Flores_DroneImage), &GadgetIcons::Flores_Drone_image);
			LoadImageByMemory(p_device, Frag_GrenadeImage, sizeof(Frag_GrenadeImage), &GadgetIcons::Frag_Grenade_image);
			LoadImageByMemory(p_device, Frost_TrapImage, sizeof(Frost_TrapImage), &GadgetIcons::Frost_Trap_image);
			LoadImageByMemory(p_device, Gemini_ReplicatorImage, sizeof(Gemini_ReplicatorImage), &GadgetIcons::Gemini_Replicator_image);
			LoadImageByMemory(p_device, GoyoImage, sizeof(GoyoImage), &GadgetIcons::Goyo_image);
			LoadImageByMemory(p_device, Grim_BeesImage, sizeof(Grim_BeesImage), &GadgetIcons::Grim_Bees_image);
			LoadImageByMemory(p_device, GuImage, sizeof(GuImage), &GadgetIcons::Gu_image);
			LoadImageByMemory(p_device, Hard_Breach_DeviceImage, sizeof(Hard_Breach_DeviceImage), &GadgetIcons::Hard_Breach_Device_image);
			LoadImageByMemory(p_device, Heartbeat_SensorImage, sizeof(Heartbeat_SensorImage), &GadgetIcons::Heartbeat_Sensor_image);
			LoadImageByMemory(p_device, HELImage, sizeof(HELImage), &GadgetIcons::HEL_image);
			LoadImageByMemory(p_device, ImpactImage, sizeof(ImpactImage), &GadgetIcons::Impact_image);
			LoadImageByMemory(p_device, IQ_ScannerImage, sizeof(IQ_ScannerImage), &GadgetIcons::IQ_Scanner_image);
			LoadImageByMemory(p_device, KapkanImage, sizeof(KapkanImage), &GadgetIcons::Kapkan_image);
			LoadImageByMemory(p_device, Kiba_BarrierImage, sizeof(Kiba_BarrierImage), &GadgetIcons::Kiba_Barrier_image);
			LoadImageByMemory(p_device, Kludge_DroneImage, sizeof(Kludge_DroneImage), &GadgetIcons::Kludge_Drone_image);
			LoadImageByMemory(p_device, KonaImage, sizeof(KonaImage), &GadgetIcons::Kona_image);
			LoadImageByMemory(p_device, Logic_BombImage, sizeof(Logic_BombImage), &GadgetIcons::Logic_Bomb_image);
			LoadImageByMemory(p_device, LV_Explosive_LanceImage, sizeof(LV_Explosive_LanceImage), &GadgetIcons::LV_Explosive_Lance_image);
			LoadImageByMemory(p_device, Mag_NETImage, sizeof(Mag_NETImage), &GadgetIcons::Mag_NET_image);
			LoadImageByMemory(p_device, Mozzie_PestImage, sizeof(Mozzie_PestImage), &GadgetIcons::Mozzie_Pest_image);
			LoadImageByMemory(p_device, Mute_JammerImage, sizeof(Mute_JammerImage), &GadgetIcons::Mute_Jammer_image);
			LoadImageByMemory(p_device, Nitro_CellImage, sizeof(Nitro_CellImage), &GadgetIcons::Nitro_Cell_image);
			LoadImageByMemory(p_device, Observation_BlockerImage, sizeof(Observation_BlockerImage), &GadgetIcons::Observation_Blocker_image);
			LoadImageByMemory(p_device, Osa_ShieldImage, sizeof(Osa_ShieldImage), &GadgetIcons::Osa_Shield_image);
			LoadImageByMemory(p_device, Pantheon_Avatare_V10Image, sizeof(Pantheon_Avatare_V10Image), &GadgetIcons::Pantheon_Avatare_V10_image);
			LoadImageByMemory(p_device, PlaceholderImage, sizeof(PlaceholderImage), &GadgetIcons::Placeholder_image);
			LoadImageByMemory(p_device, PrismaImage, sizeof(PrismaImage), &GadgetIcons::Prisma_image);
			LoadImageByMemory(p_device, Proximity_AlarmImage, sizeof(Proximity_AlarmImage), &GadgetIcons::Proximity_Alarm_image);
			LoadImageByMemory(p_device, RazorbloomImage, sizeof(RazorbloomImage), &GadgetIcons::Razorbloom_image);
			LoadImageByMemory(p_device, Rook_ArmorImage, sizeof(Rook_ArmorImage), &GadgetIcons::Rook_Armor_image);
			LoadImageByMemory(p_device, SELMAImage, sizeof(SELMAImage), &GadgetIcons::SELMA_image);
			LoadImageByMemory(p_device, ShieldImage, sizeof(ShieldImage), &GadgetIcons::Shield_image);
			LoadImageByMemory(p_device, Shock_DroneImage, sizeof(Shock_DroneImage), &GadgetIcons::Shock_Drone_image);
			LoadImageByMemory(p_device, Shock_WireImage, sizeof(Shock_WireImage), &GadgetIcons::Shock_Wire_image);
			LoadImageByMemory(p_device, Smart_GlassesImage, sizeof(Smart_GlassesImage), &GadgetIcons::Smart_Glasses_image);
			LoadImageByMemory(p_device, Smoke_GrenadeImage, sizeof(Smoke_GrenadeImage), &GadgetIcons::Smoke_Grenade_image);
			LoadImageByMemory(p_device, Spec_IO_Electro_SensorImage, sizeof(Spec_IO_Electro_SensorImage), &GadgetIcons::Spec_IO_Electro_Sensor_image);
			LoadImageByMemory(p_device, Thermite_BreachImage, sizeof(Thermite_BreachImage), &GadgetIcons::Thermite_Breach_image);
			LoadImageByMemory(p_device, TraxImage, sizeof(TraxImage), &GadgetIcons::Trax_image);
			LoadImageByMemory(p_device, X_KairosImage, sizeof(X_KairosImage), &GadgetIcons::X_Kairos_image);
			LoadImageByMemory(p_device, Yokai_DroneImage, sizeof(Yokai_DroneImage), &GadgetIcons::Yokai_Drone_image);
			LoadImageByMemory(p_device, Zoto_CanisterImage, sizeof(Zoto_CanisterImage), &GadgetIcons::Zoto_Canister_image);
			LoadImageByMemory(p_device, Black_MirrorImage, sizeof(Black_MirrorImage), &GadgetIcons::Black_Mirror_image);
			LoadImageByMemory(p_device, CastleImage, sizeof(CastleImage), &GadgetIcons::Castle_image);
			LoadImageByMemory(p_device, SenseImage, sizeof(SenseImage), &GadgetIcons::Sense_image);
			LoadImageByMemory(p_device, YingImage, sizeof(YingImage), &GadgetIcons::Ying_image);

			Render::LoadImages();
			Render::LoadGadgetImages();
		}
		else
			return p_present(p_swap_chain, sync_interval, flags);
	}
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();

	
	if (!scimitar::local_controller)
	scimitar::game_manager::get_instance()->get_local_controller();


	ImGui::NewFrame();

	if (Globals->UserInterface.bShow)
	Render::user_interface();

	static bool showConsole = false;

	if (GetAsyncKeyState(VK_HOME) & 1) {

		showConsole = !showConsole;
	}

	if (showConsole) Render::RenderConsole();

	if (scimitar::round_state::get_instance() == 2 || scimitar::round_state::get_instance() == 3) {

		BlindEye::Renderables(Globals->Visuals.bEnable || Globals->Misc.bAutoMelee);
	}

	BlindEye::Health_Message(Globals->Visuals.bHealthLog);
	BlindEye::gadget_renderables(Globals->Visuals.bGadget);
	Render::render_tracers();
	Render::Log();
	Render::Background();


	ImGui::Render();

	BlindEye::fov_changer(Globals->Player.fFoV);
	BlindEye::display_options_effects();
	BlindEye::chat_spammer();
	
	if (scimitar::round_state::get_instance() == 2 || scimitar::round_state::get_instance() == 3) {
		
	
		BlindEye::long_melee(Globals->Misc.bLongMelee);
		BlindEye::self_revive(Globals->Player.bSelfRevive);
		BlindEye::no_clip(Globals->Misc.bNoClip);
		BlindEye::third_person(Globals->Player.bThirdperson);
		BlindEye::rage_bot(Globals->Ragebot.bEnable);
		BlindEye::run_and_shoot(Globals->Player.bRunAndShoot);
		if (Globals->Player.bSpeed)
		 BlindEye::force_movement(Globals->Player.fSpeedval);

		if (Globals->Weapon.bAutoReload) {
			scimitar::game_manager::get_instance()->get_local_controller()->get_pawn()->get_entity()->get_weapon_component()->auto_reload();
		}
	}

	scimitar::unlock_all();

	p_context->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

	return p_present(p_swap_chain, sync_interval, flags);
}

auto __stdcall d3d11::EjectThread(LPVOID lpParameter) -> DWORD {
	Sleep(100);
	FreeLibraryAndExitThread(d3d11::dll_handle, 0);
	Sleep(100);
	return 0;
}


auto __stdcall d3d11::main() -> int
{


	static auto flag{ false };
	if (!flag)
	{
		{



			utils::memory::image_base = utils::importer::get_safe_module(_x(L"RainbowSix_DX11.exe"));
			utils::memory::text_size = utils::importer::get_section_size(utils::memory::image_base, _x(".text"));
			utils::memory::rdata_size = utils::importer::get_section_size(utils::memory::image_base, _x(".rdata"));
			utils::memory::rdata_virtualaddress = utils::importer::get_virtual_address(utils::memory::image_base, _x(".rdata"));

		}

		{

			hooks::init();
			scimitar::Init();
			//BlindEye::update_spread();
		}
	}


	if (!d3d11::get_present_pointer())
	{
		return 1;
	}

	MH_STATUS status = MH_Initialize();
	if (status != MH_OK)
	{
		return 1;
	}

	if (MH_CreateHook(reinterpret_cast<void**>(p_present_target), &detour_present, reinterpret_cast<void**>(&p_present)) != MH_OK) {
		return 1;
	}

	if (MH_EnableHook(p_present_target) != MH_OK) {
		return 1;
	}

	while (true) {
		Sleep(16);

		if (GetAsyncKeyState(VK_INSERT) & 1) {
			Globals->UserInterface.bShow = !Globals->UserInterface.bShow;
		}

		if (GetAsyncKeyState(VK_END)) {

			break;
		}
	}

	//Cleanup
	if (MH_DisableHook(MH_ALL_HOOKS) != MH_OK) {
		return 1;
	}
	if (MH_Uninitialize() != MH_OK) {
		return 1;
	}

	ImGui_ImplDX11_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();

	if (mainRenderTargetView) { mainRenderTargetView->Release(); mainRenderTargetView = NULL; }
	if (p_context) { p_context->Release(); p_context = NULL; }
	if (p_device) { p_device->Release(); p_device = NULL; }
	SetWindowLongPtr(window, GWLP_WNDPROC, (LONG_PTR)(oWndProc));

	CreateThread(0, 0, EjectThread, 0, 0, 0);

	return 0;
}