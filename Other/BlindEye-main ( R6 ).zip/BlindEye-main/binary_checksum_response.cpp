#include "hooks.hpp"

#include "SpoofCall/spoof_call.hpp"

__int64 hooks::binary_checksum_response(__int64 a1, __int64 a2)
{
	static std::string response{ };
	response = R"({"status":"OK"})";

	utils::str::write_str(*reinterpret_cast<void**>(a2 + 0x30), response.c_str());

	return FUNCTION(calls::binary_checksum_response, a1, a2);
}