#include "BlindEye.hpp"

static std::vector<scimitar::Entity*> cachedEntities;
static size_t entityIndex = 0;
static const size_t batchSize = 1000;
static std::chrono::system_clock::time_point lastChacheTime;
static std::unordered_map<scimitar::Entity*, std::chrono::steady_clock::time_point> entityStateTimer;
static std::vector<scimitar::Entity*> kapkanEntities;

auto BlindEye::gadget_renderables(bool enable) -> void {


    if (scimitar::round_state::get_instance() == 5) {

        return;
    }

    if (!enable) return;


    if (scimitar::round_state::get_instance() == 0) {

        cachedEntities.clear();
        entityIndex = 0;
    }

    auto World = scimitar::World::get_instance();
    auto List = World->get_entity_list();

    auto now = std::chrono::system_clock::now();
    std::chrono::milliseconds delay(100);


    if (now >= lastChacheTime + delay) {
        if (scimitar::round_state::get_instance() != 0 && scimitar::round_state::get_instance() != 5) {
            size_t processedEntities = 0;


            for (size_t i = entityIndex; i < List.second && processedEntities < batchSize; ++i) {
                auto Entity = *reinterpret_cast<scimitar::Entity**>(List.first + (0x8 * i));
                if (!utils::memory::valid_pointer(Entity)) {
                    continue;
                }

                auto pEntityptr = *reinterpret_cast<scimitar::Entity**>(Entity);
                if (!utils::memory::valid_pointer(pEntityptr)) continue;

                if (std::find(cachedEntities.begin(), cachedEntities.end(), Entity) == cachedEntities.end()) {
                    cachedEntities.push_back(Entity);
                }

                

                processedEntities++;
            }


            entityIndex += processedEntities;


            if (entityIndex >= List.second) {
                entityIndex = 0;
            }

            lastChacheTime = now;
        }
    }

    for (auto Entity : cachedEntities) {

        auto pEntityptr = *reinterpret_cast<scimitar::Entity**>(Entity);
        if (!utils::memory::valid_pointer(pEntityptr)) continue;

        const char* gadget_name = " ";
        auto hash = pEntityptr->get_hash();
        auto secondary_hash = pEntityptr->get_second_hash();
        auto third_hash = pEntityptr->get_third_hash();
        auto eight_hash = pEntityptr->get_fourth_hash();
        auto nineth_hash = pEntityptr->get_fifth_hash();
        auto tenth_hash = pEntityptr->get_sixth_hash();
		auto test = pEntityptr->get_test_Hash();
    
		switch (hash)
		{

		case 0xBE04CFBE:  // Drone
			gadget_name = "Drone";

	

			break;
		case 0xBE08380E:  // Claymore
			gadget_name = "Claymore";

			break;

		case 0xBE1D9359:  // Camera

			gadget_name = "Camera";


			break;

		case 0xBF2A1AB6:  // Frost Trap
			gadget_name = "Frost Trap";

			break;

		case 0xBDA55196:  // Nitro Cell
			gadget_name = "Nitro Cell";


			break;

		case 0xBE19999A:  // Razorbloom
			if (secondary_hash == 0xBE19999A && third_hash == 0xBE19999A) {
				gadget_name = "Razorbloom";

			}
			break;
		case 0xBDCCCCCD:
			if (secondary_hash == 0xBE051EB8) {  // Proximity Alarm
				gadget_name = "Proximity Alarm";

			}
			else if (third_hash == 0xBDA3D70A) {  // Gu
				gadget_name = "Gu";

			}
			else if (secondary_hash == 0xBDCCCCCD && third_hash == 0xBD4CCCCD) {  // Airjab
				gadget_name = "Airjab";

			}
			else if (secondary_hash == 0xBDCCCCCD && third_hash == 0xBCE56042) {  // Electroclaw
				gadget_name = "Electroclaw";

			}
			else if (secondary_hash == 0xBDCCCCCD && third_hash == 0xbf000000) {  // Kali
				gadget_name = "LV Explosive Lance";

			}
			break;

		case 0xBD5EA2AD:

			if (secondary_hash == 0xbd6533de && tenth_hash == 0x8b89e1be) {
				gadget_name = "Ela Mine"; //ELA MINE
			}

			else if (secondary_hash == 0xbd6533de && tenth_hash == 0x48d31aa) {
				gadget_name = "Zoto Canister"; //Zoto Canister
			}

			break;
		case 0xBE8175D6:

			if (secondary_hash == 0xBE800000 && tenth_hash == 0x2a0cc9ad) {
				gadget_name = "Kona"; //KONA
			}
			else if (secondary_hash == 0xBE800000 && tenth_hash == 0x8a2bf31e) {
				gadget_name = "Banshee"; //Banshee
			}

			else if (secondary_hash == 0xBE6DF377) {  // Evil Eye
				gadget_name = "Evil Eye";

			}
			break;

		case 0xC0243063:
			gadget_name = "Kapkan";
			break;
		case 0xBE03C799:
			if (secondary_hash == 0xBE37DD6D && third_hash == 0xBD7AFC85) {  // Shock Drone
				gadget_name = "Shock Drone";

			}
			else if (secondary_hash == 0xBDE147AE && third_hash == 0xBD7AFC85) {  // Kludge Drone
				gadget_name = "Kludge Drone";

			}
			break;

		case 0xBD75C28F:

			if (tenth_hash == 0x7c9c5171) {  // BLACK EYE
				gadget_name = "Black Eye";

			}
			else if (tenth_hash == 0xa6bd7eaa) {  // GRIM BEES
				gadget_name = "Grim Bees";

			}
			break;

		case 0xBE6147AE:
			if (secondary_hash == 0xBE05152B && third_hash == 0xBC09D702) {
				gadget_name = "Mute Jammer";

			}
			else if (secondary_hash == 0xbe800000 && tenth_hash == 0x1c8842fc) {
				gadget_name = "Goyo";  //works banshee GOYO SAME HASH NEED MORE FILTER
			}
			break;

		case 0xBE800000:
			if (secondary_hash == 0xBE570A3D && third_hash == 0xBD8F5C29) {  // Flores Drone

				if (pEntityptr->health_state() == 4) continue;

				
				gadget_name = "Flores Drone";

			}


			else if (secondary_hash == 0xbe19999a && tenth_hash == 0xdf6a1f88) {
				gadget_name = "Assurya Laser Gate"; //Bulletproof Cam same hash as assurya laser gate
			}

			else if (secondary_hash == 0xbe19999a && tenth_hash == 0x4ff3271f) {
				gadget_name = "Bulletproof Cam"; //Bulletproof Cam same hash as assurya laser gate
			}

			else if (secondary_hash == 0xBF000000 && third_hash == 0xBC23D70A) {  // BU-GI
				gadget_name = "BU-GI";

			}

			break;
		case 0xBD37E96A:  // Smoke Grenade
			if (secondary_hash == 0xbe135938 && tenth_hash == 0x6a3fdcbc) {  // Smoke
				gadget_name = "Smoke Grenade";

			}
			break;

		case 0xBED45CB0:  // Rook Armor
			gadget_name = "Rook Armor";

			break;

		case 0xBF133333:  // SELMA
			gadget_name = "SELMA";

			break;

		case 0xBDE60584:  // Cluster Charge
			gadget_name = "Cluster Charge";

			break;

		case 0xBE23D70A:  // Argus Camera
			gadget_name = "Argus Camera";

			break;
		case 0xBE4C7BA0:
			if (secondary_hash == 0xbe422884 && tenth_hash == 0x9b2cb09b) {  // ADS
				gadget_name = "ADS";
			}
			break;
		case 0xBF3FFFA4:  // Shield
			if (secondary_hash == 0xbed1eb85 && tenth_hash == 0x396652cd) {
				gadget_name = "Shield";

			}
			break;
		case 0xBDE56042:
			if (secondary_hash == 0x3d8f5c29 && tenth_hash == 0x50237ac5) {
				gadget_name = "Osa Shield";
			}
			break;

		case 0xBE99B404:  // Thermite Breach
			gadget_name = "Thermite Breach";

			break;

		case 0xBE051EB8:  // Yokai Drone
			if (secondary_hash == 0xBDF5C28F && third_hash == 0xBCA3D70A) {
				gadget_name = "Yokai Drone";

			}
			break;

		case 0xBDADF6C0:  // IQ Scanner
			gadget_name = "IQ Scanner";

			break;

		case 0xBE8F18C2:  // Shock Wire
			gadget_name = "Shock Wire";

			break;

		case 0xBDF5C28F:  // F-NATT and X-Kairos
			if (secondary_hash == 0xBDD70A3D && third_hash == 0x0) {
				gadget_name = "F-NATT";

			}
			else if (secondary_hash == 0xBDF5C28F && third_hash == 0x0) {
				gadget_name = "X-Kairos";

			}
			break;

		case 0xBECCCCCD:  // Trax and Prisma
			if (secondary_hash == 0xBECCCCCD && third_hash == 0xBDB73BF8) {
				gadget_name = "Trax";

			}
			else if (secondary_hash == 0xBECCCCCD && third_hash == 0x0) {
				gadget_name = "Prisma";

			}
			break;

		case 0xBE7C74FD:  // Breach Charge
			if (secondary_hash == 0xBEBF15C6 && third_hash == 0xBCA51D58) {
				gadget_name = "Breach Charge";

			}
			break;

		case 0xBE48B952:
			gadget_name = "Blitz Shield"; // works
			break;
		case 0xBF000000:
			if (secondary_hash == 0xBF000000 && tenth_hash == 0xc4e8c88b) {
				gadget_name = "EE-ONE-D"; //EE-ONE-D
			}
			else if (secondary_hash == 0xBF000000 && tenth_hash == 0x2e862811) {
				gadget_name = "Adrenal Surge"; //Adrenal Surge
			}
			break;
		case 0xBDE147AE:
			if (secondary_hash == 0xbda3d70a && third_hash == 0xbca3d70a) {
				gadget_name = "Logic Bomb"; //works
			}
			break;
		case 0xBF99999A:  // Kiba Barrier
			if (secondary_hash == 0xBF99999A && third_hash == 0xBCCCCCCD) {
				gadget_name = "Kiba Barrier";

			}
			break;

		case 0xBCC44052:
			if (secondary_hash == 0xbcc46e7b && tenth_hash == 0x2b414127) {
				gadget_name = "HEL"; // NOKK
			}

			break;
		case 0xBCF63F60:
			if (secondary_hash == 0xbe9587b2 && tenth_hash == 0x64724c16) {
				gadget_name = "Pantheon-Avatare V10"; //WORKS
			}
			break;
		case 0xBC23D70A:
			if (secondary_hash == 0xbd8f5c29 && tenth_hash == 0x363a3b24) {
				gadget_name = "Spec-IO Electro-Sensor"; // SOLIS
			}
			else if (secondary_hash == 0xbd8f5c29 && tenth_hash == 0x2b42ece6) {
				gadget_name = "Smart Glasses"; // WARDEN
			}
			else if (secondary_hash == 0xbd8f5c29 && tenth_hash == 0xa6a94a16) {
				gadget_name = "EYENOX-MODELL III"; // JACKAL
			}
			break;
		case 0xBEB45F59:
			if (secondary_hash == 0xbeea72bb && third_hash == 0xbc813aa0 && tenth_hash == 0x7bc75b93) { // SAME SECONDARY AND THIRD HASH AS DEFUSING
				gadget_name = "Heartbeat Sensor"; // PULSE
			}
			break;

		case 0xBF4C02A0:
			if (secondary_hash == 0xBEBEBFAB && third_hash == 0xBE9ACAE1) {

				gadget_name = "Black Mirror";
			}
			break;

		case 0xBDB851EC:  // Mag-NET
			if (secondary_hash == 0xBDB851EC && third_hash == 0x0) {
				gadget_name = "Mag-NET";

			}
			break;

		case 0xC0400000:  // Observation Blocker
			if (secondary_hash == 0xBC75C28F && third_hash == 0xBF000000) {
				gadget_name = "Observation Blocker";

			}
			break;

		case 0xBEDC28F6:  // Hard Breach Device
			if (secondary_hash == 0xBEDC28F6 && third_hash == 0xBE051EB8) {
				gadget_name = "Hard Breach Device";

			}
			break;

		case 0xBEAE147B:
			if (secondary_hash == 0xbfa66666 && tenth_hash == 0x27c61c80) {
				gadget_name = "CCE Shield"; //BEAE147B
			}

			break;

		case 0xbd4ccccd:
			if (secondary_hash == 0xbd4ccccd && tenth_hash == 0xf948e73f) {
				gadget_name = "Mozzie Pest";
			}

			break;

		case 0xbf800000:
			if (secondary_hash == 0xbf800000 && tenth_hash == 0x8ae6facb) {
				gadget_name = "ERC-7"; //VIGIL
			}
			else if (secondary_hash == 0xbf800000 && eight_hash == 0x924d37b0) {
				gadget_name = "ERC-7"; //VIGIL
			}
			break;
		case 0xBD17BD90:
			if (secondary_hash == 0xbd17bd90 && tenth_hash == 0xf9498252) {

				gadget_name = "Frag Grenade";
			}
			else if (secondary_hash == 0xbd17bd90 && third_hash == 0xbd03d992) {
				gadget_name = "Impact";
			}
			break;


		}

		switch (tenth_hash)
		{
		case 0xa7366ca6:
			gadget_name = "Defuser";

		break;

		case 0x8f4197b4:
			gadget_name = "Barbed Wire";
			break;
		}


        ubiVector2 screen;

        if (scimitar::world_to_screen(pEntityptr->Origin(), screen)) {

			Render::DrawGadgetIcon(gadget_name, pEntityptr->Origin());
        }
    }
}