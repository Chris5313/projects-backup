#include "BlindEye.hpp"

inline std::chrono::time_point<std::chrono::system_clock> lastMessageTime;
inline bool messageReady = true;

auto BlindEye::chat_spammer() -> void {
	

	auto now = std::chrono::system_clock::now();

	std::chrono::milliseconds delay(25 * 10);

	if (!messageReady && now < lastMessageTime + delay) {

		return;
	}

	if (Globals->Misc.teamChat) {

		int tChat = 1;
		scimitar::chat_message(&Globals->Misc.chatMessage, &tChat);

		//TeamSpammer(a1, &game::chatMessage, 1);

	}
	if (Globals->Misc.allChat) {

		int aChat = 0;
		scimitar::chat_message(&Globals->Misc.chatMessage, &aChat);

		//AllSpammer(a1, &game::chatMessage);
	}

	lastMessageTime = std::chrono::system_clock::now();
	messageReady = false;
};