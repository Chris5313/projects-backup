#include "BlindEye.hpp"

auto BlindEye::Renderables(bool enable) -> void
{

	if (!enable) return;

	auto game_manager = scimitar::game_manager::get_instance();

	auto controller_list = game_manager->get_controller_list();

	auto local_conroller = game_manager->get_local_controller();


	for (int i = 0; i < controller_list.second; ++i)
	{

		auto controller = *reinterpret_cast<scimitar::Controller**>(controller_list.first + (0x8 * i));

		if (!utils::memory::valid_pointer(controller)) continue;

		auto pawn = controller->get_pawn();
		if (!utils::memory::valid_pointer(pawn)) continue;


		auto entity = pawn->get_entity();
		if (!utils::memory::valid_pointer(entity)) continue;

		auto local_pawn = local_conroller->get_pawn();

		auto local_entity = local_pawn->get_entity();

		if (controller == local_conroller) continue;

		auto replication = controller->get_replication();
		const char* user_name = replication->get_player_name();
		auto [CTU, OP] = replication->get_ctu_op();
		const char* Operator = scimitar::OPs[CTU][OP];

		uint32_t health = entity->get_health();

		int distance = calculateDistance(entity->Origin(), scimitar::get_camera_position());

		if (Globals->Visuals.bTeamCheck && Globals->Visuals.bEnable) {

			if (controller->get_alliance() == local_conroller->get_alliance()) continue;

		}
		


		if (Globals->Visuals.bSkeleton && Globals->Visuals.bEnable) {
			for (std::pair<scimitar::BipedBoneID, scimitar::BipedBoneID> Bones : scimitar::BonesPair) {
				auto ID1 = scimitar::BipedBoneID(Bones.first);
				auto ID2 = scimitar::BipedBoneID(Bones.second);

				ubiVector4 Pos1 = pawn->get_bone_pos(ID1);
				ubiVector4 Pos2 = pawn->get_bone_pos(ID2);

				ubiVector4 dest = Pos1;
				ubiVector4 dest2 = Pos2;

				ubiVector2 Screen1, Screen2;

				if (scimitar::world_to_screen(Pos1, Screen1) && scimitar::world_to_screen(Pos2, Screen2)) {



					if (Globals->Visuals.iVisibleType == 0) {



						Render::draw_skeleton(ImVec2(Screen1.x, Screen1.y), ImVec2(Screen2.x, Screen2.y), Globals->Visuals.SkeletonRGB, Globals->Visuals.skeletonthickness);

					}


					if (Globals->Visuals.iVisibleType == 1) {




					
						if (scimitar::is_visible(scimitar::get_camera_position(), dest) && scimitar::is_visible(scimitar::get_camera_position(), dest2))
						{

							Render::draw_skeleton(ImVec2(Screen1.x, Screen1.y), ImVec2(Screen2.x, Screen2.y), Globals->Visuals.SkeletonVisRGB, Globals->Visuals.skeletonthickness);

							
						}
						else {
							Render::draw_skeleton(ImVec2(Screen1.x, Screen1.y), ImVec2(Screen2.x, Screen2.y), Globals->Visuals.SkeletonRGB, Globals->Visuals.skeletonthickness);
						} 

					}

					if (Globals->Visuals.iVisibleType == 2) {

						if (scimitar::is_visible(scimitar::get_camera_position(), dest) && scimitar::is_visible(scimitar::get_camera_position(), dest2))
						{
							Render::draw_skeleton(ImVec2(Screen1.x, Screen1.y), ImVec2(Screen2.x, Screen2.y), Globals->Visuals.SkeletonVisRGB, Globals->Visuals.skeletonthickness);
						}
						else if (local_conroller->get_pawn()->get_entity()->get_physic_world()->penetrable(scimitar::get_camera_position(), dest) && local_conroller->get_pawn()->get_entity()->get_physic_world()->penetrable(scimitar::get_camera_position(), dest2))
						{
							Render::draw_skeleton(ImVec2(Screen1.x, Screen1.y), ImVec2(Screen2.x, Screen2.y), Globals->Visuals.SkeletonPenRGB, Globals->Visuals.skeletonthickness);
						}
						else {
							Render::draw_skeleton(ImVec2(Screen1.x, Screen1.y), ImVec2(Screen2.x, Screen2.y), Globals->Visuals.SkeletonRGB, Globals->Visuals.skeletonthickness);
						}
					}
				}
			}
		}

		if (Globals->Visuals.bPlayerInformation && Globals->Visuals.bEnable) {

			ubiVector4 entPosHead = pawn->get_bone_pos(scimitar::BipedBoneID::NECK);
			entPosHead.z += 0.2f;
			ubiVector2 screenPosHead;

			if (scimitar::world_to_screen(entPosHead, screenPosHead)) {

				Render::DrawPlayerTags(screenPosHead, health, 125.f, distance, user_name,Operator ,Globals->Visuals.PlayerInformationRGB_1, Globals->Visuals.PlayerInformationRGB_2);
			}





		}




		//

		if (Globals->Misc.bAutoMelee) {
			
			if (distance < 7)
			local_conroller->Melee(local_entity, entity, pawn->get_bone_pos(scimitar::BipedBoneID::NECK));
		}
	}
}

