#include "BlindEye.hpp"




static bool setfalse = false;

void BlindEye::display_options_effects() 
{
	const uintptr_t qword_AAB1400 = *reinterpret_cast<uintptr_t*>(ImageBase + 0xBA5B3C0);
	if (!qword_AAB1400)
		return;

	const uintptr_t Effect = *reinterpret_cast<uintptr_t*>(qword_AAB1400 + 0x8);
	if (!Effect)
		return;

	

	if (!setfalse) {
		Globals->World.Model = false;
		setfalse = true;
	}

	*reinterpret_cast<bool*>(Effect + 0x5C) = !Globals->World.Light;
	*reinterpret_cast<bool*>(Effect + 0x107) = Globals->World.Model;
	*reinterpret_cast<bool*>(Effect + 0x108) = Globals->World.Sky;
	*reinterpret_cast<bool*>(Effect + 0x109) = Globals->World.HUD;
	*reinterpret_cast<bool*>(Effect + 0x104) = Globals->World.Smoke;
	*reinterpret_cast<bool*>(Effect + 0x10C) = Globals->World.Paint;
	*reinterpret_cast<bool*>(Effect + 0x119) = Globals->World.ColorMask;
	*reinterpret_cast<bool*>(Effect + 0x103) = Globals->World.Shadows;


	IColor* skyColorPtr = reinterpret_cast<IColor*>(Effect + 0x160);
	if (!skyColorPtr) return;

	*skyColorPtr = IColor::float_to_icolor(Globals->World.sky_color[0], Globals->World.sky_color[1], Globals->World.sky_color[2], 1.0f );

};