#pragma once
#include <iostream>

#include "ImGui/imgui.h"

#include <Windows.h>

class globals {

public:
	struct userinterface {

		ImFont* Default;

		bool bShow = true;

		bool bDebug;
	} UserInterface;


	struct visuals {


		bool bEnable;
		bool bSkeleton;
		ImVec4 SkeletonPenRGB = { 1.f, 1.f, 0.f, 1.f };  
		ImVec4 SkeletonVisRGB = { 0.f, 1.f, 0.f, 1.f }; 
		ImVec4 SkeletonRGB = { 1.f, 0.f, 0.f, 1.f };     


		
		
		bool bPlayerInformation;
		ImVec4 PlayerInformationRGB_1 = { 1.0f, 0.552941f, 0.074510f, 1.0f };
		ImVec4 PlayerInformationRGB_2 = { 1.0f, 0.513725f, 0.0f, 0.941176f };

		

		int iVisibleType = 0;

		float skeletonthickness = 0.5;

		const char* cVisibleType[3] = { "Off", "isVisible", "isVisible + isPenetrable" };

	
		bool bTeamCheck;

		bool bGadget;
		bool bRainbowESP;

		bool bHealthLog;
		bool bInChat;

		bool bShowIcon;

		ImVec4 GadgetRGB = { 1.f, 0.f, 0.f, 1.f };


	} Visuals;


	struct legitbot {

		bool enableaimbot;

		bool renderfov;

		bool Head;

		float AimbotSmooth = 1.f;

		int fov = 25;

		ImVec4 Color1 = ImVec4(0.0f, 0.90196f, 1.0f, 1.0f);
		ImVec4 Color2 = ImVec4(0.6f, 0.0f, 1.0f, 1.0f);

		bool FoVCheck = true;

		bool rendertarget = true;
		ImVec4 targetcolor = ImVec4(0.6f, 0.0f, 1.0f, 1.0f);


	}Legitbot;


	struct ragebot {

		bool bEnable;

		bool bSilent;

		int iTracerType = 0;
		const char* cTracerType[2] = { "Dots", "Line" };

		int delay = 35;

		bool bDecreaseAmmo;
		bool bSingleFireFix;
		//

		bool bTracer;
		bool bRainbowTracer;
		ImVec4 TracerRGB = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);

	}Ragebot;

	struct weapon {
		

		float fRecoil = 100.f;
		float fSpread = 100.f;

		bool bAutoReload;



	} Weapon;

	struct player {

		float fFoV = 0.0f;

		bool bThirdperson = false;

		bool bRunAndShoot = false;

		bool bSelfRevive = false;

		bool bSpeed;
		float fSpeedval = 5.0f;

	

		int iSelected3p = 0;
		const char* cSelected3p[2] = {
			"Mode: 1",
			"Mode: 2"
		};

	} Player;

	struct misc {



		bool bDroneFly;

		bool bNoClip;

		bool bStickyFlores;

		bool bLongMelee;
		bool bAutoMelee;


		bool teamChat;
		bool allChat;
		char chatMessage1[256] = "BlindEye.io";
		char* chatMessage = chatMessage1;

		bool unlockall;


	}Misc;


	struct antiaim {

		bool bAntiAim = false;

		bool bSlide = true;

		int iAAType = 0;
		const char* cAAType[3] = { "Forward", "Backwards", "Spin" };

		float fSpinSpeed = 20.f;

	} AntiAim;

	struct hotkey {


		bool TESTKEY = false;
		int testkey;
		int TESTINT;

		bool MENUKEY = false;
		int menukey = VK_INSERT;
		int MENUINT = VK_INSERT;

		//Third Person
		bool THIRDPERSONKEY = false;
		int thirdpersonkey;
		int THIRDPERSONINT;

		//melee
		bool MELEEKEY = false;
		int meleekey;
		int MELEEINT;

		//SelfRevive
		bool SELFREVIVEKEY = false;
		int selfrevivekey;
		int SELFREVIVEINT;

	}Hotkey;


	struct world {

		bool Light;
		bool Model = false;
		bool Sky;
		bool HUD;
		bool Smoke;
		bool Paint;
		bool ColorMask;
		bool Shadows;

		float sky_color[4];


	}World;


	struct logs {

		bool bNoCliplog;
		bool bThirdPersonlog;

	}Log;
};

inline std::unique_ptr<globals> Globals = std::make_unique<globals>();