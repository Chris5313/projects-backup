#include "hooks.hpp"

#include "SpoofCall/spoof_call.hpp"

__int64 hooks::active_penalties(__int64 a1, __int64 a2)
{
	auto res = std::string(*(const char**)(a2 + 0x30));

	auto profileID = utils::str::parse_str(res, "profile_id");

	std::string response{ };
	response = utils::str::format_str("{\"profile_id\": %s}", profileID.c_str());

	auto r = *(uint64_t*)(a2 + 0x30);
	utils::str::write_str(reinterpret_cast<void*>(r), response.c_str());

	return FUNCTION(calls::active_penalties, a1, a2);
}