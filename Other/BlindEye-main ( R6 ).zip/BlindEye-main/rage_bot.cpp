#include "BlindEye.hpp"


inline const scimitar::BipedBoneID bones[] = {
  scimitar::NECK,
  scimitar::SPINE,
  scimitar::THORAX,
  scimitar::LUMBAR,
  scimitar::LCLAVICLE,
  scimitar::LSHOULDER,
  scimitar::LELBOW,
  scimitar::LHAND,
  scimitar::RCLAVICLE,
  scimitar::RSHOULDER,
  scimitar::RELBOW,
  scimitar::RHAND,
  scimitar::LHIP,
  scimitar::LKNEE,
  scimitar::LFOOT,
  scimitar::RHIP,
  scimitar::RKNEE,
  scimitar::RFOOT
};

inline const int numBones = sizeof(bones) / sizeof(bones[0]);


auto BlindEye::rage_bot(bool enable) -> void
{
    if (!enable) return;

    auto game_manager = scimitar::game_manager::get_instance();
    auto controller_list = game_manager->get_controller_list();
    auto local_controller = game_manager->get_local_controller();

    float closestDistanceToCrosshair = FLT_MAX;
    ubiVector4 closest_bone;
    ubiVector2 screen_bone;

    ubiVector4 camera_pos;

    bool found_target = false;

    ImVec2 screenCenter(GetSystemMetrics(SM_CXSCREEN) / 2.0f, GetSystemMetrics(SM_CYSCREEN) / 2.0f);

    for (int i = 0; i < controller_list.second; ++i)
    {
        auto controller = *reinterpret_cast<scimitar::Controller**>(controller_list.first + (0x8 * i));
        if (!utils::memory::valid_pointer(controller)) continue;

        auto pawn = controller->get_pawn();
        if (!utils::memory::valid_pointer(pawn)) continue;

        auto entity = pawn->get_entity();
        if (!utils::memory::valid_pointer(entity)) continue;

        auto local_pawn = local_controller->get_pawn();

        auto local_entity = local_pawn->get_entity();

        auto physic_world = local_entity->get_physic_world();

        if (controller == local_controller) continue;

        if (controller->get_alliance() == local_controller->get_alliance()) continue;

        for (int b = 0; b < numBones; b++) {
            scimitar::BipedBoneID boneID = scimitar::BipedBoneID(bones[b]);

            ubiVector4 bonePosition = pawn->get_bone_pos(boneID);



           // if (!scimitar::world_to_screen(bonePosition, screen_bone)) continue;

            bool isVisible;

            if (Globals->Log.bThirdPersonlog) {
                camera_pos = local_controller->get_pawn()->get_bone_pos(scimitar::BipedBoneID::NECK);
            }
            else {
                camera_pos = scimitar::get_camera_position();
            }

            if (Globals->Log.bThirdPersonlog) {
                isVisible = local_controller->get_pawn()->get_entity()->get_physic_world()->penetrable(local_controller->get_pawn()->get_bone_pos(scimitar::BipedBoneID::NECK), bonePosition);
            }
            else {
                isVisible = local_controller->get_pawn()->get_entity()->get_physic_world()->penetrable(scimitar::get_camera_position(), bonePosition);
            }


            if (isVisible) {

                float distanceToCrosshair = std::sqrt(std::pow(screen_bone.x - screenCenter.x, 2) + std::pow(screen_bone.y - screenCenter.y, 2));

                if (distanceToCrosshair < closestDistanceToCrosshair) {
                    closestDistanceToCrosshair = distanceToCrosshair;
                    closest_bone = bonePosition;
                    found_target = true;
                }
            }
        }
    }

    if (found_target) {

        static std::chrono::system_clock::time_point last_bullet = std::chrono::system_clock::now();
        std::chrono::system_clock::time_point now = std::chrono::system_clock::now();

        std::chrono::milliseconds delay(Globals->Ragebot.delay);

        ubiVector3 angles = calculate_angles(closest_bone, scimitar::get_camera_position());


        const auto clamp = [](ubiVector3 euler_angles) {
            if (euler_angles.x > 75.f) euler_angles.x = 75.f;
            else if (euler_angles.x < -75.f) euler_angles.x = -75.f;
            if (euler_angles.z < -180.f) euler_angles.z += 360.f;
            else if (euler_angles.z > 180.f) euler_angles.z -= 360.f;
            euler_angles.y = 0.f;
            return euler_angles;
            };
        angles = clamp(angles);


        ubiVector4 quat = angles_to_quat(angles);


        auto pawnAimManager = local_controller->get_pawn()->get_cpawn_aim_manager();
      
        auto weapon_comp = local_controller->get_pawn()->get_entity()->get_weapon_component();
        auto nigger = local_controller->get_pawn()->get_entity()->get_weapon_component();

        

            if (now - last_bullet >= delay) {
              
                  
                    if (weapon_comp->ammo() > 0) {

                        if (Globals->Ragebot.bSingleFireFix) {

                            local_controller->get_pawn()->get_entity()->send_server_shoot(1);
                        }

                        BlindEye::StopRunning(false);
                           
                          if (!Globals->Ragebot.bSilent) {
                                 pawnAimManager->set_view_angle(quat);
                                }
                            
                     

                         nigger->decrease_ammo();

                        weapon_comp->Shoot(camera_pos, closest_bone);

                      
                        Render::add_tracer(camera_pos, closest_bone, 10.0f, Globals->Ragebot.bTracer); 

                    }

                 last_bullet = now;
            } 
        }

  }




