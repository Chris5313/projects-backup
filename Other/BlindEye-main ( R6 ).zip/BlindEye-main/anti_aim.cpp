#include "hooks.hpp"

#include "SpoofCall/spoof_call.hpp"

#include "config.hpp"

#include "Scimitar.hpp"

#include "BlindEye.hpp"

# define M_PI           3.14159265358979323846f

bool hooks::anti_aim(__int64 rcx, __int64 rdx)
{
	//printf("[%s]:Hooked\n", "hooks::hk_anti_aim");

	if (!Globals->AntiAim.bAntiAim)
		return FUNCTION(calls::anti_aim, rcx, rdx);

	auto Pawn = scimitar::game_manager::get_instance()->get_local_controller()->get_pawn();
	if (!utils::memory::valid_pointer(Pawn))
		return FUNCTION(calls::anti_aim, rcx, rdx);

	bool do_Slide = (*reinterpret_cast<bool*>(Pawn + 0xDA) && Globals->AntiAim.bSlide);

	if (do_Slide)
	{
		*reinterpret_cast<bool*>(Pawn + 0xDA) = false;

		auto PawnDRInfo = *reinterpret_cast<std::uint64_t*>(Pawn + 0x1318); 
		*reinterpret_cast<ubiVector4*>(PawnDRInfo + 0x20) = ubiVector4(-0.01f, -0.01f, -0.01f, -0.01f);
	}  

	ubiVector4 rotation{ };

	ubiVector4 rot{ };

	if (Globals->AntiAim.iAAType)
	{
		rotation = Pawn->get_entity()->rotation();
		auto newRotation = rotation;


		switch (Globals->AntiAim.iAAType)
		{
		default:
			newRotation = rotation;
			break;

		case 1: //Backward
		{

			ubiVector4 flipRotation = { 0.0f, 0.0f, 1.0f, 0.0f };
			newRotation = newRotation * flipRotation;
			break;
		}
		case 2: //Spin
		{

			static float Testangle = 0;
			Testangle += Globals->AntiAim.fSpinSpeed * 0.032f;
			newRotation.z = std::cos(Testangle);
			newRotation.w = std::sin(Testangle);
			break;
		}
		}

		Pawn->get_entity()->rotation(&newRotation);
	}

	auto ret = FUNCTION(calls::anti_aim, rcx, rdx);

	if (do_Slide)
		*reinterpret_cast<bool*>(Pawn + 0xDA) = true;

	if (Globals->AntiAim.iAAType)
		Pawn->get_entity()->rotation(&rotation);

	return ret;
}

__int64 hooks::anti_aim_manager(__int64 rcx)
{

	auto ret = FUNCTION(calls::anti_aim_manager, rcx);
	if (!Globals->AntiAim.bAntiAim)
		return ret;


	if (*reinterpret_cast<std::uint64_t*>(rcx + 0x1A0) != (std::uint64_t)hooks::anti_aim)
	{


		if (!calls::anti_aim) {

			calls::anti_aim = reinterpret_cast<decltype(calls::anti_aim)>(*reinterpret_cast<std::uint64_t*>(rcx + 0x1A0));
		}


		*reinterpret_cast<std::uint64_t*>(rcx + 0x1A0) = (std::uint64_t)hooks::anti_aim;
	}


	return ret;

}