#include "BlindEye.hpp"

auto BlindEye::long_melee(bool enable) -> void {

	auto local_controller = scimitar::game_manager::get_instance()->get_local_controller();
	if (!utils::memory::valid_pointer(local_controller)) return;

	auto local_pawn = local_controller->get_pawn();
	if (!utils::memory::valid_pointer(local_pawn)) return;

	auto local_entity = local_pawn->get_entity();
	if (!utils::memory::valid_pointer(local_entity)) return;

	auto EDrvMelee = local_entity->get_movement(scimitar::EMovementComponent::EDrvMelee);
	if (!utils::memory::valid_pointer(EDrvMelee)) return;

	if (enable)
	{

		utils::memory::Write<float>(EDrvMelee + 0x68, 1000);
		utils::memory::Write<float>(EDrvMelee + 0x6C, 1000);
	}
	else
	{
		utils::memory::Write<float>(EDrvMelee + 0x68, 1.2);
		utils::memory::Write<float>(EDrvMelee + 0x6C, 1.2);
	}
}