#include "BlindEye.hpp"

auto BlindEye::fov_changer(float fov) -> void {

	utils::memory::Write<float>(scimitar::get_camera_fx() + 0x1C, fov);
}

auto BlindEye::third_person(bool enable) -> void {


	auto player_camera_manager = scimitar::game_manager::get_instance()->get_local_controller()->get_player_camera_manager();
	auto camera_fx = scimitar::get_camera_fx();


	static bool enabled;


	if (enable && (GetAsyncKeyState(Globals->Hotkey.thirdpersonkey) & 1)) {
		enabled = !enabled;
	}


	if (enabled) {


		Globals->Log.bThirdPersonlog = true;

		if (Globals->Player.iSelected3p == 0) {
			utils::memory::Write<uint32_t>(player_camera_manager + 0x2ba, 168);
		}
		if (Globals->Player.iSelected3p == 1) {
			utils::memory::Write<uint32_t>(player_camera_manager + 0x2ba, 166);
		}


		utils::memory::Write<float>(camera_fx + 0x34, -1.2);
	}
	else {


		Globals->Log.bThirdPersonlog = false;

		if (Globals->Player.iSelected3p == 0) {
			utils::memory::Write<uint32_t>(player_camera_manager + 0x2ba, 166);
		}

		if (Globals->Player.iSelected3p == 1) {
			utils::memory::Write<uint32_t>(player_camera_manager + 0x2ba, 168);
		}

		utils::memory::Write<float>(camera_fx + 0x34, 0);
	}
}


