#include "hooks.hpp"

#include <intrin.h>

#include "Utils.hpp"

#include "SpoofCall/spoof_call.hpp"

#include "config.hpp"

#pragma intrinsic(_ReturnAddress)

void hooks::compute_value(void* AnimTrackLinearFloat, float a2, float* a3, unsigned int* a4)
{
	//printf("[%s]: Hooked\n", "hooks::compute_value");

	//search CD CC 4C 3E 00 00 F0 00 FC 00 58 02 64 02 08 
	//for hook then check what acceses first result

	//search 0x3528a9b9 for spread_caller_address

	static uintptr_t recoil_caller_address = ImageBase + 0x6E52564; //0x1e8af1c
	static uintptr_t spread_caller_address = ImageBase + 0x6e6e7ad; //0x1ea6c77

	auto ret_address = uintptr_t(_ReturnAddress());

	FUNCTION(calls::compute_value, AnimTrackLinearFloat, a2, a3, a4);

	if (ret_address == spread_caller_address)
	{
		*a3 *= static_cast<float>(Globals->Weapon.fSpread) / 100.f;
		return;
	}

	if (ret_address == recoil_caller_address)
	{
		*a3 *= static_cast<float>(Globals->Weapon.fRecoil) / 100.f;
		return;
	}
}