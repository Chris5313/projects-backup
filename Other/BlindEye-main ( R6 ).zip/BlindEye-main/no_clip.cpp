#include "BlindEye.hpp"

auto BlindEye::no_clip(bool enable) -> void {


	if (!enable) return;
	
	static bool enabled;

	if (GetAsyncKeyState(Globals->Hotkey.testkey) & 1) enabled = !enabled;

	if (enabled) {

		Globals->Log.bNoCliplog = true;

		utils::memory::Write<float>(scimitar::get_no_clip(), -1);
	}
	else {

		Globals->Log.bNoCliplog = false;

		utils::memory::Write<float>(scimitar::get_no_clip(), 0.0003051850945);
	}

}