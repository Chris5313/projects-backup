#include "scimitar.hpp"
#include "BlindEye.hpp"

inline bool IsRunning;

static std::chrono::steady_clock::time_point last_ran;

void send_sprint_to_server(uint8_t state)
{

	auto edrvsprinting = scimitar::game_manager::get_instance()->get_local_controller()->get_pawn()->get_entity()->get_movement(scimitar::EMovementComponent::EDrvSprinting);

	if (!utils::memory::valid_pointer(edrvsprinting))
		return;

	auto v4 = *reinterpret_cast<scimitar::Server**>(edrvsprinting + 0x68);
	if (!utils::memory::valid_pointer(v4))
		return;

 	auto buffer = scimitar::Server::sprint_state_server(state);

	v4->send_to_server(&buffer, 0x301A0DFF);

}


bool isRunning()
{
	auto edrvsprinting = scimitar::game_manager::get_instance()->get_local_controller()->get_pawn()->get_entity()->get_movement(scimitar::EMovementComponent::EDrvSprinting);
	if (!utils::memory::valid_pointer(edrvsprinting))
		return false;

	return (((utils::memory::Read<uint8_t>(edrvsprinting + 0x93) >> 7) ^ 0xB7) & 1) == 0;
}


void(*set_sprint_state)(uint64_t edrvSprinting, bool bRun) = reinterpret_cast<decltype(set_sprint_state)>(ImageBase + 0x521F5A0);

void StartRunning()
{
	auto edrvsprinting = scimitar::game_manager::get_instance()->get_local_controller()->get_pawn()->get_entity()->get_movement(scimitar::EMovementComponent::EDrvSprinting);
	if (!utils::memory::valid_pointer(edrvsprinting))
		return;

	send_sprint_to_server(1);

	spoof_call(set_sprint_state, edrvsprinting, true);
}

void BlindEye::StopRunning(bool state)
{

	auto edrvsprinting = scimitar::game_manager::get_instance()->get_local_controller()->get_pawn()->get_entity()->get_movement(scimitar::EMovementComponent::EDrvSprinting);
	if (!utils::memory::valid_pointer(edrvsprinting))
		return;

	send_sprint_to_server(0);

	if (state && IsRunning)

		spoof_call(set_sprint_state, edrvsprinting, true);
	else if (!state)
		spoof_call(set_sprint_state, edrvsprinting, false);
}

auto BlindEye::run_and_shoot(bool enabled) -> void
{

	

	auto edrvsprinting = scimitar::game_manager::get_instance()->get_local_controller()->get_pawn()->get_entity()->get_movement(scimitar::EMovementComponent::EDrvSprinting);
	if (!utils::memory::valid_pointer(edrvsprinting))
		return;

	auto edrvweapon = scimitar::game_manager::get_instance()->get_local_controller()->get_pawn()->get_entity()->get_movement(scimitar::EMovementComponent::EDrvWeapon);
	if (!utils::memory::valid_pointer(edrvweapon))
		return;


	static std::uint64_t orgi;
	static bool running = false;

	auto v12 = utils::memory::Read<uint64_t>(edrvsprinting + 0x48);
	if (v12 != 0) {
		orgi = v12;
	}



	if (enabled)
	{

		*reinterpret_cast<std::uint64_t*>(edrvweapon + 0x160) = 0;

		utils::memory::Write<uint64_t>(edrvsprinting + 0x48, 0);
		running = true;

		

			auto this_run = std::chrono::high_resolution_clock::now();
			std::chrono::duration<float> elapsed = this_run - last_ran;
			if (elapsed.count() >= (0.1f))
			{

				StartRunning();
				last_ran = std::chrono::high_resolution_clock::now();
			}
			IsRunning = true;
		
		
	}
	else
	{
		if (running)
		{
			if (orgi)
			{
				utils::memory::Write<uint64_t>(edrvsprinting + 0x48, orgi);

				BlindEye::StopRunning(true);

				running = false;
			}
		}
	}
}
