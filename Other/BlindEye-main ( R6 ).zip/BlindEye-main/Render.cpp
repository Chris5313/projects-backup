#include "Render.hpp"

ImVec4 Render::getRainbowColor(float hue) {
    float r = std::sin(hue * 2.0f * M_PI) * 0.5f + 0.5f;
    float g = std::sin(hue * 2.0f * M_PI + (2.0f / 3.0f) * M_PI) * 0.5f + 0.5f;
    float b = std::sin(hue * 2.0f * M_PI + (4.0f / 3.0f) * M_PI) * 0.5f + 0.5f;
    return ImVec4(r, g, b, 1.0f);
}



ImU32 Render::GetRainbowColor() {
    ImVec4 rainbowColor = Render::getRainbowColor(hue1);
    hue1 += hueStep;
    if (hue1 > 1.0f)
        hue1 -= 1.0f;

    return ImColor(rainbowColor);
}

ImU32 RGBtoU32(int r, int g, int b)
{
    float fr = (float)r / 255.0;
    float fg = (float)g / 255.0;
    float fb = (float)b / 255.0;
    return ImGui::GetColorU32(ImVec4(fr, fg, fb, 1));
}

auto Render::add_tracer(ubiVector4 start_pos, ubiVector4 end_pos, float thickness, bool enable) -> void {

    ImU32 color = ImColor(255, 255, 255, 255);

    if (!enable) return;

    if (Globals->Ragebot.bRainbowTracer) {
        color = Render::GetRainbowColor();
    }
    else {
        color = ImColor(Globals->Ragebot.TracerRGB);
    }

    auto lifetime = std::chrono::steady_clock::now();


    Tracer start_tracer = {
        start_pos,
        color,
        thickness,
        lifetime,
        end_pos
    };


    active_tracers.push_back(start_tracer);


    Tracer end_tracer = {
        start_pos,
        color,
        thickness,
        lifetime,
        end_pos
    };


    active_tracers.push_back(end_tracer);
}

auto Render::render_tracers() -> void {
    auto now = std::chrono::steady_clock::now();

    if (active_tracers.size() > 20) {
        active_tracers.erase(active_tracers.begin());
    }

    for (int i = 0; i < active_tracers.size(); i++) {
        auto timeAlive = std::chrono::duration_cast<std::chrono::seconds>(now - active_tracers[i].start_time);
        if (timeAlive.count() > 2) {
            active_tracers.erase(active_tracers.begin() + i);
            i--;
            continue;
        }

        ubiVector2 screen_pos_start, screen_pos_end;

        bool bstart = scimitar::world_to_screen(active_tracers[i].world_start, screen_pos_start);
        bool bend = scimitar::world_to_screen(active_tracers[i].world_end, screen_pos_end);

        if (bstart || bend) {
            ubiVector4 direction = active_tracers[i].world_end - active_tracers[i].world_start;
            float distance = direction.Length();
            direction.Normalize();

            float dot_spacing = 0.5f;
            int num = static_cast<int>(distance / dot_spacing);

            for (int j = 0; j <= num; j++) {
                ubiVector4 pos = active_tracers[i].world_start + direction * (dot_spacing * j);

                ubiVector2 screen_pos;
                if (scimitar::world_to_screen(pos, screen_pos)) {
                    ImVec2 dotPos(screen_pos.x, screen_pos.y);

                    float r = (active_tracers[i].color >> IM_COL32_R_SHIFT & 0xFF) / 255.0f;
                    float g = (active_tracers[i].color >> IM_COL32_G_SHIFT & 0xFF) / 255.0f;
                    float b = (active_tracers[i].color >> IM_COL32_B_SHIFT & 0xFF) / 255.0f;

                    ImU32 baseColor = RGBtoU32(r * 255, g * 255, b * 255);

                    ImDrawList* drawList = ImGui::GetBackgroundDrawList();

                    
                    drawList->AddCircleFilled(dotPos, 8.0f, (baseColor & 0x00FFFFFF) | 0x12000000);
                    drawList->AddCircleFilled(dotPos, 6.5f, (baseColor & 0x00FFFFFF) | 0x20000000);
                    drawList->AddCircleFilled(dotPos, 5.0f, (baseColor & 0x00FFFFFF) | 0x30000000);
                    drawList->AddCircleFilled(dotPos, 4.0f, (baseColor & 0x00FFFFFF) | 0x45000000);
                    drawList->AddCircleFilled(dotPos, 3.2f, (baseColor & 0x00FFFFFF) | 0x60000000);
                    drawList->AddCircleFilled(dotPos, 2.5f, (baseColor & 0x00FFFFFF) | 0x80000000);
                    drawList->AddCircleFilled(dotPos, 2.0f, (baseColor & 0x00FFFFFF) | 0xA0000000);

                   
                    ImU32 skelBright = RGBtoU32(
                        min(255, static_cast<int>(r * 255 * 3.0f)),
                        min(255, static_cast<int>(g * 255 * 3.0f)),
                        min(255, static_cast<int>(b * 255 * 3.0f))
                    );

                    ImU32 skelHyperBright = RGBtoU32(
                        min(255, static_cast<int>(r * 255 * 4.5f)),
                        min(255, static_cast<int>(g * 255 * 4.5f)),
                        min(255, static_cast<int>(b * 255 * 4.5f))
                    );

                    drawList->AddCircleFilled(dotPos, 1.5f, skelBright);
                    drawList->AddCircleFilled(dotPos, 1.0f, skelHyperBright);
                    drawList->AddCircleFilled(dotPos, 0.7f, IM_COL32_WHITE);
                }
            }
        }
    }
}


void Render::outlined_text(ImDrawList* bg, const ImVec2& pos, ImU32 black, ImU32 color, const char* text)
{
    bg->AddText({ pos.x - 1, pos.y }, black, text);
    bg->AddText({ pos.x + 1, pos.y }, black, text);
    bg->AddText({ pos.x, pos.y - 1 }, black, text);
    bg->AddText({ pos.x, pos.y + 1 }, black, text);

    bg->AddText(pos, color, text);
}




inline void DrawImage(ImTextureID ptexture, float_t x, float_t y, float_t w, float_t h, ImColor color)
{
    ImGui::GetBackgroundDrawList()->AddImage(ptexture, ImVec2(x, y), ImVec2(x + w, y + h), ImVec2(0, 0), ImVec2(1, 1), color);
}

void Render::DrawPlayerTags(const ubiVector2& Position, float Health, float MaxHealth, float Distance, const char* UserName, const char* Operator, ImColor color, ImColor distanceColor)
{
    float healthPercentage = Health / MaxHealth;
    if (healthPercentage >= 1) healthPercentage = 1.f;

    std::string Full = std::to_string((int)std::round(Distance)) + ("m ") + UserName;
    std::string DistanceStr = std::to_string((int)std::round(Distance)) + "m ";

    const ImVec2 text_dimension = ImGui::CalcTextSize(Full.c_str());
    const float text_width = text_dimension.x + 5.f;
    const float offsetX = -10.0f;
    const float mid_width = Position.x - (text_width / 2.f) + offsetX;

    ImVec2 distance_dimension = ImGui::CalcTextSize(DistanceStr.c_str());
    ImVec2 username_dimension = ImGui::CalcTextSize(UserName);

    ImVec2 tagTopLeft = ImVec2(mid_width + 2.f, Position.y - 25.f);
    ImVec2 tagBottomRight = ImVec2(mid_width + distance_dimension.x + username_dimension.x + 25.f, Position.y - 25.f + text_dimension.y + 1.f);

    ImDrawList* drawList = ImGui::GetBackgroundDrawList();

    // Background rectangles (unchanged)
    drawList->AddRectFilled(tagTopLeft, ImVec2(mid_width + distance_dimension.x + 5.f + 2.f, tagBottomRight.y), distanceColor);
    drawList->AddRectFilled(ImVec2(mid_width + distance_dimension.x + 5.f + 2.f, tagTopLeft.y), tagBottomRight, color);

   
    float extraSpacing = 14.0f;
    ImVec2 distancePos = ImVec2(mid_width + 6.f, (Position.y - 26.5f) + 2.f);
    ImVec2 usernamePos = ImVec2(mid_width + distance_dimension.x + extraSpacing, (Position.y - 26.5f) + 2.f);

    outlined_text(drawList, distancePos, IM_COL32_BLACK, IM_COL32_WHITE, DistanceStr.c_str());
    outlined_text(drawList, usernamePos, IM_COL32_BLACK, IM_COL32_WHITE, UserName);


    ImVec2 healthBarPos = ImVec2(mid_width + 2.f, Position.y - 27.f + text_dimension.y + 3.f);
    ImVec2 healthBarSize = ImVec2(text_width + 18.7f, 2);

    ImU32 healthColor = IM_COL32(
        (1.f - healthPercentage) * 255,
        255 * healthPercentage * 0.9f,
        0, 255);

    for (float i = 1.3f; i > 0.0f; i -= 0.5f) {
        float alpha = (i /  1.3f) * 80.0f; 
        ImU32 glowCol = (healthColor & 0x00FFFFFF) | (static_cast<int>(alpha) << 24);

        drawList->AddRectFilled(
            ImVec2(healthBarPos.x - i, healthBarPos.y - i),
            ImVec2(healthBarPos.x + healthBarSize.x * healthPercentage + i, healthBarPos.y + healthBarSize.y + i),
            glowCol);
    }

   
    drawList->AddRectFilled(
        healthBarPos,
        { healthBarPos.x + healthBarSize.x, healthBarPos.y + healthBarSize.y },
        ImColor(0, 0, 0, 255));

    drawList->AddRectFilled(
        healthBarPos,
        { healthBarPos.x + healthBarSize.x * healthPercentage, healthBarPos.y + healthBarSize.y },
        healthColor);

  
    if (auto icon = Render::GetIconByName(Operator); icon)
        DrawImage(icon, mid_width - 23.f, Position.y - 28.3f, 24.f, 24.f, ImColor(255, 255, 255, 255));
}


void Render::LoadImages()
{
    operatorImages.emplace_back("Smoke", OperatorIcons::smoke_image);
    operatorImages.emplace_back("Ace", OperatorIcons::ace_image);
    operatorImages.emplace_back("Alibi", OperatorIcons::alibi_image);
    operatorImages.emplace_back("Amaru", OperatorIcons::amaru_image);
    operatorImages.emplace_back("Aruni", OperatorIcons::aruni_image);
    operatorImages.emplace_back("Ash", OperatorIcons::ash_image);
    operatorImages.emplace_back("Azami", OperatorIcons::azami_image);
    operatorImages.emplace_back("Bandit", OperatorIcons::bandit_image);
    operatorImages.emplace_back("Blackbeard", OperatorIcons::blackbeard_image);
    operatorImages.emplace_back("Blitz", OperatorIcons::blitz_image);
    operatorImages.emplace_back("Brava", OperatorIcons::brava_image);
    operatorImages.emplace_back("Buck", OperatorIcons::buck_image);
    operatorImages.emplace_back("Capitao", OperatorIcons::capitao_image);
    operatorImages.emplace_back("Castle", OperatorIcons::castle_image);
    operatorImages.emplace_back("Caveira", OperatorIcons::caveira_image);
    operatorImages.emplace_back("Clash", OperatorIcons::clash_image);
    operatorImages.emplace_back("Deimos", OperatorIcons::deimos_image);
    operatorImages.emplace_back("Doc", OperatorIcons::doc_image);
    operatorImages.emplace_back("Dokkaebi", OperatorIcons::dokkaebi_image);
    operatorImages.emplace_back("Echo", OperatorIcons::echo_image);
    operatorImages.emplace_back("Ela", OperatorIcons::ela_image);
    operatorImages.emplace_back("Fenrir", OperatorIcons::fenrir_image);
    operatorImages.emplace_back("Finka", OperatorIcons::finka_image);
    operatorImages.emplace_back("Flores", OperatorIcons::flores_image);
    operatorImages.emplace_back("Frost", OperatorIcons::frost_image);
    operatorImages.emplace_back("Fuze", OperatorIcons::fuze_image);
    operatorImages.emplace_back("Glaz", OperatorIcons::glaz_image);
    operatorImages.emplace_back("Goyo", OperatorIcons::goyo_image);
    operatorImages.emplace_back("Gridlock", OperatorIcons::gridlock_image);
    operatorImages.emplace_back("Grim", OperatorIcons::grim_image);
    operatorImages.emplace_back("Hibana", OperatorIcons::hibana_image);
    operatorImages.emplace_back("Iana", OperatorIcons::iana_image);
    operatorImages.emplace_back("Iq", OperatorIcons::iq_image);
    operatorImages.emplace_back("Jackal", OperatorIcons::jackal_image);
    operatorImages.emplace_back("Jager", OperatorIcons::jager_image);
    operatorImages.emplace_back("Kaid", OperatorIcons::kaid_image);
    operatorImages.emplace_back("Kali", OperatorIcons::kali_image);
    operatorImages.emplace_back("Kapkan", OperatorIcons::kapkan_image);
    operatorImages.emplace_back("Lesion", OperatorIcons::lesion_image);
    operatorImages.emplace_back("Lion", OperatorIcons::lion_image);
    operatorImages.emplace_back("Maestro", OperatorIcons::maestro_image);
    operatorImages.emplace_back("Maverick", OperatorIcons::maverick_image);
    operatorImages.emplace_back("Melusi", OperatorIcons::melusi_image);
    operatorImages.emplace_back("Mira", OperatorIcons::mira_image);
    operatorImages.emplace_back("Montagne", OperatorIcons::montagne_image);
    operatorImages.emplace_back("Mozzie", OperatorIcons::mozzie_image);
    operatorImages.emplace_back("Mute", OperatorIcons::mute_image);
    operatorImages.emplace_back("Nokk", OperatorIcons::nokk_image);
    operatorImages.emplace_back("Nomad", OperatorIcons::nomad_image);
    operatorImages.emplace_back("Oryx", OperatorIcons::oryx_image);
    operatorImages.emplace_back("Osa", OperatorIcons::osa_image);
    operatorImages.emplace_back("Pulse", OperatorIcons::pulse_image);
    operatorImages.emplace_back("Ram", OperatorIcons::ram_image);
    operatorImages.emplace_back("Recruit", OperatorIcons::recruit_image);
    operatorImages.emplace_back("Rook", OperatorIcons::rook_image);
    operatorImages.emplace_back("Sens", OperatorIcons::sens_image);
    operatorImages.emplace_back("Sentry", OperatorIcons::sentry_image);
    operatorImages.emplace_back("Sledge", OperatorIcons::sledge_image);
    operatorImages.emplace_back("Solis", OperatorIcons::solis_image);
    operatorImages.emplace_back("Striker", OperatorIcons::striker_image);
    operatorImages.emplace_back("Tachanka", OperatorIcons::tachanka_image);
    operatorImages.emplace_back("Thatcher", OperatorIcons::thatcher_image);
    operatorImages.emplace_back("Thermite", OperatorIcons::thermite_image);
    operatorImages.emplace_back("Thorn", OperatorIcons::thorn_image);
    operatorImages.emplace_back("Thunderbird", OperatorIcons::thunderbird_image);
    operatorImages.emplace_back("Tubarao", OperatorIcons::tubarao_image);
    operatorImages.emplace_back("Twitch", OperatorIcons::twitch_image);
    operatorImages.emplace_back("Valkyrie", OperatorIcons::valkyrie_image);
    operatorImages.emplace_back("Vigil", OperatorIcons::vigil_image);
    operatorImages.emplace_back("Wamai", OperatorIcons::wamai_image);
    operatorImages.emplace_back("Warden", OperatorIcons::warden_image);
    operatorImages.emplace_back("Ying", OperatorIcons::ying_image);
    operatorImages.emplace_back("Zero", OperatorIcons::zero_image);
    operatorImages.emplace_back("Zofia", OperatorIcons::zofia_image);
    operatorImages.emplace_back("Skopos", OperatorIcons::skopos_image);
}

ID3D11ShaderResourceView* Render::GetIconByName(const char* Operator)
{
    for (auto& icon : operatorImages)
        if (strcmp(icon.first.c_str(), Operator) == 0)
            return icon.second;

    return nullptr;
}

void Render::LoadGadgetImages()
{

    GadgetImages.emplace_back("Black Mirror", GadgetIcons::Black_Mirror_image);
    GadgetImages.emplace_back("Castle", GadgetIcons::Castle_image);
    GadgetImages.emplace_back("Sense", GadgetIcons::Sense_image);
    GadgetImages.emplace_back("Ying", GadgetIcons::Ying_image);


    GadgetImages.emplace_back("Frag Grenade", GadgetIcons::Frag_Grenade_image);

    GadgetImages.emplace_back("Impact", GadgetIcons::Impact_image);


    GadgetImages.emplace_back("Mozzie Pest", GadgetIcons::Mozzie_Pest_image);

    GadgetImages.emplace_back("Defuser", GadgetIcons::Defuser_image);

    GadgetImages.emplace_back("LV Explosive Lance", GadgetIcons::LV_Explosive_Lance_image);

    GadgetImages.emplace_back("EYENOX-MODELL III", GadgetIcons::EYENOX_MODELL_III_image);

    GadgetImages.emplace_back("ERC-7", GadgetIcons::ERC_7_image);
    GadgetImages.emplace_back("CCE Shield", GadgetIcons::CCE_Shield_image);

    GadgetImages.emplace_back("Gemini Replicator", GadgetIcons::Gemini_Replicator_image);
    GadgetImages.emplace_back("Pantheon-Avatare V10", GadgetIcons::Pantheon_Avatare_V10_image);

    GadgetImages.emplace_back("Smart Glasses", GadgetIcons::Smart_Glasses_image);
    GadgetImages.emplace_back("Spec-IO Electro-Sensor", GadgetIcons::Spec_IO_Electro_Sensor_image);


    GadgetImages.emplace_back("ADS", GadgetIcons::ADS_image);
    GadgetImages.emplace_back("Adrenal Surge", GadgetIcons::Adrenal_Surge_image);
    GadgetImages.emplace_back("EE-ONE-D", GadgetIcons::EE_ONE_D_image);
    GadgetImages.emplace_back("Osa Shield", GadgetIcons::Osa_Shield_image);


    GadgetImages.emplace_back("Goyo", GadgetIcons::Goyo_image);
    GadgetImages.emplace_back("Assurya Laser Gate", GadgetIcons::Assurya_Laser_Gate_image);
    GadgetImages.emplace_back("Bulletproof Cam", GadgetIcons::Bulletproof_Cam_image);


    GadgetImages.emplace_back("Black Eye", GadgetIcons::Black_Eye_image);
    GadgetImages.emplace_back("Grim Bees", GadgetIcons::Grim_Bees_image);
    GadgetImages.emplace_back("Kona", GadgetIcons::Kona_image);
    GadgetImages.emplace_back("Banshee", GadgetIcons::Banshee_image);
    GadgetImages.emplace_back("Ela Mine", GadgetIcons::Ela_Mine_image);
    GadgetImages.emplace_back("Zoto Canister", GadgetIcons::Zoto_Canister_image);
    GadgetImages.emplace_back("Airjab", GadgetIcons::Airjab_image);
    GadgetImages.emplace_back("Argus Camera", GadgetIcons::Argus_Camera_image);
    GadgetImages.emplace_back("Barbed Wire", GadgetIcons::Barbed_Wire_image);
    GadgetImages.emplace_back("Blitz Shield", GadgetIcons::Blitz_Shield_image);
    GadgetImages.emplace_back("Breach Charge", GadgetIcons::Breach_Charge_image);
    GadgetImages.emplace_back("BU-GI", GadgetIcons::BU_GI_image);
    GadgetImages.emplace_back("Camera", GadgetIcons::Camera_image);
    GadgetImages.emplace_back("Claymore", GadgetIcons::Claymore_image);
    GadgetImages.emplace_back("Cluster Charge", GadgetIcons::Cluster_Charge_image);
    GadgetImages.emplace_back("Drone", GadgetIcons::Drone_image);
    GadgetImages.emplace_back("Electroclaw", GadgetIcons::Electroclaw_image);
    GadgetImages.emplace_back("Evil Eye", GadgetIcons::Evil_Eye_image);
    GadgetImages.emplace_back("F-NATT", GadgetIcons::F_NATT_image);
    GadgetImages.emplace_back("Flores Drone", GadgetIcons::Flores_Drone_image);
    GadgetImages.emplace_back("Frost Trap", GadgetIcons::Frost_Trap_image);
    GadgetImages.emplace_back("Gu", GadgetIcons::Gu_image);
    GadgetImages.emplace_back("Hard Breach Device", GadgetIcons::Hard_Breach_Device_image);
    GadgetImages.emplace_back("Heartbeat Sensor", GadgetIcons::Heartbeat_Sensor_image);
    GadgetImages.emplace_back("HEL", GadgetIcons::HEL_image);
    GadgetImages.emplace_back("IQ Scanner", GadgetIcons::IQ_Scanner_image);
    GadgetImages.emplace_back("Kapkan", GadgetIcons::Kapkan_image);
    GadgetImages.emplace_back("Kiba Barrier", GadgetIcons::Kiba_Barrier_image);
    GadgetImages.emplace_back("Kludge Drone", GadgetIcons::Kludge_Drone_image);
    GadgetImages.emplace_back("Logic Bomb", GadgetIcons::Logic_Bomb_image);
    GadgetImages.emplace_back("Mag-NET", GadgetIcons::Mag_NET_image);
    GadgetImages.emplace_back("Mute Jammer", GadgetIcons::Mute_Jammer_image);
    GadgetImages.emplace_back("Nitro Cell", GadgetIcons::Nitro_Cell_image);
    GadgetImages.emplace_back("Observation Blocker", GadgetIcons::Observation_Blocker_image);
    GadgetImages.emplace_back("Prisma", GadgetIcons::Prisma_image);
    GadgetImages.emplace_back("Proximity Alarm", GadgetIcons::Proximity_Alarm_image);
    GadgetImages.emplace_back("Razorbloom", GadgetIcons::Razorbloom_image);
    GadgetImages.emplace_back("Rook Armor", GadgetIcons::Rook_Armor_image);
    GadgetImages.emplace_back("SELMA", GadgetIcons::SELMA_image);
    GadgetImages.emplace_back("Shield", GadgetIcons::Shield_image);
    GadgetImages.emplace_back("Shock Drone", GadgetIcons::Shock_Drone_image);
    GadgetImages.emplace_back("Shock Wire", GadgetIcons::Shock_Wire_image);
    GadgetImages.emplace_back("Smoke Grenade", GadgetIcons::Smoke_Grenade_image);
    GadgetImages.emplace_back("Thermite Breach", GadgetIcons::Thermite_Breach_image);
    GadgetImages.emplace_back("Trax", GadgetIcons::Trax_image);
    GadgetImages.emplace_back("X-Kairos", GadgetIcons::X_Kairos_image);
    GadgetImages.emplace_back("Yokai Drone", GadgetIcons::Yokai_Drone_image);
}


ID3D11ShaderResourceView* Render::GetGadgetIconByName(const char* Gadget)
{
    for (auto& icon : GadgetImages)
        if (strcmp(icon.first.c_str(), Gadget) == 0)
            return icon.second;

    return nullptr;
}

void Render::DrawGadgetIcon(const char* Gadget, ubiVector4 position) {
    ubiVector2 screen;

    if (!scimitar::world_to_screen(position, screen) || screen.x == 0 || screen.y == 0)
        return;

    static const float iconSize = 18.0f;
    static const float offsetX = iconSize / 2.0f;
    static const float PlaceHolderSize = 26.0f;
    static const float PlaceHolderoffsetX = PlaceHolderSize / 2.0f;

    ImVec2 iconTopLeft(screen.x - offsetX, screen.y - offsetX);
    ImVec2 iconBottomRight(screen.x + offsetX, screen.y + offsetX);
    ImVec2 PlaceHolderLeft(screen.x - PlaceHolderoffsetX, screen.y - PlaceHolderoffsetX);
    ImVec2 PlaceHolderRight(screen.x + PlaceHolderoffsetX, screen.y + PlaceHolderoffsetX);

    static float hue = 0.0f;
    const float hueStep = 0.0001f;

    if (auto icon = Render::GetGadgetIconByName(Gadget); icon) {
        ImVec4 gadgetColor;

        if (Globals->Visuals.bRainbowESP) {
            gadgetColor = Render::getRainbowColor(hue);
            hue += hueStep;
            if (hue > 1.0f) hue -= 1.0f;
        }
        else {
            gadgetColor = ImVec4(Globals->Visuals.GadgetRGB.x, Globals->Visuals.GadgetRGB.y, Globals->Visuals.GadgetRGB.z, 1.0f);
        }

        if (Globals->Visuals.bShowIcon) {
            ImGui::GetBackgroundDrawList()->AddImage(GadgetIcons::Placeholder_image, PlaceHolderLeft, PlaceHolderRight, ImVec2(0, 0), ImVec2(1, 1), ImColor(gadgetColor));
            ImGui::GetBackgroundDrawList()->AddImage((void*)icon, iconTopLeft, iconBottomRight, ImVec2(0, 0), ImVec2(1, 1), ImColor(255, 255, 255, 255));

        }
        else {

            ImGui::GetBackgroundDrawList()->AddImage((void*)icon, iconTopLeft, iconBottomRight, ImVec2(0, 0), ImVec2(1, 1), ImColor(gadgetColor));
        }
    }
}



void Render::draw_skeleton(const ImVec2& p1, const ImVec2& p2, const ImVec4& color, float thickness) {


    ImU32 baseColor = RGBtoU32(
        color.x * 255,
        color.y * 255,
        color.z * 255
    );

    ImU32 skelGlowFarthest = (baseColor & 0x00FFFFFF) | 0x12000000;
    ImU32 skelGlowVeryFar = (baseColor & 0x00FFFFFF) | 0x20000000;
    ImU32 skelGlowFar = (baseColor & 0x00FFFFFF) | 0x30000000;
    ImU32 skelGlowOuter = (baseColor & 0x00FFFFFF) | 0x45000000;
    ImU32 skelGlowMid = (baseColor & 0x00FFFFFF) | 0x60000000;
    ImU32 skelGlowInner = (baseColor & 0x00FFFFFF) | 0x80000000;
    ImU32 skelGlowVeryInner = (baseColor & 0x00FFFFFF) | 0xA0000000;
   
    ImU32 skelBright = RGBtoU32(
       min(255, static_cast<int>(color.x * 255 * 3.0f)),
       min(255, static_cast<int>(color.y * 255 * 3.0f)),
      min(255, static_cast<int>(color.z * 255 * 3.0f))
    );

    ImU32 skelHyperBright = RGBtoU32(
        min(255, static_cast<int>(color.x * 255 * 4.5f)),
        min(255, static_cast<int>(color.y * 255 * 4.5f)),
        min(255, static_cast<int>(color.z * 255 * 4.5f))
    );

    ImDrawList* drawList = ImGui::GetBackgroundDrawList();

    drawList->AddLine(p1, p2, skelGlowFarthest, thickness * 12.0f);
    drawList->AddLine(p1, p2, skelGlowVeryFar, thickness * 9.0f);
    drawList->AddLine(p1, p2, skelGlowFar, thickness * 7.0f);
    drawList->AddLine(p1, p2, skelGlowOuter, thickness * 5.5f);
    drawList->AddLine(p1, p2, skelGlowMid, thickness * 4.2f);
    drawList->AddLine(p1, p2, skelGlowInner, thickness * 3.0f);
    drawList->AddLine(p1, p2, skelGlowVeryInner, thickness * 2.2f);
    drawList->AddLine(p1, p2, skelBright, thickness * 1.6f);
    drawList->AddLine(p1, p2, skelHyperBright, thickness * 1.1f);
    drawList->AddLine(p1, p2, IM_COL32_WHITE, thickness * 0.7f);
}