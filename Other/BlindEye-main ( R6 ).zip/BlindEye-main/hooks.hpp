#pragma once
#include "vector"

#include "Utils.hpp"

#include "havok_math.hpp"

#include "engine.hpp"

#include "ubiservices.hpp"

inline std::vector < std::pair<void*, void*>> orig_funcs;

inline void hook(void* destination, void* detour)
{
	if (!destination)
		return;

	orig_funcs.push_back({ destination, *reinterpret_cast<void**>(destination) });

	utils::memory::swap_table_ptr(destination, detour);
}

namespace calls
{
	inline __int64(*sendImpl)(void* HttpClientImpl, __int64 result, ubiservices::HttpRequest* request, __int64 requestRetryhandler, __int64 requestConfig);

	
	inline __int64(*binary_checksum_response)(__int64 a1, __int64 a2);

	//inline __int64(*gatekeeper_response)(__int64 a1, __int64 a2);

	inline __int64(*active_penalties)(__int64 a1, __int64 a2);

	inline void(*compute_value)(void*, float, float*, unsigned int*);

	inline bool (*anti_aim)(__int64 rcx, __int64 rdx);
	inline __int64 (*anti_aim_manager)(__int64 rcx);
}

namespace hooks
{
	__int64 binary_checksum_response(__int64 a1, __int64 a2);
	//__int64 gatekeeper_response(__int64 a1, __int64 a2);
	__int64 active_penalties(__int64 a1, __int64 a2);
	//__int64 begin_frame(eng::EngineLoop*);
	void compute_value(void*, float, float*, unsigned int*);

	bool anti_aim(__int64 rcx, __int64 rdx);
	__int64 anti_aim_manager(__int64 rcx);

	inline void init()
	{

		RVA_CALL(calls::binary_checksum_response, 0x4522040);
		
		RVA_CALL(calls::active_penalties, 0x45560F0);

		RVA_CALL(calls::anti_aim_manager, 0x6B8D060); //search //search aPawnStatepartr // 0xa607ef0h
		
		RVA_CALL(calls::compute_value, 0x903E730); //7AD6C00
		
		utils::memory::swap_table_ptr(utils::memory::scan_memory(reinterpret_cast<uint64_t>(calls::binary_checksum_response)), hooks::binary_checksum_response);


		hook(utils::memory::scan_memory(reinterpret_cast<uint64_t>(calls::anti_aim_manager)), hooks::anti_aim_manager);

		hook(utils::memory::scan_memory(reinterpret_cast<uint64_t>(calls::compute_value)), hooks::compute_value);

		hook(utils::memory::scan_memory(reinterpret_cast<uint64_t>(calls::active_penalties)), hooks::active_penalties);

	}




	inline void uninit()
	{
		for (auto& [ptr, func] : orig_funcs)
			utils::memory::swap_table_ptr(ptr, func);
	}
}

namespace UnlockAllHook
{


	__int64 sendImpl(void* HttpClientImpl, __int64 result, ubiservices::HttpRequest* request, __int64 requestRetryhandler, __int64 requestConfig);



	inline void init()
	{

		RVA_CALL(calls::sendImpl, 0x34CCE00);

		utils::memory::swap_table_ptr(utils::memory::scan_memory(reinterpret_cast<uint64_t>(calls::sendImpl)), UnlockAllHook::sendImpl);
		hook(utils::memory::scan_memory(reinterpret_cast<uint64_t>(calls::sendImpl)), UnlockAllHook::sendImpl);
	}

}