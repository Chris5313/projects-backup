#include "interface.hpp"
#include <windows.h>
#include <winhttp.h>
#pragma comment(lib, "winhttp.lib")
#include <thread>


static const char* KeyNames[] = {
    "OFF",
    "LBUTTON",
    "RBUTTON",
    "VK_CANCEL",
    "VK_MBUTTON",
    "MOUSE1",
    "MOUSE2",
    "Unknown",
    "VK_BACK",
    "VK_TAB",
    "Unknown",
    "Unknown",
    "VK_CLEAR",
    "VK_RETURN",
    "Unknown",
    "Unknown",
    "VK_SHIFT",
    "VK_CONTROL",
    "VK_MENU",
    "VK_PAUSE",
    "VK_CAPITAL",
    "VK_KANA",
    "Unknown",
    "VK_JUNJA",
    "VK_FINAL",
    "VK_KANJI",
    "Unknown",
    "Esc",
    "VK_CONVERT",
    "VK_NONCONVERT",
    "VK_ACCEPT",
    "VK_MODECHANGE",
    "VK_SPACE",
    "VK_PRIOR",
    "VK_NEXT",
    "VK_END",
    "VK_HOME",
    "VK_LEFT",
    "VK_UP",
    "VK_RIGHT",
    "VK_DOWN",
    "VK_SELECT",
    "VK_PRINT",
    "VK_EXECUTE",
    "VK_SNAPSHOT",
    "VK_INSERT",
    "VK_DELETE",
    "VK_HELP",
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
    "VK_LWIN",
    "VK_RWIN",
    "VK_APPS",
    "Unknown",
    "VK_SLEEP",
    "VK_NUMPAD0",
    "VK_NUMPAD1",
    "VK_NUMPAD2",
    "VK_NUMPAD3",
    "VK_NUMPAD4",
    "VK_NUMPAD5",
    "VK_NUMPAD6",
    "VK_NUMPAD7",
    "VK_NUMPAD8",
    "VK_NUMPAD9",
    "VK_MULTIPLY",
    "VK_ADD",
    "VK_SEPARATOR",
    "VK_SUBTRACT",
    "VK_DECIMAL",
    "VK_DIVIDE",
    "VK_F1",
    "VK_F2",
    "VK_F3",
    "VK_F4",
    "VK_F5",
    "VK_F6",
    "VK_F7",
    "VK_F8",
    "VK_F9",
    "VK_F10",
    "VK_F11",
    "VK_F12",
    "VK_F13",
    "VK_F14",
    "VK_F15",
    "VK_F16",
    "VK_F17",
    "VK_F18",
    "VK_F19",
    "VK_F20",
    "VK_F21",
    "VK_F22",
    "VK_F23",
    "VK_F24",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "VK_NUMLOCK",
    "VK_SCROLL",
    "VK_OEM_NEC_EQUAL",
    "VK_OEM_FJ_MASSHOU",
    "VK_OEM_FJ_TOUROKU",
    "VK_OEM_FJ_LOYA",
    "VK_OEM_FJ_ROYA",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
    "VK_LSHIFT",
    "VK_RSHIFT",
    "VK_LCONTROL",
    "VK_RCONTROL",
    "VK_LMENU",
    "VK_RMENU"
};
const int KeyCodes[] = {
    0x0,  //Undefined
    0x01,
    0x02,
    0x03,
    0x04,
    0x05,
    0x06,
    0x07, //Undefined
    0x08,
    0x09,
    0x0A, //Reserved
    0x0B, //Reserved
    0x0C,
    0x0D,
    0x0E, //Undefined
    0x0F, //Undefined
    0x10,
    0x11,
    0x12,
    0x13,
    0x14,
    0x15,
    0x16, //IME On
    0x17,
    0x18,
    0x19,
    0x1A, //IME Off
    0x1B,
    0x1C,
    0x1D,
    0x1E,
    0x1F,
    0x20,
    0x21,
    0x22,
    0x23,
    0x24,
    0x25,
    0x26,
    0x27,
    0x28,
    0x29,
    0x2A,
    0x2B,
    0x2C,
    0x2D,
    0x2E,
    0x2F,
    0x30,
    0x31,
    0x32,
    0x33,
    0x34,
    0x35,
    0x36,
    0x37,
    0x38,
    0x39,
    0x3A, //Undefined
    0x3B, //Undefined
    0x3C, //Undefined
    0x3D, //Undefined
    0x3E, //Undefined
    0x3F, //Undefined
    0x40, //Undefined
    0x41,
    0x42,
    0x43,
    0x44,
    0x45,
    0x46,
    0x47,
    0x48,
    0x49,
    0x4A,
    0x4B,
    0x4C,
    0x4B,
    0x4E,
    0x4F,
    0x50,
    0x51,
    0x52,
    0x53,
    0x54,
    0x55,
    0x56,
    0x57,
    0x58,
    0x59,
    0x5A,
    0x5B,
    0x5C,
    0x5D,
    0x5E, //Rservered
    0x5F,
    0x60, //Numpad1
    0x61, //Numpad2
    0x62, //Numpad3
    0x63, //Numpad4
    0x64, //Numpad5
    0x65, //Numpad6
    0x66, //Numpad7
    0x67, //Numpad8
    0x68, //Numpad8
    0x69, //Numpad9
    0x6A,
    0x6B,
    0x6C,
    0x6D,
    0x6E,
    0x6F,
    0x70, //F1
    0x71, //F2
    0x72, //F3
    0x73, //F4
    0x74, //F5
    0x75, //F6
    0x76, //F7
    0x77, //F8
    0x78, //F9
    0x79, //F10
    0x7A, //F11
    0x7B, //F12
    0x7C, //F13
    0x7D, //F14
    0x7E, //F15
    0x7F, //F16
    0x80, //F17
    0x81, //F18
    0x82, //F19
    0x83, //F20
    0x84, //F21
    0x85, //F22
    0x86, //F23
    0x87, //F24
    0x88, //Unkown
    0x89, //Unkown
    0x8A, //Unkown
    0x8B, //Unkown
    0x8C, //Unkown
    0x8D, //Unkown
    0x8E, //Unkown
    0x8F, //Unkown
    0x90,
    0x91,
    0x92, //OEM Specific
    0x93, //OEM Specific
    0x94, //OEM Specific
    0x95, //OEM Specific
    0x96, //OEM Specific
    0x97, //Unkown
    0x98, //Unkown
    0x99, //Unkown
    0x9A, //Unkown
    0x9B, //Unkown
    0x9C, //Unkown
    0x9D, //Unkown
    0x9E, //Unkown 
    0x9F, //Unkown
    0xA0,
    0xA1,
    0xA2,
    0xA3,
    0xA4,
    0xA5
};


auto SetupImGuiStyle() -> void

{
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;

    ImGuiStyle& style = ImGui::GetStyle();
    style.Colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.13f, 0.14f, 0.15f, 1.00f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.13f, 0.14f, 0.15f, 1.00f);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.13f, 0.14f, 0.15f, 1.00f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.43f, 0.43f, 0.50f, 0.50f);
    style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.38f, 0.38f, 0.38f, 1.00f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.67f, 0.67f, 0.67f, 0.39f);
    style.Colors[ImGuiCol_TitleBg] = ImVec4(0.08f, 0.08f, 0.09f, 1.00f);
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.08f, 0.08f, 0.09f, 1.00f);
    style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.00f, 0.00f, 0.00f, 0.51f);
    style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.02f, 0.02f, 0.02f, 0.53f);
    style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.41f, 0.41f, 0.41f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.51f, 0.51f, 0.51f, 1.00f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.11f, 0.64f, 0.92f, 1.00f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.11f, 0.64f, 0.92f, 1.00f);
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.08f, 0.50f, 0.72f, 1.00f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.38f, 0.38f, 0.38f, 1.00f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.67f, 0.67f, 0.67f, 0.39f);
    style.Colors[ImGuiCol_Header] = ImVec4(0.22f, 0.22f, 0.22f, 1.00f);
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.67f, 0.67f, 0.67f, 0.39f);
    style.Colors[ImGuiCol_Separator] = style.Colors[ImGuiCol_Border];
    style.Colors[ImGuiCol_SeparatorHovered] = ImVec4(0.41f, 0.42f, 0.44f, 1.00f);
    style.Colors[ImGuiCol_SeparatorActive] = ImVec4(0.26f, 0.59f, 0.98f, 0.95f);
    style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.29f, 0.30f, 0.31f, 0.67f);
    style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.26f, 0.59f, 0.98f, 0.95f);
    style.Colors[ImGuiCol_Tab] = ImVec4(0.08f, 0.08f, 0.09f, 0.83f);
    style.Colors[ImGuiCol_TabHovered] = ImVec4(0.33f, 0.34f, 0.36f, 0.83f);
    style.Colors[ImGuiCol_TabActive] = ImVec4(0.23f, 0.23f, 0.24f, 1.00f);
    style.Colors[ImGuiCol_TabUnfocused] = ImVec4(0.08f, 0.08f, 0.09f, 1.00f);
    style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.13f, 0.14f, 0.15f, 1.00f);
    style.Colors[ImGuiCol_PlotLines] = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
    style.Colors[ImGuiCol_PlotLinesHovered] = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
    style.Colors[ImGuiCol_PlotHistogram] = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
    style.Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
    style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
    style.Colors[ImGuiCol_DragDropTarget] = ImVec4(0.11f, 0.64f, 0.92f, 1.00f);
    style.Colors[ImGuiCol_NavHighlight] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    style.Colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
    style.Colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
    style.Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);
    style.GrabRounding = style.FrameRounding = 2.3f;
    style.Colors[ImGuiCol_WindowBg].w = 0.9f;  // Adjust the alpha value as needed (0.0f = fully transparent, 1.0f = opaque)
}

auto Render::user_interface() -> void {
    static bool initialized = false;

    SetupImGuiStyle();

    if (!initialized) {
        ImGui::SetNextWindowSize(ImVec2(560, 660), ImGuiCond_Once);
        ImGui::Begin("BlindEye.io", nullptr, ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse);
        initialized = true;
    }
    else {
        ImGui::Begin("BlindEye.io", nullptr, ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse);
    }

    if (ImGui::BeginTabBar("##Tabs")) {
        if (ImGui::BeginTabItem("Visuals")) {
            
            ImGui::Text("Visuals");
            ImGui::Checkbox("Enable", &Globals->Visuals.bEnable);
           
            
            if (Globals->Visuals.iVisibleType == 0) {

                ImGui::Checkbox("Skeleton", &Globals->Visuals.bSkeleton);
                ImGui::SameLine();
                ImGui::ColorEdit3("##Skeleton", &Globals->Visuals.SkeletonRGB.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);

            }

            if (Globals->Visuals.iVisibleType == 1) {

                ImGui::Checkbox("Skeleton", &Globals->Visuals.bSkeleton);
                ImGui::SameLine();
                ImGui::ColorEdit3("##Skeleton", &Globals->Visuals.SkeletonRGB.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);
                ImGui::SameLine();
                ImGui::ColorEdit3("##SkeletonVis", &Globals->Visuals.SkeletonVisRGB.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);
          
            }
            
            if (Globals->Visuals.iVisibleType == 2) {

                ImGui::Checkbox("Skeleton", &Globals->Visuals.bSkeleton);
                ImGui::SameLine();
                ImGui::ColorEdit3("##Skeleton", &Globals->Visuals.SkeletonRGB.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);
                ImGui::SameLine();
                ImGui::ColorEdit3("##SkeletonVis", &Globals->Visuals.SkeletonVisRGB.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);
                ImGui::SameLine();
                ImGui::ColorEdit3("##SkeletonPen", &Globals->Visuals.SkeletonPenRGB.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);
            }

           
            ImGui::SliderFloat("Skeleton Thickness", &Globals->Visuals.skeletonthickness, 0.1, 3.0);

            ImGui::Combo("Visible Check", &Globals->Visuals.iVisibleType, Globals->Visuals.cVisibleType, IM_ARRAYSIZE(Globals->Visuals.cVisibleType));

            ImGui::Checkbox("Player Information", &Globals->Visuals.bPlayerInformation);
            ImGui::SameLine();
            ImGui::ColorEdit4("##Information1", &Globals->Visuals.PlayerInformationRGB_1.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);
            ImGui::SameLine();
            ImGui::ColorEdit4("##Information2", &Globals->Visuals.PlayerInformationRGB_2.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);

          
            ImGui::Checkbox("Gadget ESP", &Globals->Visuals.bGadget);
            ImGui::SameLine();
            ImGui::ColorEdit4("##GadgetRGB", &Globals->Visuals.GadgetRGB.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);
            ImGui::SameLine();
            ImGui::Checkbox("Rainbow", &Globals->Visuals.bRainbowESP);
            ImGui::SameLine();
            ImGui::Checkbox("Show Icon", &Globals->Visuals.bShowIcon);

            
            ImGui::Checkbox("Team Check", &Globals->Visuals.bTeamCheck);
           
            ImGui::Checkbox("Health Log", &Globals->Visuals.bHealthLog);

            if (Globals->Visuals.bHealthLog) {

                ImGui::SetCursorPosX(15);

                ImGui::Checkbox("Chat Message", &Globals->Visuals.bInChat);

            }


            ImGui::EndTabItem();
        }

        if (ImGui::BeginTabItem("World")) {

            ImGui::Text("World");

            ImGui::Checkbox("No Light", &Globals->World.Light);
            ImGui::Checkbox("No Model", &Globals->World.Model);
            ImGui::Checkbox("No Sky", &Globals->World.Sky);
            ImGui::SameLine();
            ImGui::ColorEdit3("##SkyColor", Globals->World.sky_color, ImGuiColorEditFlags_PickerHueWheel | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel);

            ImGui::Checkbox("No HUD", &Globals->World.HUD);
            ImGui::Checkbox("No Smoke", &Globals->World.Smoke);
            ImGui::Checkbox("No Paint", &Globals->World.Paint);
            ImGui::Checkbox("No ColorMask", &Globals->World.ColorMask);
            ImGui::Checkbox("No Shadows", &Globals->World.Shadows);

            ImGui::EndTabItem();
        }

        if (ImGui::BeginTabItem("Weapon")) {
            ImGui::Text("Weapon");


            ImGui::SliderFloat("Recoil", &Globals->Weapon.fRecoil, 0.0, 100.0, "%.0fx", ImGuiSliderFlags_NoInput);
            ImGui::SliderFloat("Spread", &Globals->Weapon.fSpread, 0.0, 100.0, "%.0fx", ImGuiSliderFlags_NoInput);
            ImGui::Checkbox("Auto Reload", &Globals->Weapon.bAutoReload);

            ImGui::EndTabItem();
        }


        if (ImGui::BeginTabItem("Ragebot")) {
           
            ImGui::Text("Ragebot");


            ImGui::Checkbox("Enable Ragebot", &Globals->Ragebot.bEnable);

            ImGui::Checkbox("Silent", &Globals->Ragebot.bSilent);

            ImGui::SliderInt("Fire Rate", &Globals->Ragebot.delay, 0, 300, "%dms", ImGuiSliderFlags_NoInput);

            ImGui::Checkbox("Single Fire Fix", &Globals->Ragebot.bSingleFireFix);

            ImGui::Checkbox("Decrease Ammo", &Globals->Ragebot.bDecreaseAmmo);

            ImGui::Checkbox("Bullet Tracer", &Globals->Ragebot.bTracer);
            ImGui::SameLine();
          
            ImGui::ColorEdit3("##TracerRGB", &Globals->Ragebot.TracerRGB.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_InputRGB);
          
            ImGui::Checkbox("Rainbow Tracer", &Globals->Ragebot.bRainbowTracer);


            ImGui::EndTabItem();
        }
     

        if (ImGui::BeginTabItem("Player")) {
            ImGui::Text("Player");
           

            ImGui::SliderFloat("Camera FoV Modifier", &Globals->Player.fFoV, -1.0, 1.0, "%.3fx", ImGuiSliderFlags_NoInput);
            
            ImGui::Checkbox("Third Person", &Globals->Player.bThirdperson);
            ImGui::SameLine();
            ImGui::Combo("##ThirdpersonMode", &Globals->Player.iSelected3p, Globals->Player.cSelected3p, IM_ARRAYSIZE(Globals->Player.cSelected3p));
            ImGui::SameLine();
            if (Globals->Hotkey.THIRDPERSONKEY == false) {
                if (ImGui::Button(KeyNames[Globals->Hotkey.THIRDPERSONINT])) {
                    Globals->Hotkey.THIRDPERSONKEY = true;
                }
            }
            else if (Globals->Hotkey.THIRDPERSONKEY == true) {
                ImGui::Button("...");
                for (auto& Key : KeyCodes) {

                    if (Key == VK_LBUTTON || Key == VK_RBUTTON) {
                        continue;
                    }

                    if (Key == VK_ESCAPE && GetAsyncKeyState(VK_ESCAPE)) {
                        Globals->Hotkey.thirdpersonkey = 0x0; 
                        Globals->Hotkey.THIRDPERSONINT = 0x0;   
                        Globals->Hotkey.THIRDPERSONKEY = false;
                        break; 
                    }

                    if (GetAsyncKeyState(Key)) {
                        Globals->Hotkey.thirdpersonkey = Key;
                        Globals->Hotkey.THIRDPERSONINT = Key;
                        Globals->Hotkey.THIRDPERSONKEY = false;
                        break;  
                    }
                }
            }

            ImGui::Checkbox("Self Revive", &Globals->Player.bSelfRevive);
            ImGui::SameLine();
            if (Globals->Hotkey.SELFREVIVEKEY == false) {
                if (ImGui::Button(KeyNames[Globals->Hotkey.SELFREVIVEINT])) {
                    Globals->Hotkey.SELFREVIVEKEY = true;
                }
            }
            else if (Globals->Hotkey.SELFREVIVEKEY == true) {
                ImGui::Button("...");
                for (auto& Key : KeyCodes) {

                    if (Key == VK_LBUTTON || Key == VK_RBUTTON) {
                        continue;
                    }

                    if (Key == VK_ESCAPE && GetAsyncKeyState(VK_ESCAPE)) {
                        Globals->Hotkey.selfrevivekey = 0x0;
                        Globals->Hotkey.SELFREVIVEINT = 0x0;
                        Globals->Hotkey.SELFREVIVEKEY = false;
                        break;
                    }

                    if (GetAsyncKeyState(Key)) {
                        Globals->Hotkey.selfrevivekey = Key;
                        Globals->Hotkey.SELFREVIVEINT = Key;
                        Globals->Hotkey.SELFREVIVEKEY = false;
                        break;
                    }
                }
            }


            ImGui::Checkbox("Run & Shoot", &Globals->Player.bRunAndShoot);

            ImGui::Checkbox("Speed Multiplier", &Globals->Player.bSpeed);
            ImGui::SameLine();
            ImGui::SliderFloat("##SpeedModifier1", &Globals->Player.fSpeedval, 4.0f, 6.0f, "%.2f m/s", ImGuiSliderFlags_NoInput);

            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("Misc")) {
            ImGui::Text("Misc");
           
            ImGui::Checkbox("No Clip", &Globals->Misc.bNoClip);
            ImGui::SameLine();
            if (Globals->Hotkey.TESTKEY == false) {
                if (ImGui::Button(KeyNames[Globals->Hotkey.TESTINT])) {
                    Globals->Hotkey.TESTKEY = true;
                }
            }
            else if (Globals->Hotkey.TESTKEY == true) {
                ImGui::Button("...");
                for (auto& Key : KeyCodes) {

                    if (Key == VK_LBUTTON || Key == VK_RBUTTON) {
                        continue;
                    }

                    if (Key == VK_ESCAPE && GetAsyncKeyState(VK_ESCAPE)) {
                        Globals->Hotkey.testkey = 0x0;
                        Globals->Hotkey.TESTINT = 0x0;
                        Globals->Hotkey.TESTKEY = false;
                        break;
                    }

                    if (GetAsyncKeyState(Key)) {
                        Globals->Hotkey.testkey = Key;
                        Globals->Hotkey.TESTINT = Key;
                        Globals->Hotkey.TESTKEY = false;
                        break;
                    }
                }
            }
            ImGui::Checkbox("Long Melee", &Globals->Misc.bLongMelee);

            ImGui::Checkbox("Auto Melee", &Globals->Misc.bAutoMelee);

            ImGui::SetNextItemWidth(145);
            ImGui::InputText("Chat Spammer", Globals->Misc.chatMessage, 256);
            ImGui::Checkbox("Team Chat", &Globals->Misc.teamChat);
            ImGui::SameLine();
            ImGui::Checkbox("All Chat", &Globals->Misc.allChat);


            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("Anti Aim")) {
            ImGui::Text("Anti Aim");
            ImGui::Checkbox("Enable Anti Aim", &Globals->AntiAim.bAntiAim);

            ImGui::Combo("Anti Aim Mode", &Globals->AntiAim.iAAType, Globals->AntiAim.cAAType, IM_ARRAYSIZE(Globals->AntiAim.cAAType));
            
            if (Globals->AntiAim.iAAType == 2) {
                ImGui::SliderFloat("Spin Speed", &Globals->AntiAim.fSpinSpeed, 0.0f, 100.0f, "%.0f", ImGuiSliderFlags_NoInput);
            }
            
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("Settings")) {
            ImGui::Text("Settings");
            ImGui::Checkbox("Debug ", &Globals->UserInterface.bDebug);
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }

    ImGui::End();
}

bool showConsole = false;
char inputBuffer[256] = "";
std::vector<std::string> consoleMessages;


auto Render::AddMessage(const std::string& text) -> void {
    float currentTimestamp = currentTime;

    if (!messages.empty()) {
        currentTimestamp += 0.01f * messages.size();
    }

    ImVec2 newPosition = { 2.0f, 20.0f + static_cast<float>(messages.size()) * 20.0f };

    messages.push_back({ text, newPosition, currentTimestamp });

    consoleMessages.push_back("> " + text);

}



auto water_mark_outline(const ImVec2& pos, ImU32 outlineColor, ImU32 textColor, const char* text) -> void
{
    ImGui::GetBackgroundDrawList()->AddText({pos.x - 1, pos.y}, outlineColor, text);
    ImGui::GetBackgroundDrawList()->AddText({ pos.x + 1, pos.y }, outlineColor, text);
    ImGui::GetBackgroundDrawList()->AddText({ pos.x, pos.y - 1 }, outlineColor, text);
    ImGui::GetBackgroundDrawList()->AddText({ pos.x, pos.y + 1 }, outlineColor, text);
    ImGui::GetBackgroundDrawList()->AddText({ pos.x - 1, pos.y - 1 }, outlineColor, text);
    ImGui::GetBackgroundDrawList()->AddText({ pos.x + 1, pos.y - 1 }, outlineColor, text);
    ImGui::GetBackgroundDrawList()->AddText({ pos.x - 1, pos.y + 1 }, outlineColor, text);
    ImGui::GetBackgroundDrawList()->AddText({ pos.x + 1, pos.y + 1 }, outlineColor, text);
    ImGui::GetBackgroundDrawList()->AddText(pos, textColor, text);
}

bool lastThirdPersonState = false;
bool lastNoClipState = false;
bool lastFloresState = false;

auto Render::Log() -> void {


    if (Globals->Log.bNoCliplog != lastNoClipState) {
        if (Globals->Log.bNoCliplog) {
            AddMessage("NoClip enabled");

        }
        else {
            AddMessage("NoClip disabled");
        }


        lastNoClipState = Globals->Log.bNoCliplog;
    }


    if (Globals->Log.bThirdPersonlog != lastThirdPersonState) {
        if (Globals->Log.bThirdPersonlog) {
            AddMessage("Third Person enabled");
        }
        else {
            AddMessage("Third Person disabled");
        }

        lastThirdPersonState = Globals->Log.bThirdPersonlog;
    }

}


auto Render::Background() -> void {
   
    water_mark_outline({ 2, 5 }, IM_COL32_BLACK, IM_COL32_WHITE, "BlindEye.io");
 
    currentTime += ImGui::GetIO().DeltaTime;

    messages.erase(std::remove_if(messages.begin(), messages.end(), [](const Message& msg) {
        return currentTime - msg.timestamp > messageDuration;
        }), messages.end());


    for (size_t i = 0; i < messages.size(); ++i) {

        messages[i].position.y = 20.0f + static_cast<float>(i) * 20.0f;
        water_mark_outline(messages[i].position, IM_COL32_BLACK, IM_COL32_WHITE, messages[i].text.c_str());
    }
}



void Messages(const char* input) {
    std::string cmd(input);

    cmd.erase(0, cmd.find_first_not_of(" \t"));
    cmd.erase(cmd.find_last_not_of(" \t") + 1);

    if (cmd.empty())
        return;

    consoleMessages.push_back("> " + cmd); 

    if (cmd == "help") {
        consoleMessages.push_back("Available commands:");
        consoleMessages.push_back("  help - Display this help message");
        consoleMessages.push_back("  cls  - Clear the console");
    }
    else if (cmd == "cls") {
        consoleMessages.clear(); 
    }
    else {
        
    }

}

inline bool autoScroll = true;


void Init() {
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 0.0f;
    style.FrameRounding = 0.0f;
    style.WindowBorderSize = 0.0f;
    style.FrameBorderSize = 0.0f;
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.06f, 0.06f, 0.9f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.1f, 0.1f, 0.1f, 1.0f);
    style.Colors[ImGuiCol_Text] = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.2f, 0.2f, 0.2f, 0.4f);
}

void Render::RenderConsole() {

    Init();

    ImGuiIO& io = ImGui::GetIO();
    ImVec2 displaySize = io.DisplaySize;

    float consoleHeight = displaySize.y * 0.5f;
    ImGui::SetNextWindowSize(ImVec2(displaySize.x, consoleHeight), ImGuiCond_Always);
    ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8, 8));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.06f, 0.06f, 0.06f, 0.95f));

    ImGui::Begin("Console", &showConsole,
        ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoCollapse |
        ImGuiWindowFlags_NoSavedSettings);

    ImGui::BeginChild("Log", ImVec2(0, -ImGui::GetFrameHeightWithSpacing()), false);
    for (const auto& msg : consoleMessages) {
        ImGui::TextUnformatted(msg.c_str());
    }
    ImGui::EndChild();

    
    ImGui::PushItemWidth(-1.0f);
    if (ImGui::InputText("##console_input", inputBuffer, IM_ARRAYSIZE(inputBuffer),
        ImGuiInputTextFlags_EnterReturnsTrue | ImGuiInputTextFlags_AutoSelectAll)) {
        Messages(inputBuffer);
        inputBuffer[0] = '\0';
        ImGui::SetKeyboardFocusHere(-1);
    }
    ImGui::PopItemWidth();

    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar();
}
