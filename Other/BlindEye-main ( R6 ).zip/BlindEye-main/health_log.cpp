#include "BlindEye.hpp"
#include "interface.hpp"

static std::unordered_map<scimitar::Entity*, uint32_t> previous_health_map;


auto BlindEye::Health_Message(bool enable) -> void {
    if (!enable) {
        //Render::AddMessage("Health message disabled");
        return;
    }

    auto game_manager = scimitar::game_manager::get_instance();
    auto controller_list = game_manager->get_controller_list();
    auto local_controller = game_manager->get_local_controller();

    for (int i = 0; i < controller_list.second; ++i) {
        auto controller = *reinterpret_cast<scimitar::Controller**>(controller_list.first + (0x8 * i));
        if (!utils::memory::valid_pointer(controller)) continue;
        if (controller == local_controller) continue;

        auto pawn = controller->get_pawn();
        if (!utils::memory::valid_pointer(pawn)) continue;

        auto entity = pawn->get_entity();
        if (!utils::memory::valid_pointer(entity)) continue;

        auto replication = controller->get_replication();
        if (!utils::memory::valid_pointer(replication)) continue;

        const char* user_name = replication->get_player_name();
        uint32_t current_health = entity->get_health();

        auto it = previous_health_map.find(entity);
        if (it != previous_health_map.end()) {
            uint32_t previous_health = it->second;

            if (current_health < previous_health) {
                uint32_t damage_taken = previous_health - current_health;

                std::string message = std::format(
                    "{} took {} damage (remaining health: {})",
                    user_name,
                    damage_taken,
                    current_health
                );

                Render::AddMessage(message);
                
                char* msg_cstr = const_cast<char*>(message.c_str());
                char* msg_ptr = msg_cstr;

                int type = 0;

                if (Globals->Visuals.bInChat) {
                    scimitar::chat_message(&msg_ptr, &type);
                   
                }
               
            }
        }
        previous_health_map[entity] = current_health;
    }
}