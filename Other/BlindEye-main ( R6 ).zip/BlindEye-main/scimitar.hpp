#pragma once
#ifndef _scimitar
#define _scimitar

#include "havok_math.hpp"

#include "engine.hpp"

#include "SpoofCall/spoof_call.hpp"

#include "xmmintrin.h"

#include "ImGui/imgui.h"

#include <chrono>

#include <emmintrin.h>

#include "config.hpp"

namespace scimitar {

	class round_state;
	class game_manager;
	class Controller;
	inline Controller* local_controller = 0x0;
	class Replication;
	class Pawn;
	class cpawn_aim_manager;
	class Entity;
	class physic_world;
	class weapon_component;
	class WeaponData;

	inline const char* OPs[36][7] = {
	{ "",           "Smoke",        "Mute",     "Sledge",   "Thatcher", "",     "" }, // 0
	{ "Recruit",    "Castle",       "Ash",      "Pulse",    "Thermite", "",     "" }, // 1
	{ "",           "Doc",          "Rook",     "Twitch",   "Montagne", "",     "" }, // 2
	{ "",           "Glaz",         "Fuze",     "Kapkan",   "Tachanka", "",     "" }, // 3
	{ "",           "Blitz",        "Iq",       "Jager",    "Bandit",   "",     "" }, // 4
	{ "",           "Buck",         "Frost",    "",         "",         "",     "" }, // 5
	{ "",           "Blackbeard",   "Valkyrie", "",         "",         "",     "" }, // 6
	{ "",           "Capitao",      "Caveira",  "",         "",         "",     "" }, // 7
	{ "",           "Hibana",       "Echo",     "",         "",         "",     "" }, // 8
	{ "",           "Jackal",       "Mira",     "",         "",         "",     "" }, // 9
	{ "",           "Ying",         "Lesion",   "",         "",         "",     "" }, // 10
	{ "",           "Ela",          "Zofia",    "",         "",         "",     "" }, // 11
	{ "",           "Dokkaebi",     "Vigil",    "",         "",         "",     "" }, // 12
	{ "",           "",             "Lion",     "Finka",    "",         "",     "" }, // 13
	{ "",           "Maestro",      "Alibi",    "",         "",         "",     "" }, // 14
	{ "",           "Maverick",     "Clash",    "",         "",         "",     "" }, // 15
	{ "",           "Nomad",        "Kaid",     "",         "",         "",     "" }, // 16
	{ "",           "Mozzie",       "Gridlock", "",         "",         "",     "" }, // 17
	{ "",           "Nokk",         "",         "",         "",         "",     "" }, // 18
	{ "",           "Warden",       "",         "",         "",         "",     "" }, // 19
	{ "",           "Goyo",         "",         "",         "",         "",     "" }, // 20
	{ "",           "Amaru",        "",         "",         "",         "",     "" }, // 21
	{ "",           "Kali",         "Wamai",    "Ace",      "Aruni",    "Osa",  "Grim"}, // 22
	{ "",           "Oryx",         "Flores",   "Azami",    "Fenrir",   "",     "" }, // 23
	{ "",           "Iana",         "",         "",         "",         "",     "" }, // 24
	{ "",           "Melusi",       "",         "",         "",         "",     "" }, // 25
	{ "Zero",       "Striker",      "Sentry",   "",         "",         "",     "" }, // 26
	{ "Thunderbird","",             "",         "",         "",         "",     "" }, // 27
	{ "Thorn",      "",             "",         "",         "",         "",     "" }, // 28
	{ "Sens",       "",             "",         "",         "",         "",     "" }, // 29
	{ "Solis",      "",             "",         "",         "",         "",     "" }, // 30
	{ "Brava",      "",             "",         "",         "",         "",     "" }, // 31
	{ "Ram",        "",             "",         "",         "",         "",     "" }, // 32
	{ "Tubarao",    "",             "",         "",         "",         "",     "" }, // 33
	{ "Deimos",     "",             "",         "",         "",         "",     "" }, // 34
	{ "Skopos",     "",             "",         "",         "",         "",     "" }, // 35
	};


	enum BipedBoneID
	{
		PELVIS = 0xDED10611,
		STOMACH = 0x530EC1CB,
		LUMBAR = 0x8F39FA4E,
		THORAX = 0x1630ABF4,
		SPINE = 0x8023796D,
		NECK = 0x7C159A2,

		LHIP = 0x176183F0,
		LKNEE = 0x60DF401,
		LFOOT = 0x58988870,
		LTOE = 0xB95094E1,

		LCLAVICLE = 0x2D4660A8,
		LSHOULDER = 0xEB830ADA,
		LELBOW = 0x89B93A80,
		LHAND = 0xB675F36C,

		RHIP = 0x757F1291,
		RKNEE = 0x863D09FC,
		RFOOT = 0x9B14362C,
		RTOE = 0x42BE0FCB,

		RCLAVICLE = 0xF60647E5,
		RSHOULDER = 0x6BB3F727,
		RELBOW = 0x7257a1AA,
		RHAND = 0x75F94D30,

		HEAD = 0xA9CEFD4A,
		ROOT = 0x22E53C03,

		// Left hand fingers
		LTHUMB1 = 0x78f4e1ac,
		LTHUMB2 = 0xe1fdb016,
		LTHUMB3 = 0x96fa8080,
		LINDEX1 = 0x1e679ed0,
		LINDEX2 = 0x876ecf6a,
		LINDEX3 = 0xf069fffc,
		LMIDDLE1 = 0x911fbacf,
		LMIDDLE2 = 0x816eb75,
		LMIDDLE3 = 0x7f11dbe3,
		LRING1 = 0xd34048cf,
		LRING2 = 0x4a491975,
		LRING3 = 0x3d4e29e3,
		LPINKY1 = 0xf4a6edbc,
		LPINKY2 = 0x6dafbc06,
		LPINKY3 = 0x1aa88c90,
		// Right hand fingers
		RTHUMB1 = 0x9829becf,
		RTHUMB2 = 0x120ef75,
		RTHUMB3 = 0x7627dfe3,
		RINDEX1 = 0xfebac1b3,
		RINDEX2 = 0x67b39009,
		RINDEX3 = 0x10b4a09f,
		RMIDDLE1 = 0x45445772,
		RMIDDLE2 = 0xdc4d06c8,
		RMIDDLE3 = 0xab4a365e,
		RRING1 = 0xdbf635c5,
		RRING2 = 0x42ff647f,
		RRING3 = 0x35f854e9,
		RPINKY1 = 0x147bb2df,
		RPINKY2 = 0x8d72e365,
		RPINKY3 = 0xfa75d3f3,
	};

	struct _BoneInfo
	{
	private:
		char pad1[0x18];//0x0
	public:
		std::uint64_t EncryptedEntity;//0x18
	private:
		char pad2[0x34];//0x20
	public:
		BipedBoneID BipedBoneID;//0x54
	};


	inline std::vector<std::pair<BipedBoneID, BipedBoneID>> BonesPair = {
		// Right leg
		{ RTOE, RFOOT },
		{ RFOOT, RKNEE },
		{ RKNEE, RHIP },
		{ RHIP, PELVIS },

		// Left leg
		{ LTOE, LFOOT },
		{ LFOOT, LKNEE },
		{ LKNEE, LHIP },
		{ LHIP, PELVIS },

		// Spine
		{ PELVIS, STOMACH },
		{ STOMACH, LUMBAR },
		{ LUMBAR, THORAX },
		{ THORAX, SPINE },
		{ SPINE, NECK },

		// Left arm and hand
		{ SPINE, LSHOULDER },
		{ LSHOULDER, LELBOW },
		{ LELBOW, LHAND },
		{ LHAND, LTHUMB1 },
		{ LTHUMB1, LTHUMB2 },
		{ LTHUMB2, LTHUMB3 },
		{ LHAND, LINDEX1 },
		{ LINDEX1, LINDEX2 },
		{ LINDEX2, LINDEX3 },
		{ LHAND, LMIDDLE1 },
		{ LMIDDLE1, LMIDDLE2 },
		{ LMIDDLE2, LMIDDLE3 },
		{ LHAND, LRING1 },
		{ LRING1, LRING2 },
		{ LRING2, LRING3 },
		{ LHAND, LPINKY1 },
		{ LPINKY1, LPINKY2 },
		{ LPINKY2, LPINKY3 },

		// Right arm and hand
		{ SPINE, RSHOULDER },
		{ RSHOULDER, RELBOW },
		{ RELBOW, RHAND },
		{ RHAND, RTHUMB1 },
		{ RTHUMB1, RTHUMB2 },
		{ RTHUMB2, RTHUMB3 },
		{ RHAND, RINDEX1 },
		{ RINDEX1, RINDEX2 },
		{ RINDEX2, RINDEX3 },
		{ RHAND, RMIDDLE1 },
		{ RMIDDLE1, RMIDDLE2 },
		{ RMIDDLE2, RMIDDLE3 },
		{ RHAND, RRING1 },
		{ RRING1, RRING2 },
		{ RRING2, RRING3 },
		{ RHAND, RPINKY1 },
		{ RPINKY1, RPINKY2 },
		{ RPINKY2, RPINKY3 },
	};


	inline std::vector<std::pair<BipedBoneID, BipedBoneID>> HandsPair = {
	

		// Left arm and hand
		{ LHAND, LTHUMB1 },
		{ LTHUMB1, LTHUMB2 },
		{ LTHUMB2, LTHUMB3 },
		{ LHAND, LINDEX1 },
		{ LINDEX1, LINDEX2 },
		{ LINDEX2, LINDEX3 },
		{ LHAND, LMIDDLE1 },
		{ LMIDDLE1, LMIDDLE2 },
		{ LMIDDLE2, LMIDDLE3 },
		{ LHAND, LRING1 },
		{ LRING1, LRING2 },
		{ LRING2, LRING3 },
		{ LHAND, LPINKY1 },
		{ LPINKY1, LPINKY2 },
		{ LPINKY2, LPINKY3 },

		{ RHAND, RTHUMB1 },
		{ RTHUMB1, RTHUMB2 },
		{ RTHUMB2, RTHUMB3 },
		{ RHAND, RINDEX1 },
		{ RINDEX1, RINDEX2 },
		{ RINDEX2, RINDEX3 },
		{ RHAND, RMIDDLE1 },
		{ RMIDDLE1, RMIDDLE2 },
		{ RMIDDLE2, RMIDDLE3 },
		{ RHAND, RRING1 },
		{ RRING1, RRING2 },
		{ RRING2, RRING3 },
		{ RHAND, RPINKY1 },
		{ RPINKY1, RPINKY2 },
		{ RPINKY2, RPINKY3 },
	};

	enum class MeleeAttackType : std::uint32_t
	{
		MeleeAttackType_Undefined = 0x0,
		MeleeAttackType_Knife = 0x1,
		MeleeAttackType_GunButt_Wall = 0x2,
		MeleeAttackType_Punch = 0x3,
		MeleeAttackType_MultipleHit = 0x4,
		MeleeAttackType_GunButt_Shield = 0x5,
		MeleeAttackType_GunButt_AI = 0x6,
		MeleeAttackType_Shield = 0x7,
		MeleeAttackType_Kick = 0x8,
		MeleeAttackType_Finisher = 0x9,
		MeleeAttackType_ArmSwing = 0xA,
		MeleeAttackType_Stomp = 0xB,
		MeleeAttackType_TwoHitsProp = 0xC,
		MeleeAttackType_ThreeHitsProp = 0xD,
		MeleeAttackType_ObjectiveAttack = 0xE
	};

	enum class MeleeState : uint32_t {
		MeleeState_None = 0x0,
		MeleeState_PreAttack = 0x3,
		MeleeState_Hit = 0x5,
		MeleeState_Miss = 0x6,
		MeleeState_WaitingForDetectionPreAttack = 0x7,
		MeleeState_WaitingForDetectionPreHit = 0x8
	};


	enum EMovementComponent : uint32_t
	{
		EDrvAnimation = 0x2800E489,
		EDrvSprinting = 0xDFD83971,
		EDrvWeapon = 0xA6F78616,
		EDrvMelee = 0xB1531297,
		EDrvShooting = 0xCE425D1A,
		EDrvDrone = 0x903F7852,
		EDrvGadget = 0x799B767A,
		EDrvLeaning = 0x2434CD8B,
		EDrvVaulting = 0xF6D74D80,
		EDrvContext = 0x5F2FB343,
		EDrvNavigation = 0x529E3224,
		EDrvInteraction = 0xBDF390BC,

		ESrvR6AIData = 0x229E5633,
		ESrvEffect = 0xB1059FBA,
		ESrvMobility = 0x948CF73,
		ESrvDebug = 0x646F16A3,
		ESrvGroup = 0x650A15C1,
		ESrvCoordinator = 0x9CFFF5DD,
		ESrvScripting = 0x8ABC2229,
		ESrvPerception = 0xCF133C7C,
		ESrvLocation = 0x818666A4,
		ESrvAbilities = 0x65EAE982,
		ESrvHostage = 0xA0C9A8AB,

		Unknown1 = 0xE7BB7DA4,
		Unknown7 = 0xDBE19682,
		Unknown10 = 0x8CB9FFB7
	};

	struct _WeaponComponentInfo
	{
		char pad[0x80];//0x0
		std::uint64_t entity;
	};

	inline std::uint64_t(*fn_get_weapon_component)(_WeaponComponentInfo*);
	inline void (*shoot_bullet)(weapon_component*, ubiVector4*, ubiVector4*);
	inline std::uint32_t(*get_ammo)(uint64_t, uint32_t);
	inline void (*fn_decrease_ammo)(weapon_component*);
	inline void (*fn_auto_reload)(weapon_component*);
	inline void(*MeleeDamage)(
		scimitar::Controller* LocalController,
		scimitar::Entity* LocalEntity,
		std::uint64_t healthComp,
		scimitar::Entity* Target,
		ubiVector4* a5,
		float* a6,
		ubiVector4* a7,
		std::uint32_t a8,
		std::uint32_t a9,
		std::uint32_t a10,
		std::uint32_t a11,
		std::uint32_t a12,
		std::uint32_t a13,
		char a14,
		std::uint64_t a15,
		std::uint32_t a16,
		std::uint64_t a17);

	inline void (*self_revive_call)(Pawn*, unsigned int);



	inline void(*fn_ray_cast)(void*);
	inline void(*fn_free_ray)(void*);

	struct Trace
	{
		DWORD tmp1;
		__m128 tmp2; // ubiQuaternion
		__m128 tmp3; // ubiQuaternion
	};



	inline bool world_to_screen(const ubiVector4& World, ubiVector2& screen)
	{
		const ubiViewMatrix& vm = *reinterpret_cast<ubiViewMatrix*>(*reinterpret_cast<ptrdiff_t*>(ImageBase + 0xC0DEE58) + 0x250);

		float w = vm[0][3] * World.x + vm[1][3] * World.y + vm[2][3] * World.z + vm[3][3];

		if (w < 0.001f)
			return false;

		float x = World.x * vm[0][0] + World.y * vm[1][0] + World.z * vm[2][0] + vm[3][0];
		float y = World.x * vm[0][1] + World.y * vm[1][1] + World.z * vm[2][1] + vm[3][1];


		float nx = x / w;
		float ny = y / w;


		const ImVec2 size = ImGui::GetIO().DisplaySize;


		screen.x = (size.x * 0.5f * nx) + (size.x * 0.5f);
		screen.y = -(size.y * 0.5f * ny) + (size.y * 0.5f);

		if (screen.x < 0 || screen.y < 0 || screen.x > size.x || screen.y > size.y)
		{
			return false;
		}

		return true;
	};

	inline ubiVector4 get_camera_position() {

		auto ptr1 = utils::memory::Read<uint64_t>(ImageBase + 0xC0DEE58); //UPDATED 23 / 10 / 2024
		auto cam = utils::memory::Read<ubiVector4>(ptr1 + 0x1A0);
		return cam;
	}

	inline uint64_t get_camera_fx() {
		return utils::memory::Read<uint64_t>(ImageBase + 0xBB0C9E0);
	}


	inline uint64_t get_player_camera_manager() {

		uint64_t Base = ImageBase + 0xBA3C1C0;
		std::vector<uintptr_t> Chain = { 0xB8, 0x0, 0x0, 0x2BA };
		uint64_t pcm = utils::memory::ReadPtr<uint64_t>(Base, Chain);

		return pcm;
	}

	inline uint64_t get_no_clip() {

		uint64_t noClipBase = ImageBase + 0x0BA06120;
		std::vector<uintptr_t> noClipChain = { 0x98, 0x10, 0x5D0 };

		uint64_t no_clip_address = utils::memory::GetAddr(noClipBase, noClipChain);

		return no_clip_address;
	}

	inline void chat_message(char** text, int* a2) {

		typedef void(__fastcall* SendChatMessage)(char** Text, int* a2);

		SendChatMessage chat_call = (SendChatMessage)(ImageBase + 0x34D9A0);

		spoof_call(chat_call, text, a2);
	}

	class round_state {
	public:


		static int get_instance() {

			uint64_t RoundBase = ImageBase + 0x0C90E218;
			std::vector<uintptr_t> RoundChain = { 0x28, 0x10, 0x70, 0x48, 0x288 };
			int roundstate = utils::memory::ReadPtr<int>(RoundBase, RoundChain);

			return roundstate;

		}
	};




	class game_manager {
	public:


		static game_manager* get_instance()
		{

			uint64_t qword_BA8BB50 = *(uint64_t*)(ImageBase + 0xBA8BB50);

			uint64_t v5, v6, v10;

			v5 = (__ROR8__(utils::memory::current_peb(), 0xC) ^ 0xDEA99BA33834E09Cui64) + (retaddr >> 0x21);
			if (HIDWORD(v5))
				v6 = v5 % 4;
			else
				v6 = (unsigned int)v5 % 4;
			if (v6)
			{
				if (v6 == 1)
				{
					v10 = __ROL8__((qword_BA8BB50 + 0x5BC676C774C8D2A4i64) ^ 0x856FED644CFC322Eui64, 0x2A);
				}
				else if (v6 == 2)
				{
					v10 = (__ROL8__(qword_BA8BB50, 0x2A) ^ 0x856FED644CFC322Eui64) + 0x5BC676C774C8D2A4i64;
				}
				else
				{
					v10 = (__ROL8__(qword_BA8BB50, 0x2A) + 0x5BC676C774C8D2A4i64) ^ 0x856FED644CFC322Eui64;
				}
			}
			else
			{
				v10 = __ROL8__(qword_BA8BB50 + 0x5BC676C774C8D2A4i64, 0x2A) ^ 0x856FED644CFC322Eui64;
			}


			return reinterpret_cast<scimitar::game_manager*>(v10);
		}



		std::pair<scimitar::Controller*, uint32_t> get_controller_list()
		{

			unsigned __int64(*sub_1605A0)(uint64_t * a1) = reinterpret_cast<decltype(sub_1605A0)>(ImageBase + 0x89BD780);
			unsigned __int64(*sub_160D00)(uint64_t * a1) = reinterpret_cast<decltype(sub_160D00)>(ImageBase + 0x89BDB50);

			__int64 List = spoof_call(sub_1605A0, (uint64_t*)(this + 0x728));
			__int64 Count = spoof_call(sub_160D00, (uint64_t*)(this + 0x728));

			return { reinterpret_cast<scimitar::Controller*>(List), static_cast<uint32_t>((Count - List) / 0x8) };
		}


		Controller* get_local_controller()
		{
			if (!local_controller)
				local_controller = *reinterpret_cast<Controller**>(this->get_controller_list().first);

			return local_controller;
		}
	};

	class controller_local {
	public:

		static uint64_t get_local_controller()
		{

			typedef uint64_t(__fastcall* Localplayer0x)();
			auto Localplayer = (Localplayer0x)(ImageBase + 0x1CFF2C0);
			auto localplayer1 = FUNCTION(Localplayer);

			return localplayer1;

		}

	};

	class Controller {
	public:

		Pawn* get_pawn() {

			if (!utils::memory::valid_pointer(this))
				return 0;

			auto v23 = *(_QWORD*)(this + 0x20) - 0x16i64;

			return reinterpret_cast<scimitar::Pawn*>(v23);
		}



		Replication* get_replication()
		{
			if (!utils::memory::valid_pointer(this))
				return 0;

			auto v244 = ((0x995B3412FDDC1645ui64 - __ROR8__(utils::memory::current_peb(), 0xC)) ^ (retaddr >> 0x21)) % 5;

			__int64 v111, v112, v113, v115, PlayerReplication;

			__int64 enc = *reinterpret_cast<std::uint64_t*>(this + 0x58);
			__int64 enc32 = *reinterpret_cast<std::uint32_t*>(this + 0x58);


			if (!v244)
			{
				v111 = (enc + 0x4E9D957871B7F916i64) ^ 0xD7C6A16A686D99E6ui64;
				v112 = v111 << 0x28;
				v113 = (v111 << 0x18) & 0xFF00000000000000ui64;
			LABEL_323:
				PlayerReplication = (v111 >> 0x28) & 0xFF00 | v113 | (v111 >> 8) & 0xFF00000000i64 | HIBYTE(v111) | (unsigned int)v111 & 0xFFFF0000 | v112 & 0xFFFF0000000000i64;


				return reinterpret_cast<scimitar::Replication*>(PlayerReplication);
			}
			if (v244 == 1)
			{
				v115 = ((unsigned __int64)(enc + 0x4E9D957871B7F916i64) >> 0x28) & 0xFF00 | ((enc + 0x4E9D957871B7F916i64) << 0x18) & 0xFF00000000000000ui64 | ((unsigned __int64)(enc + 0x4E9D957871B7F916i64) >> 8) & 0xFF00000000i64 | ((unsigned __int64)(enc + 0x4E9D957871B7F916i64) >> 0x38) | (enc32 + 0x71B7F916) & 0xFFFF0000 | ((enc + 0x4E9D957871B7F916i64) << 0x28) & 0xFFFF0000000000i64;
			LABEL_326:
				PlayerReplication = v115 ^ 0xD7C6A16A686D99E6ui64;

				return reinterpret_cast<scimitar::Replication*>(PlayerReplication);
			}
			if (v244 != 2)
			{
				if (v244 == 3)
				{
					v111 = (enc ^ 0xD7C6A16A686D99E6ui64) + 0x4E9D957871B7F916i64;
					v112 = v111 << 0x28;
					v113 = (v111 << 0x18) & 0xFF00000000000000ui64;
					goto LABEL_323;
				}
				v115 = ((enc << 0x18) & 0xFF00000000000000ui64)
					+ ((enc << 0x28) & 0xFFFF0000000000i64)
					+ ((enc >> 8) & 0xFF00000000i64)
					+ ((enc >> 0x28) & 0xFF00i64)
					+ (enc & 0xFFFF0000i64)
					+ HIBYTE(enc)
					+ 0x4E9D957871B7F916i64;
				goto LABEL_326;
			}

			PlayerReplication = (((enc ^ 0xD7C6A16A686D99E6ui64) << 0x18) & 0xFF00000000000000ui64)
				+ (((enc ^ 0xD7C6A16A686D99E6ui64) << 0x28) & 0xFFFF0000000000i64)
				+ (((enc ^ 0xD7C6A16A686D99E6ui64) >> 8) & 0xFF00000000i64)
				+ (((enc ^ 0xD7C6A16A686D99E6ui64) >> 0x28) & 0xFF00)
				+ ((enc32 ^ 0x686D99E6) & 0xFFFF0000)
				+ ((enc ^ 0xD7C6A16A686D99E6ui64) >> 0x38)
				+ 0x4E9D957871B7F916i64;

			return reinterpret_cast<scimitar::Replication*>(PlayerReplication);
		}


		uint64_t get_player_camera_manager() {


			if (!utils::memory::valid_pointer(this))
				return 0;


			uint64_t v240 = ((0x27F979D63ECD0870i64 - __ROR8__(utils::memory::current_peb(), 0xC) - 0xF) ^ (retaddr >> 0x21)) % 2;
			uint64_t pcm{ 0x0 };
			if (v240)
			{
				pcm = (__ROL8__(*(_QWORD*)(this + 0x3B0), 0x35) - 0x1Ai64) ^ 0x27F979D63ECD0870i64;
			}
			else
			{
				pcm = (__ROL8__(*(_QWORD*)(this + 0x3B0), 0x35) ^ 0x27F979D63ECD0870i64) - 0x1A;
			}

			return pcm;


		}


		int get_alliance()
		{

			static int(*getteamid)(scimitar::Controller*) = reinterpret_cast<decltype(getteamid)>(ImageBase + 0xE81EE0);

			return spoof_call(getteamid, this);
		}


		void Melee(scimitar::Entity* LocalEntity, scimitar::Entity* Target, ubiVector4 Pos) {

			if (!utils::memory::valid_pointer(this) || (!utils::memory::valid_pointer(Target)))
				return;



			ubiVector4 Destination = ubiVector4(Pos.x, Pos.y, Pos.z, 0.f);

			//Vector4 pos2 = Vector4(0.100000f, 0.300000f, 0.100000f, 0.000000f);
			ubiVector4 pos2 = ubiVector4(0.0f, 0.0f, 0.0f, 0.0f);

			//float FloatPos[] = { 0.9999998808f, 0.f, 0.f, 0.f, Destination.x,  Destination.y, Destination.z, 0.f, pos2.x, pos2.z, pos2.y, 0.f };
			float FloatPos[] = { 0.0f, 0.f, 0.f, 0.f, Destination.x, Destination.y, Destination.z, 0.f, pos2.x, pos2.z, pos2.y, 0.f };

			static const int Damage = 0xFF;
			static const auto DamageType = 0x1;//1 = Melee, 0xB = Skull

			spoof_call(MeleeDamage, this, LocalEntity, (std::uint64_t)0i64, Target, &Destination, FloatPos, &pos2, (std::uint32_t)1, (std::uint32_t)DamageType, (std::uint32_t)Damage, (std::uint32_t)0x2710, (std::uint32_t)3, (std::uint32_t)0, (char)0, (std::uint64_t)0i64, (std::uint32_t)0, (std::uint64_t)0x00000007F1A5C282);
		}
	};

	class Replication {
	public:

		const char* get_player_name() {

			if (!utils::memory::valid_pointer(this)) return "Terrorist";
			return utils::memory::Read<const char*>(reinterpret_cast<uintptr_t>(this) + 0x758);

		}

		std::pair<std::uint8_t, std::uint8_t> get_ctu_op()
		{
			if (!utils::memory::valid_pointer(this))
				return { 0x1, 0x0 };

			static uint32_t offset = 0x3D0;

			auto v9 = ((unsigned __int64)utils::memory::current_peb() >> 0xC) ^ 0x6AF591BE8658A093i64;
			auto v10 = v9 + (retaddr >> 0x21);
			__int64 v11, v14;

			uint32_t OP, CTU;
			if (HIDWORD(v10))
				v11 = (v9 + (retaddr >> 0x21)) % 2;
			else
				v11 = (unsigned int)v10 % 2;
			if (v11)
				OP = (unsigned int)(__ROL4__(*(uint32_t*)(this + 4 + offset), 4) - 0x4F16B1F9) >> 0x18;
			else
				LOWORD(OP) = (unsigned __int8)(*(uint32_t*)(this + 4 + offset) >> 0x14) + 0x4E07;

			auto v13 = __ROR8__(utils::memory::current_peb(), 0xC) + 0x3DC5B23F46DC0124i64 - (retaddr >> 0x21);
			if (HIDWORD(v13))
				v14 = v13 % 3;
			else
				v14 = (unsigned int)v13 % 3;
			if (v14)
			{
				if (v14 == (_DWORD)0xD3758 - 0xD3757)
					LOBYTE(CTU) = (*(uint8_t*)(this + 2 + offset) ^ 0x7F) + 0x52;
				else
					CTU = ((unsigned int)(*(uint32_t*)(this + offset) + 0x332B1C52) >> 0x10) ^ 0xAE;
			}
			else
			{
				LOBYTE(CTU) = (*(uint8_t*)(this + 2 + offset) ^ 0x7F) +
					((((*(uint8_t*)(this + 1 + offset) ^ 0xC0) << 8) + (*(uint8_t*)(this + offset) ^ 0xAEu) + 0x2B1C52) >> 0x10);
			}

			return { CTU, OP };
		}
	};






	class Pawn {
	public:

		Entity* get_entity() {
			if (!utils::memory::valid_pointer(this))
				return 0;

			__int64 v13{ };
			__int64 v17{ };

			auto v12 = (((unsigned __int64)utils::memory::current_peb() >> 0xC) ^ 0x87BD6612) + (retaddr >> 0x21);
			if (HIDWORD(v12))
				v13 = v12 % 6;
			else
				v13 = (unsigned int)v12 % 6;

			auto encrypted64 = *reinterpret_cast<std::uint64_t*>(this + 0x18);
			auto encrypted32 = *reinterpret_cast<std::uint32_t*>(this + 0x18);

			switch (v13)
			{
			case 0ui64:
				v17 = (((encrypted64 - 0xBi64) << 0x10) & 0xFF000000000000i64)
					+ (((unsigned __int64)(encrypted64 - 0xBi64) >> 0x18) & 0xFF0000)
					+ (((encrypted64 - 0xBi64) << 8) & 0xFF00000000000000ui64)
					+ ((encrypted32 - 0xB) & 0xFF00FF00)
					+ (((unsigned __int64)(encrypted64 - 0xBi64) >> 0x10) & 0xFF00000000FFi64)
					+ (((encrypted64 - 0xBi64) << 0x20) & 0xFF00000000i64)
					- 0x15;
				break;
			case 1ui64:
				goto LABEL_27;
			case 2ui64:
			case 3ui64:
				v17 = ((encrypted64 << 0x10) & 0xFF000000000000i64)
					+ ((encrypted64 >> 0x18) & 0xFF0000i64)
					+ ((encrypted64 << 8) & 0xFF00000000000000ui64)
					+ (encrypted64 & 0xFF00FF00i64)
					+ ((encrypted64 >> 0x10) & 0xFF00000000FFi64)
					+ ((encrypted64 << 0x20) & 0xFF00000000i64)
					- 0x20;
				break;
			case 4ui64:
			LABEL_27:
				v17 = ((unsigned __int64)(encrypted64 - 0x20i64) >> 0x18) & 0xFF0000 | ((encrypted64
					- 0x20i64) << 8) & 0xFF00000000000000ui64 | ((encrypted64 - 0x20i64) << 0x20) & 0xFF00000000i64 | (encrypted32 - 0x20) & 0xFF00FF00 | ((encrypted64 - 0x20i64) << 0x10) & 0xFF000000000000i64 | ((unsigned __int64)(encrypted64 - 0x20i64) >> 0x10) & 0xFF00000000FFi64;
				break;
			default:
				v17 = (((encrypted64 - 0x15i64) << 0x10) & 0xFF000000000000i64)
					+ (((unsigned __int64)(encrypted64 - 0x15i64) >> 0x18) & 0xFF0000)
					+ (((encrypted64 - 0x15i64) << 8) & 0xFF00000000000000ui64)
					+ ((encrypted32 - 0x15) & 0xFF00FF00)
					+ (((unsigned __int64)(encrypted64 - 0x15i64) >> 0x10) & 0xFF00000000FFi64)
					+ (((encrypted64 - 0x15i64) << 0x20) & 0xFF00000000i64)
					- 0xB;
				break;
			}

			return reinterpret_cast<scimitar::Entity*>(v17);
		}


		ubiVector4 get_bone_pos(BipedBoneID biped_bone)
		{
			if (!utils::memory::valid_pointer(this))
				return ubiVector4();

			__m128 out;

			static void(*GetBonePos)(_BoneInfo*, __m128*) = reinterpret_cast<decltype(GetBonePos)>(ImageBase + 0x35E1C40);

			auto encrypted = *reinterpret_cast<std::uint64_t*>(this + 0x18);
			static _BoneInfo buffer;
			buffer.EncryptedEntity = encrypted;
			buffer.BipedBoneID = biped_bone;

			spoof_call(GetBonePos, &buffer, &out);

			return { out.m128_f32[0], out.m128_f32[1], out.m128_f32[2] };
		}

		cpawn_aim_manager* get_cpawn_aim_manager() {



			__int64 v45 = __int64(this); // rbp
			__int64 v72; // rdx
			unsigned __int64 v73; // rbx
			__int64 v74; // r9
			__int64 v75; // r8
			__int64 v76; // r13
			unsigned __int64 v77; // r12
			__m128 v462; // [rsp+30h] [rbp-1C8h] BYREF
			__m128 v464; // [rsp+50h] [rbp-1A8h] BYREF
			__m128 v470; // [rsp+B0h] [rbp-148h] B
			__m128 v473; // [rsp+E0h] [rbp-118h] BYREF
			__m128 v476; // [rsp+100h] [rbp-F8h]

			if (!utils::memory::valid_pointer(this)) return 0;

			auto v71 = ((unsigned __int64)utils::memory::current_peb() >> 0xC) + 0x338D6D3EF1EF605Ei64 - (retaddr >> 0x21);
			v464.m128_i32[0] = 0x3C527F56;
			if (HIDWORD(v71))
				v72 = v71 % 5;
			else
				v72 = (unsigned int)v71 % 5;
			v462.m128_u64[0] = v72;
			v464.m128_i32[0] = 0x45BB08AB;
			if (v72)
			{
				v476.m128_u64[0] = v462.m128_u64[0];
				v464.m128_i32[0] = 0x2E00C404;
				if (v462.m128_u64[0] != 1)
				{
					v470.m128_u64[0] = v476.m128_u64[0];
					v464.m128_i32[0] = 0x8D0E8085;
					if (v476.m128_u64[0] == 2
						|| (v473.m128_u64[0] = v470.m128_u64[0], v464.m128_i32[0] = 0xF0837BC8, v470.m128_u64[0] == 3))
					{
						v74 = *(_QWORD*)(v45 + 0x400) & 0xFF00i64;
						v75 = (*(_QWORD*)(v45 + 0x400) >> 0x18) & 0xFF000000i64;
						v72 = 0xFFFF00000000i64;
						v76 = (unsigned __int8)((unsigned __int16)WORD2(*(_QWORD*)(v45 + 0x400)) >> 8)
							+ ((*(_QWORD*)(v45 + 0x400) << 0x20) & 0xFF000000000000i64)
							+ ((*(_QWORD*)(v45 + 0x400) << 8) & 0xFFFF00000000i64)
							+ v75
							+ ((*(_QWORD*)(v45 + 0x400) >> 0x28) & 0xFF0000i64)
							+ v74
							+ (*(_QWORD*)(v45 + 0x400) << 0x38)
							- 0xD752B123C60E72Fi64;
						goto LABEL_123;
					}
					v464.m128_u64[0] = v473.m128_u64[0];
				}
				v77 = *(_QWORD*)(v45 + 0x400) - 0xD752B123C60E72Fi64;
				v74 = (unsigned __int16)(*(_WORD*)(v45 + 0x400) + 0x18D1) & 0xFF00;
				v75 = (v77 << 0x20) & 0xFF000000000000i64 | v74 | (v77 << 0x38) | (v77 >> 0x28) & 0xFF0000;
				v76 = (v77 >> 0x18) & 0xFF000000 | BYTE5(v77) | v75 | (v77 << 8) & 0xFFFF00000000i64;
				goto LABEL_123;
			}
			v73 = *(_QWORD*)(v45 + 0x400) - 0x68D34CA8DF86D686i64;
			v74 = (unsigned __int16)(*(_WORD*)(v45 + 0x400) + 0x297A) & 0xFF00;
			v75 = ((v73 >> 0x18) & 0xFF000000) + ((v73 >> 0x28) & 0xFF0000);
			v76 = BYTE5(v73)
				+ ((v73 << 0x20) & 0xFF000000000000i64)
				+ ((v73 << 8) & 0xFFFF00000000i64)
				+ v75
				+ v74
				+ (v73 << 0x38)
				+ 0x5B5E2196A325EF57i64;
		LABEL_123:

			return reinterpret_cast<cpawn_aim_manager*>(v76);
		}

		void send_melee_state(scimitar::MeleeState state)
		{
			if (!utils::memory::valid_pointer(this)) return;

			static void (*SendMeleeStateToServer)(std::uint64_t, scimitar::MeleeState) = reinterpret_cast<decltype(SendMeleeStateToServer)>(ImageBase + 0x8039FC0);

			auto Array = *reinterpret_cast<std::uint64_t*>(this + 0x6A8);
			if (!utils::memory::valid_pointer(Array)) return;


			auto Unk = *reinterpret_cast<std::uint64_t*>(Array + 0x18);
			if (!utils::memory::valid_pointer(Unk)) return;

			if (*(bool*)(Unk + 0x31))
				return;

			spoof_call(SendMeleeStateToServer, Unk, state);
		}


		void self_revive(unsigned int state) {

			spoof_call(self_revive_call, this, (unsigned int)state);

		}
	};

	class cpawn_aim_manager {
	public:

		void  set_view_angle(const ubiVector4& quat) {
			__m128 angle = *(__m128*)(&quat);

			using SetViewAngleFunc = void(__fastcall*)(cpawn_aim_manager*, __m128*);
			SetViewAngleFunc oSetViewAngle = reinterpret_cast<SetViewAngleFunc>(ImageBase + 0x95167C0);
			FUNCTION(oSetViewAngle, this, &angle);
		};
	};



	class World {
	public:

		static World* get_instance() {


			auto recordingManager = utils::memory::Read<uint64_t>(ImageBase + 0xC0EA680);

			return reinterpret_cast<World*>(utils::memory::Read<uint64_t>(recordingManager + 0x18));

		}

		std::pair<scimitar::Entity*, std::uint32_t> get_entity_list() {


			if (!utils::memory::valid_pointer(this)) {
				return std::pair<scimitar::Entity*, std::uint32_t>();
			}


			auto v37 = (__ROR8__(utils::memory::current_peb(), 0xC) ^ 0x8500B437B21DA29Dui64) + (retaddr >> 0x21);
			std::uint64_t v38{ 0x0 };
			if (HIDWORD(v37))
				v38 = v37 % 2;
			else
				v38 = (unsigned int)v37 % 2;

			auto enc = *reinterpret_cast<__m128i*>(this + 0x400);

			for (int i = 0; i < 2; i++)
			{
				if (v38)
				{
					enc.m128i_i64[i] = ((unsigned __int64)(enc.m128i_i64[i] - 0x7AFF4BC8D111093Bi64) >> 0x10) & 0xFF00000000i64 | ((*reinterpret_cast<std::uint32_t*>(&enc.m128i_i64[i]) + 0x2EEEF6C5) << 0x10) & 0xFF000000 | (enc.m128i_i64[i] - 0x7AFF4BC8D111093Bi64) & 0xFF000000000000FFui64 | ((unsigned int)(enc.m128i_i64[i] + 0x2EEEF6C5) >> 8) & 0xFFFF00 | ((enc.m128i_i64[i] - 0x7AFF4BC8D111093Bi64) << 8) & 0xFFFF0000000000i64;
				}
				else
				{
					enc.m128i_i64[i] = (((unsigned int)enc.m128i_i64[i] << 0x10) & 0xFF000000)
						+ (((unsigned int)enc.m128i_i64[i] >> 8) & 0xFFFF00)
						+ ((enc.m128i_i64[i] << 8) & 0xFFFF0000000000i64)
						+ ((enc.m128i_i64[i] >> 0x10) & 0xFF00000000i64)
						+ (enc.m128i_i64[i] & 0xFF000000000000FFui64)
						- 0x7AFF4BC8D111093Bi64;
				}
			}


			return  { reinterpret_cast<scimitar::Entity*> (enc.m128i_i64[0])  ,enc.m128i_i64[1] & 0x3FFFFFFF };
		}

		uint64_t Bomb()
		{

			auto FXManager = *reinterpret_cast<uintptr_t*>(this + 0xE8);
			auto tmp = *reinterpret_cast<uintptr_t*>(FXManager + 0x18);
			auto tmp2 = *reinterpret_cast<uintptr_t*>(tmp + 0x0);
			auto tmp3 = *reinterpret_cast<uintptr_t*>(tmp2 + 0x288);
			auto tmp4 = *reinterpret_cast<uintptr_t*>(tmp3 + 0x58);
			auto tmp5 = *reinterpret_cast<uintptr_t*>(tmp4 + 0x10);

			auto Bomb_Entity = *reinterpret_cast<uintptr_t*>(tmp5 + 0x8);

			return Bomb_Entity;

		}
	};


	class Entity {
	public:

		ubiVector4 Origin() {

			return *reinterpret_cast<ubiVector4*>(this + 0x50);

		}

		ubiVector4 rotation([[maybe_unused]] ubiVector4* newRotation = nullptr)
		{
			if (!this)
				return ubiVector4();

			if (newRotation)
			{
				*reinterpret_cast<ubiVector4*>(this + 0x60) = *newRotation;
				*reinterpret_cast<bool*>(this + 0x73) = false;
			}
			return *reinterpret_cast<ubiVector4*>(this + 0x60);
		}




		class class_descriptor
		{
		public:
			template <typename T>
			static class_descriptor* get(T instance)
			{
				if (!utils::memory::valid_pointer(instance))
					return nullptr;

				auto vt = *reinterpret_cast<std::uint64_t*>(instance);
				if (!utils::memory::valid_pointer(vt))
					return nullptr;

				return *reinterpret_cast<class_descriptor**>(vt + 0x30);
			}

		public:
			std::uint32_t class_id()
			{

				unsigned int v17; // edx
				_WORD* v14 = (_WORD*)this; // r8

				auto v15 = (((unsigned __int64)utils::memory::current_peb() >> 0xC) ^ 0x7D120018B9810926i64) + (retaddr >> 0x21);
				auto v16 = HIDWORD(v15) ? v15 % 2 : (unsigned int)v15 % 2;

				if (v16)
				{

					v17 = (unsigned __int8)((unsigned __int16)(v14[0xE] - 0x29D4) >> 8) | (unsigned __int16)((v14[0xE] - 0x29D4) << 8) | (*((_DWORD*)v14 + 7) + 0x5840D62C) & 0xFFFF0000;
				}
				else
				{
					v17 = (unsigned __int16)(v14[0xE] << 8)
						+ ((unsigned __int8)BYTE1(*((_DWORD*)v14 + 7)) | *((_DWORD*)v14 + 7) & 0xFFFF0000)
						+ 0x5840D62C;
				}

				return v17;
			}

			class_descriptor* parent()
			{
				if (!this)
					return 0;

				return *reinterpret_cast<class_descriptor**>(this + 0x10);
			}

			bool is(std::uint32_t crc, bool super = false)
			{
				if (!this)
					return false;

				if (this->class_id() == crc)
					return true;

				if (super && this->parent())
					return this->parent()->is(crc, true);

				return false;
			}
		};

		template <typename T>
		struct array_t
		{
			T* data;
			int flags;

			size_t size()
			{
				return flags & 0x3FFFFF;
			}

			T operator[](int i)
			{
				if (!utils::memory::valid_pointer(data))
					return { };

				if (i > size())
					return { };

				return data[i];
			}
		};

		template<class T>
		T  get_component(const char* klass)
		{
			if (!this)
				return 0;

			auto components = *reinterpret_cast<array_t<std::uint64_t>*>(this + 0xD8);
			if (!utils::memory::valid_pointer(components.data) || !components.size())
				return 0;

			auto crc = CRC32(klass);

			for (auto i{ 0 }; i < components.size(); i++)
			{
				auto component = components[i];
				if (!utils::memory::valid_pointer(component))
					continue;

				if (class_descriptor::get(component)->is(crc))
					return (T)component;
			}

			return 0;
		}

		physic_world* get_physic_world()
		{
			if (!utils::memory::valid_pointer(this))
			{
				//printf("invalid physic world due to invalid entity\n");
				return 0;
			}

			auto R6CharacterComponent = this->get_component<std::uint64_t>(_x("R6CharacterComponent"));
			if (!utils::memory::valid_pointer(R6CharacterComponent))
			{
				//printf("invalid character component\n");
				return 0;
			}

			auto m_PhysicWorld = *reinterpret_cast<physic_world**>(R6CharacterComponent + 0x3E0);
			if (!utils::memory::valid_pointer(m_PhysicWorld))
			{
				//printf("invalid physic world\n");
				return 0;
			}

			return m_PhysicWorld;
		}


		uintptr_t get_ai_component(int id) noexcept
		{
			constexpr int kValid{ 0xFF };
			const auto kEntry = *reinterpret_cast<uint8_t*>(this + id);
			if (kEntry != kValid)
			{
				const uintptr_t kComponentList = *reinterpret_cast<uintptr_t*>(*reinterpret_cast<uintptr_t*>(this + 0xD8) + 8 * kEntry);
				if (kComponentList)
					return kComponentList;
			}
			return 0;
		}


		uintptr_t get_movement(uint64_t Hash) noexcept
		{
			if (!utils::memory::valid_pointer(this)) return 0;

			using Prototype = uintptr_t(*)(uintptr_t, uint64_t, uintptr_t*);
			const Prototype function = reinterpret_cast<Prototype>(ImageBase + 0x66B88E0);

			uintptr_t zero = 0;
			uintptr_t AIComponent = this->get_ai_component(0x21D);
			if (AIComponent)
			{
				uintptr_t EntityAI = *reinterpret_cast<uintptr_t*>(AIComponent + 0x48);
				if (EntityAI)
				{

					uintptr_t* v7 = (uintptr_t*)FUNCTION(function, *(uintptr_t*)(EntityAI + 0x148), Hash, &zero);
					if (v7 && *v7)
					{
						return *v7;
					}

				}
			}
			return 0;
		};

		uint32_t get_health() // updated 29 / 10 / 2024
		{

			uint64_t v25, v43, v47, v49, v50, v28, v26;

			int Health;
			auto DamageComponentID = *reinterpret_cast<uint8_t*>(this + 0x217);
			auto DamageComponent = *reinterpret_cast<uint64_t*>(*reinterpret_cast<uint64_t*>(this + 0xD8) + DamageComponentID * 8ul);

			auto v24 = (((unsigned __int64)utils::memory::current_peb() >> 0xC) ^ 0x27560E53) + (retaddr >> 0x21);
			v25 = HIDWORD(v24) ? v24 % 4 : (unsigned int)v24 % 4;
			v49 = v25;
			if (v25)
			{
				v47 = v49;
				if (v49 == 1)
				{
					v28 = __ROL4__(*(_DWORD*)(DamageComponent + 0x1E0), 0x10) - 0x3D;
					Health = _byteswap_ulong(v28 & 0xFF0000FF) | v28 & 0xFFFF00;
				}
				else
				{
					v50 = v47;
					if (v47 == 2)
					{
						Health = __ROL4__(
							_byteswap_ulong(*(_DWORD*)(DamageComponent + 0x1E0) & 0xFF0000FF)
							+ (*(_DWORD*)(DamageComponent + 0x1E0) & 0xFFFF00)
							- 0x3D,
							0x10);
					}
					else
					{
						v43 = v50;
						Health = __ROL4__(
							_byteswap_ulong(*(_DWORD*)(DamageComponent + 0x1E0) & 0xFF0000FF) | *(_DWORD*)(DamageComponent + 0x1E0) & 0xFFFF00,
							0x10)
							- 0x3D;
					}
				}
			}
			else
			{
				v26 = __ROL4__(*(_DWORD*)(DamageComponent + 0x1E0), 0x10);
				Health = (v26 & 0xFFFF00) + _byteswap_ulong(v26 & 0xFF0000FF) - 0x3D;
			}
			return Health;
		}



		weapon_component* get_weapon_component() {

			if (!utils::memory::valid_pointer(this))
				return nullptr;

			_WeaponComponentInfo buffer;
			buffer.entity = reinterpret_cast<uintptr_t>(this);

			uint64_t weaponComponentAddr = spoof_call(fn_get_weapon_component, &buffer);
			return reinterpret_cast<weapon_component*>(weaponComponentAddr);
		}

		Pawn* get_pawn() {

			if (!utils::memory::valid_pointer(this))
			{
				//printf("invalid pawn due to invalid entity\n");
				return 0;
			}

			auto _Pawn = this->get_component<std::uint64_t>(_x("Pawn"));
			if (!utils::memory::valid_pointer(_Pawn))
			{
				//printf("invalid Pawn\n");
				return 0;
			}

			return reinterpret_cast<Pawn*>(_Pawn);
		}

		int health_state() {


			if (!utils::memory::valid_pointer(this)) return 2;




			unsigned __int64 v6; // rdx
			int v7; // eax
			unsigned __int8 v8; // r11
			unsigned int State; // r11d

			auto DamageComponentID = *reinterpret_cast<uint8_t*>(this + 0x217);
			auto DamageComponent = *reinterpret_cast<uint64_t*>(*reinterpret_cast<uint64_t*>(this + 0xD8) + DamageComponentID * 8ul);

			auto v5 = ((int)(utils::memory::current_peb()) >> 0xC) - (retaddr >> 0x21) + 0x7A426F8BF4883D52i64;
			if (HIDWORD(v5))
				v6 = v5 % 2;
			else
				v6 = (unsigned int)v5 % 2;
			if (v6)
			{
				v7 = *(_DWORD*)(DamageComponent + 0x194) - 0xB77C2D8;
				v8 = v7 ^ 0x7A;
			}
			else
			{
				v7 = (*(unsigned __int16*)(DamageComponent + 0x196) << 0x10)
					+ (*(unsigned __int8*)(DamageComponent + 0x194) ^ 0x7A | (*(unsigned __int8*)(DamageComponent + 0x195) << 8))
					- 0xB77C2D8;
				v8 = (*(_BYTE*)(DamageComponent + 0x194) ^ 0x7A) + 0x28;
			}

			State = v7 & 0xFFFFFF00 | v8;

			return State;

		}

		uint32_t get_hash() {
			return *reinterpret_cast<uint32_t*>(reinterpret_cast<uint8_t*>(this) + 0x84);
		}

		uint32_t get_second_hash() {
			return *reinterpret_cast<uint32_t*>(reinterpret_cast<uint8_t*>(this) + 0x88);
		}

		uint32_t get_third_hash() {
			return *reinterpret_cast<uint32_t*>(reinterpret_cast<uint8_t*>(this) + 0x8C);
		}

		uint32_t get_fourth_hash() {
			return *reinterpret_cast<uint32_t*>(reinterpret_cast<uint8_t*>(this) + 0xA0);
		}

		uint32_t get_fifth_hash() {
			return *reinterpret_cast<uint32_t*>(reinterpret_cast<uint8_t*>(this) + 0xA4);
		}

		uint32_t get_sixth_hash() {
			return *reinterpret_cast<uint32_t*>(reinterpret_cast<uint8_t*>(this) + 0xA8);
		}

		 uint32_t get_test_Hash() {
			 return *reinterpret_cast<uint32_t*>(reinterpret_cast<uint8_t*>(this) + 0xB0);
		}

		bool send_server_shoot(int nShootVal) 
		{
			if (!utils::memory::valid_pointer(this))
				return false;

			auto EDrvWeapon = this->get_movement(scimitar::EMovementComponent::EDrvWeapon);
			if (!utils::memory::valid_pointer(EDrvWeapon))
				return false;

			auto WeaponComponent = this->get_weapon_component();
			if (!utils::memory::valid_pointer(WeaponComponent))
				return false;


			auto v23 = *reinterpret_cast<std::uint64_t*>(EDrvWeapon + 0x68);
			if (!utils::memory::valid_pointer(v23))
				return false;


			static __int64(*GetServerClass)(__int64, __int64, weapon_component*) = reinterpret_cast<decltype(GetServerClass)>(ImageBase + 0x5D4E290); 

			static __int64(*SetupServerShootClass)(uint64_t * a1, uint64_t a2) = reinterpret_cast<decltype(SetupServerShootClass)>(ImageBase + 0x40BA5E0);

			static __int64(*CleanServerShootClass)(uint64_t * a1) = reinterpret_cast<decltype(CleanServerShootClass)>(ImageBase + 0x40B9F20);

			auto v35 = spoof_call(GetServerClass, (__int64)ImageBase + 0xBC40BF8, (__int64)0i64, WeaponComponent); 
			if (!v35) return false;

			void(*send_server_shoot)(uint64_t a1, __int64* a2, int a3) = reinterpret_cast<decltype(send_server_shoot)>(ImageBase + 0x9E93C20); 

			send_server_shoot(v23, &v35, nShootVal);

			return true;
		}


	};

	class weapon_component {

	public:

		void Shoot(ubiVector4 source, ubiVector4 destination)
		{
			if (!utils::memory::valid_pointer(this)) return;


			auto difference = source - destination;

			float hypothenuse = std::sqrtf((difference.x * difference.x) + (difference.y * difference.y) + (difference.z * difference.z));

			auto result = difference / hypothenuse;
			auto rotation = ubiVector4(-result.x, -result.y, -result.z, 0.f);
			auto location = ubiVector4(source.x, source.y, source.z, 1.f);

			bool isHost = *(bool*)((char*)this + 0x59);

			*(bool*)(scimitar::controller_local::get_local_controller() + 0x52) = 0;

			if (!isHost)
				*(bool*)((char*)this + 0x59) = 1;

			spoof_call(shoot_bullet, this, &location, &rotation);

			*(bool*)(scimitar::controller_local::get_local_controller() + 0x52) = 1;
			if (!isHost)
				*(bool*)((char*)this + 0x59) = 0;

		}


		void decrease_ammo() {

			if (!Globals->Ragebot.bDecreaseAmmo) return;

			if (!utils::memory::valid_pointer(this)) {
				return;
			}

			spoof_call(fn_decrease_ammo, this);
		}


		unsigned int ammo()
		{
			if (!utils::memory::valid_pointer(this)) {
				return 0;
			}

			auto WeaponFireType = utils::memory::Read<uint32_t>(reinterpret_cast<uintptr_t>(this) + 0x1258);

			auto WeaponFireData = reinterpret_cast<uintptr_t>(this) + 0x38;

			return FUNCTION(get_ammo, WeaponFireData, WeaponFireType);
		}

		void auto_reload()
		{

			auto bulletcount = utils::memory::Read<int>(reinterpret_cast<uintptr_t>(this) + 0x4458);

			if (bulletcount > 0) {
				spoof_call(fn_auto_reload, this);
			}
		}

		WeaponData* m_WeaponData()
		{

			if (!utils::memory::valid_pointer(this)) return 0;


			unsigned __int64 v50; // r12
			unsigned __int64 v51; // rcx
			__int64 v52; // r8
			unsigned __int64 WeaponDataRef; // r12


			auto v49 = ((0x22BF9C59i64 - __ROR8__(utils::memory::current_peb(), 0xC)) ^ (retaddr >> 0x21)) % 2;


			if (v49)
			{
				v51 = (*(_QWORD*)(this + 0x1198) << 0x10) & 0xFF00000000000000ui64;
				v52 = HIDWORD(*(_QWORD*)(this + 0x1198)) & 0xFF0000;
				v49 = v51 | (*(_QWORD*)(this + 0x1198) >> 0x10) & 0xFF00i64 | (*(_QWORD*)(this + 0x1198) << 0x28) & 0xFF0000000000i64 | (*(_QWORD*)(this + 0x1198) >> 0x18) & 0xFF00000000i64 | v52 | (*(_QWORD*)(this + 0x1198) << 0x10) & 0xFF000000000000i64 | (unsigned __int8)BYTE2(*(_QWORD*)(this + 0x1198));
				WeaponDataRef = __ROR8__(v49 | (*(_DWORD*)(this + 0x1198) << 0x10) & 0xFF000000, 1);

				return reinterpret_cast<WeaponData*>(WeaponDataRef);
			}


			v50 = __ROR8__(
				(*(_QWORD*)(this + 0x1198) >> 8) & 0xFF000000i64 | (*(_QWORD*)(this + 0x1198) << 0x10) & 0xFF00000000000000ui64 | (*(_QWORD*)(this + 0x1198) >> 0x10) & 0xFF00000000i64 | BYTE3(*(_QWORD*)(this + 0x1198)) | (*(_QWORD*)(this + 0x1198) << 0x18) & 0xFF0000000000i64 | (*(_QWORD*)(this + 0x1198) << 0x28) & 0xFF000000000000i64 | (unsigned __int16)((unsigned __int16)*(_QWORD*)(this + 0x1198) << 8) | (*(_QWORD*)(this + 0x1198) >> 0x28) & 0xFF0000i64,
				1);
			v51 = (v50 << 0x18) & 0xFF000000000000i64;
			v52 = (v50 >> 0x18) & 0xFF000000;
			WeaponDataRef = v52 | v51 | (v50 >> 0x10) & 0xFF0000 | BYTE5(v50) | (v50 << 0x20) & 0xFF0000000000i64 | (v50 << 0x10) & 0xFF00000000i64 | (unsigned __int16)((_WORD)v50 << 8) | v50 & 0xFF00000000000000ui64;


			return reinterpret_cast<WeaponData*>(WeaponDataRef);
		}

	};



	class _RayHitData
	{
	public:
		DEFINE_MEMBER(void**, m_collision_material, 0x8);
		DEFINE_MEMBER(ubiVector4, m_position, 0x20);
		DEFINE_MEMBER(float, m_origin_delta, 0x30);
		DEFINE_MEMBER(std::uint64_t, m_object, 0x38);

	private:
		char m_pad[0x50]{ };
	};

	class BulletPenetrationSettings
	{
	public:
		std::uint8_t Penetrable()
		{
			if (!utils::memory::valid_pointer(this))
				return 0xFF;


			auto v29 = (*(unsigned __int8*)(this + 0x24) - 0x27);
			return v29;

		}

	};

	class CollisionMaterial
	{
	public:
		BulletPenetrationSettings* m_BulletPenetrationSettings()
		{
			if (!utils::memory::valid_pointer(this))
			{

				return nullptr;
			}

			uint64_t BulletPenetrationSettingsRef{ 0x0 };


			unsigned __int64 v86; // rdx
			__int64 v87; // rsi
			unsigned __int64 v91; // rbx
			unsigned __int64 v92; // rbx
			__int64 v93; // r8
			unsigned __int64 v94; // rcx
			unsigned __int64 v235; // [rsp+40h] [rbp-268h] BYREF
			unsigned __int64 v236; // [rsp+48h] [rbp-260h]
			unsigned __int64 v241; // [rsp+158h] [rbp-150h]
			unsigned __int64 v245; // [rsp+178h] [rbp-130h]

			auto v85 = __ROR8__(utils::memory::current_peb(), 0xC) - 0x151ABD1425F80440i64 - (retaddr >> 0x21);
			LODWORD(v235) = 0x9CE29BEF;
			if (HIDWORD(v85))
				v86 = v85 % 4;
			else
				v86 = (unsigned int)v85 % 4;
			v241 = v86;
			LODWORD(v235) = 0x901149E7;
			if (!v86)
			{
				v91 = __ROL8__(*(_QWORD*)(this + 0x30), 0x23) ^ 0xEAE542EB13287771ui64;
				goto LABEL_148;
			}

			v245 = v241;
			LODWORD(v235) = 0x5B24190F;
			if (v241 == 1)
			{
				v92 = __ROL8__(*(_QWORD*)(this + 0x30), 0x23);
				v93 = BYTE4(v92);
				v94 = (v92 << 0x10) & 0xFF00000000000000ui64 | (v92 >> 0x18) & 0xFF000000;
				BulletPenetrationSettingsRef = (v94 | BYTE4(v92) | (v92 << 0x20) & 0xFF0000000000i64 | (v92 << 0x18) & 0xFF000000000000i64 | (v92 << 0x20) & 0xFF00000000i64 | v92 & 0xFF0000 | HIWORD(v92) & 0xFF00) ^ 0xEAE542EB13287771ui64;
			}
			else
			{
				v236 = v245;
				LODWORD(v235) = 0x994A3159;
				if (v245 == 2)
				{
					v93 = (unsigned __int8)((*(_QWORD*)(this + 0x30) ^ 0xEAE542EB13287771ui64) >> 0x20);
					v94 = ((*(_QWORD*)(this + 0x30) ^ 0xEAE542EB13287771ui64) << 0x10) & 0xFF00000000000000ui64 | ((*(_QWORD*)(this + 0x30) ^ 0xEAE542EB13287771ui64) >> 0x18) & 0xFF000000;
					BulletPenetrationSettingsRef = __ROL8__(
						v94 | v93 | ((*(_QWORD*)(this + 0x30) ^ 0xEAE542EB13287771ui64) << 0x20) & 0xFF0000000000i64 | ((*(_QWORD*)(this + 0x30) ^ 0xEAE542EB13287771ui64) << 0x18) & 0xFF000000000000i64 | ((*(_QWORD*)(this + 0x30) ^ 0xEAE542EB13287771ui64) << 0x20) & 0xFF00000000i64 | (*(_DWORD*)(this + 0x30) ^ 0x13287771) & 0xFF0000 | ((*(_QWORD*)(this + 0x30) ^ 0xEAE542EB13287771ui64) >> 0x30) & 0xFF00,
						0x23);
				}
				else
				{
					v235 = v236;
					v91 = __ROL8__(*(_QWORD*)(this + 0x30) ^ 0xEAE542EB13287771ui64, 0x23);

				LABEL_148:

					v93 = BYTE4(v91);
					v94 = (v91 << 0x10) & 0xFF00000000000000ui64 | (v91 >> 0x18) & 0xFF000000;
					BulletPenetrationSettingsRef = v94 | BYTE4(v91) | (v91 << 0x20) & 0xFF0000000000i64 | (v91 << 0x18) & 0xFF000000000000i64 | (v91 << 0x20) & 0xFF00000000i64 | v91 & 0xFF0000 | HIWORD(v91) & 0xFF00;
				}
			}

			if (!utils::memory::valid_pointer(BulletPenetrationSettingsRef))
			{

				return nullptr;
			}

			return *reinterpret_cast<BulletPenetrationSettings**>(BulletPenetrationSettingsRef);
		}
	};

	struct HitData
	{
	public:
		DEFINE_MEMBER(void**, m_VTABLE, 0x0);
		DEFINE_MEMBER(ubiVector4, m_Position, 0x20);

		CollisionMaterial* m_CollisionMaterial()
		{
			if (!utils::memory::valid_pointer(this))
				return nullptr;



			unsigned __int64 v20; // rax
			unsigned __int64 v21; // rdx
			unsigned __int64 v22; // r9
			unsigned __int64 v23; // r9
			__int64 v25; // r9
			unsigned __int64 v26; // r8
			unsigned __int64 v27; // rdx
			unsigned __int64 v28; // rbp
			std::uint64_t CollisionMaterialRef{ 0 };


			auto v19 = __ROR8__(utils::memory::current_peb(), 0xC);
			v20 = (v19 ^ 0x8D1F1B4Di64) + (retaddr >> 0x21);
			v21 = HIDWORD(v20) ? ((v19 ^ 0x8D1F1B4Di64) + (retaddr >> 0x21)) % 3 : (unsigned int)v20 % 3;
			if (v21)
			{
				if (v21 == 1)
				{



					v25 = (*(_QWORD*)(this + 8) << 0x28) & 0xFF000000000000i64;
					v26 = (*(_QWORD*)(this + 8) >> 0x10) & 0xFF0000000000i64;
					v27 = ((*(_QWORD*)(this + 8) >> 8) & 0xFFFF0000i64 | (*(_QWORD*)(this + 8) << 0x10) & 0xFF0000FF00000000ui64 | v26 | v25) >> 0x10;
					CollisionMaterialRef = (v25 | HIDWORD(v26) | v27 & 0xFF0000 | (*(_QWORD*)(this + 8) << 0x18) & 0xFF00000000000000ui64 | (((unsigned __int8)*(_QWORD*)(this + 8) | (*(_QWORD*)(this + 8) >> 0x28) & 0xFF00i64) << 0x18) | v27 & 0xFF00000000FFi64)
						- 0x5E;
				}
				else
				{


					v28 = *(_QWORD*)(this + 8) - 0x5Ei64;
					CollisionMaterialRef = BYTE2(v28) | (v28 << 8) & 0xFF000000000000i64 | (v28 >> 0x28) & 0xFF00 | ((unsigned __int64)((unsigned int)v28 & 0xFF00FFFF) << 0x10) | v28 & 0xFF0000FF00000000ui64;
				}
			}
			else
			{



				v22 = *(_QWORD*)(this + 8);
				v23 = ((v22 >> 0x28) & 0xFF00)
					+ ((v22 << 0x10) & 0xFF00000000000000ui64 | (v22 << 0x10) & 0xFF00000000i64 | (v22 << 0x28) & 0xFF000000000000i64 | (unsigned __int8)v22 | (v22 >> 0x10) & 0xFF0000000000i64 | (v22 >> 8) & 0xFFFF0000)
					- 0x5E;
				CollisionMaterialRef = (v23 >> 0x10) & 0xFF0000 | WORD2(v23) & 0xFF00 | ((unsigned __int64)((unsigned int)v23 & 0xFF000000) << 0x20) | BYTE2(v23) | (unsigned int)((_DWORD)v23 << 0x18) | v23 & 0xFF000000000000i64 | (v23 << 0x18) & 0xFF00000000i64 | (v23 >> 0x10) & 0xFF0000000000i64;
			}

			if (!utils::memory::valid_pointer(CollisionMaterialRef))
				return nullptr;

			return *reinterpret_cast<CollisionMaterial**>(CollisionMaterialRef);
		}

	public:
		bool Penetrable()
		{
			if (!utils::memory::valid_pointer(this))
				return false;

			auto CollisionMaterial = this->m_CollisionMaterial();
			if (!utils::memory::valid_pointer(CollisionMaterial))
				return false;

			auto BulletPenetrationSettings = CollisionMaterial->m_BulletPenetrationSettings();
			if (!utils::memory::valid_pointer(BulletPenetrationSettings))
				return false;

			auto Penetrable = BulletPenetrationSettings->Penetrable();
			if (Penetrable == 0xFF)
				return false;

			return true;
		}
	};//Size = 0x50

	class _HitInfo
	{
	public:
		DEFINE_MEMBER(_RayHitData*, m_hits, 0x8);
		DEFINE_MEMBER(std::uint32_t, m_hit_count, 0x10);
		DEFINE_MEMBER(bool, m_did_hit, 0x18);

	private:
		char m_pad[0x30]{ };
	};

	class _RayCastData
	{
	public:
		_RayCastData(physic_world* m_PhysicWorld, uint32_t Mask, int max_hits, ubiVector4* Start, ubiVector4* End)
		{
			this->m_PhysicWorld() = m_PhysicWorld;
			this->m_filter_mask() = Mask;
			this->m_max_hits() = max_hits;
			this->m_flag2() = true;

			this->m_rayStart() = Start;
			this->m_rayEnd() = End;

			this->setToNull_1() = 0;
			this->setToNull_2() = 0;
			this->Collector() = &this->m_hit_information;
		}

		~_RayCastData()
		{
			auto start = (std::uint64_t)&this->m_hit_information;
			start -= 0x78;

			spoof_call(fn_free_ray, (void*)start);
		}

		DEFINE_MEMBER(physic_world*, m_PhysicWorld, 0x8); //updated

		DEFINE_MEMBER(std::uint32_t, m_filter_mask, 0x50); //updated
		DEFINE_MEMBER(uint8_t, m_flag1, 0x60); //updated
		DEFINE_MEMBER(uint8_t, m_flag2, 0x59); //updated
		DEFINE_MEMBER(uint8_t, m_max_hits, 0xB0); //updated

		DEFINE_MEMBER(ubiVector4*, m_rayStart, 0xC0);//updated
		DEFINE_MEMBER(ubiVector4*, m_rayEnd, 0x150); //updated
		DEFINE_MEMBER(std::uint64_t, setToNull_1, 0x48); //updated
		DEFINE_MEMBER(std::uint64_t, setToNull_2, 0x1F8); //updated
		DEFINE_MEMBER(_HitInfo*, Collector, 0x208);//updated

	private:
		char m_pad[0x218]{ };

	public:
		_HitInfo m_hit_information{ };

	private:
		char m_pad2[0x100]{ };
	};

	class physic_world
	{
	public:
		void RayCast(_RayCastData* RayCastData)
		{
			if (!utils::memory::valid_pointer(this)) return;

			spoof_call(fn_ray_cast, (void*)RayCastData);
		}

		bool visible(const ubiVector4& Source, const ubiVector4& Destination)
		{
			if (!utils::memory::valid_pointer(this))
				return false;

			ubiVector4 src = Source;
			ubiVector4 dst = Destination;

			_RayCastData hknpRayCastQuery = _RayCastData(this, 0x126045, 0x1, &src, &dst);
			RayCast(&hknpRayCastQuery);

			uint64_t m_HitArray = (uint64_t)hknpRayCastQuery.m_hit_information.m_hits();
			auto m_hitCount = hknpRayCastQuery.m_hit_information.m_hit_count() & 0x3FFFFFFF;

			return (m_hitCount == 0);
		}

		bool penetrable(const ubiVector4& Source, const ubiVector4& Destination)
		{
			if (!utils::memory::valid_pointer(this))
				return false;

			ubiVector4 src = ubiVector4(Source.x, Source.y, Source.z, 0.f);
			ubiVector4 dst = ubiVector4(Destination.x, Destination.y, Destination.z, 0.f);

			_RayCastData hknpRayCastQuery = _RayCastData(this, 0x22034BF, 0x20, &src, &dst);
			RayCast(&hknpRayCastQuery);

			auto m_hitCount = hknpRayCastQuery.m_hit_information.m_hit_count() & 0x3FFFFFFF;
			if (m_hitCount == 0)
			{

				return true;
			}

			uint64_t m_HitArray = (uint64_t)hknpRayCastQuery.m_hit_information.m_hits();
			if (!utils::memory::valid_pointer(m_HitArray))
			{
				return false;
			}

			auto v16 = 0x50 * m_hitCount;
			for (auto i = 0i64; i != v16; i += 0x50i64)
			{
				auto m_HitData = (HitData*)(m_HitArray + i);

				if (!utils::memory::valid_pointer(m_HitData))
					continue;

				auto m_CollisionMaterial = m_HitData->m_CollisionMaterial();

				if (!utils::memory::valid_pointer(m_CollisionMaterial))
					continue;

				auto m_BulletPenetrationSettings = m_CollisionMaterial->m_BulletPenetrationSettings();

				if (!utils::memory::valid_pointer(m_BulletPenetrationSettings))
					continue;

				auto m_Penetrable = m_BulletPenetrationSettings->Penetrable();

				if (m_Penetrable == 0xFF)
					return false;
			}

			return true;
		}
	};



	inline bool is_visible(ubiVector4 src, ubiVector4 dst)
	{

		using Prototype = uint64_t(*)(uint64_t, ubiVector4*, ubiVector4*, Trace*);

		const Prototype function = reinterpret_cast<Prototype>(ImageBase + 0x56B4A10);

		Trace trace;
		if (spoof_call(
			function,
			0ui64,
			&src,
			&dst,
			&trace) == 2)
		{
			return true;
		}

		return false;
	};


	class Server {
	public:

		void send_to_server(void* data, uint32_t hash)
		{
			static void(*send_server_packet)(Server*, uint32_t*, void*) = reinterpret_cast<decltype(send_server_packet)>(ImageBase + 0x40B2C30);
			spoof_call(send_server_packet, this, &hash, data);
		}




	public:

		struct sprint_state_server
		{
		public:
			uint64_t qword1;//0x0
			uint64_t qword2;//0x8
			uint64_t qword3;//0x10
			uint8_t char4;//0x18
		private:
			char pad_0019[0x7];//0x19
		public:
			uint8_t sprint_state;//0x20

			sprint_state_server(uint8_t state)
			{
				this->qword1 = ImageBase + 0xB27ADF0;
				this->qword2 = ImageBase + 0xB0DE4C8;

				bool tmp{ true };
				this->qword3 = (uint64_t)tmp;
				this->char4 = 1;

				this->sprint_state = state;
			}
		};


	};


	inline __int64(*sub)(std::uint64_t a1, std::uint64_t a2, std::uint64_t* a3) = reinterpret_cast<decltype(sub)>(ImageBase + 0x66B88E0); 

	inline void unlock_all() {
		uint64_t qword = utils::memory::Read<std::uint64_t>(ImageBase + 0xBC40CE8);

		uint64_t value1 = spoof_call(sub, qword, (std::uint64_t)0x0000000F37524569, (std::uint64_t*)nullptr);
		uint64_t value2 = spoof_call(sub, qword, (std::uint64_t)0x0000005838589211, (std::uint64_t*)nullptr);

		**reinterpret_cast<std::uint64_t**>(value1) = **reinterpret_cast<std::uint64_t**>(value2);
	}

	inline void Init()
	{
		RVA_CALL(fn_ray_cast, 0x6E171B0); // 0x3f34fdf4 // 0x50BF00
		RVA_CALL(fn_free_ray, 0x31B8CE0); //aFree //3DB2870
		RVA_CALL(fn_get_weapon_component, 0x5198BA0);
		RVA_CALL(shoot_bullet, 0x72C2220)
		RVA_CALL(get_ammo, 0x7310BC0);
		RVA_CALL(fn_auto_reload, 0x72D4F60);
		RVA_CALL(fn_decrease_ammo, 0x72C4660);
		RVA_CALL(MeleeDamage, 0x3690E0);
		RVA_CALL(self_revive_call, 0x19E1A0);
	}

}

#endif