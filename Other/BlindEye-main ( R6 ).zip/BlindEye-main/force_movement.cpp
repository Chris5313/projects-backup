#include "BlindEye.hpp"


auto BlindEye::force_movement(float movementSpeed) -> void
{

	auto Pawn = scimitar::game_manager::get_instance()->get_local_controller()->get_pawn();

	if (!utils::memory::valid_pointer(Pawn)) return;

	auto local_entity = Pawn->get_entity();

	if (!utils::memory::valid_pointer(local_entity)) return;

	auto GroundNavContext = *reinterpret_cast<std::uint64_t*>(Pawn + 0xB40);

	static bool isJumping = false;

	ubiVector3 backwardDirection = -(*(ubiVector3*)(local_entity + 0x30));

	ubiVector3 rightDirection = *(ubiVector3*)(local_entity + 0x20);

	ubiVector3 direction = ubiVector3(0.f, 0.f, 0.f);

	
     if (GetAsyncKeyState('W')) //forward
			direction -= backwardDirection;

		if (GetAsyncKeyState('D')) //Right
			direction += rightDirection;

		if (GetAsyncKeyState('A')) //Left
			direction -= rightDirection;

		if (GetAsyncKeyState('S')) //Backwards
			direction += backwardDirection;
	
	
	direction.Normalize2();

	direction *= movementSpeed;

	utils::memory::Write<ubiVector2>(GroundNavContext + 0x4B0, { direction.x, direction.y });
}
